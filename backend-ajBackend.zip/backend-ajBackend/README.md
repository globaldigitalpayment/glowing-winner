# README #

### What is this repository for? ###

APIs for BYTUS TOKENSALE PLATFORM

### Prerequisites
  - Node.js
  - NPM
  - MongoDB
  - npm install -g pm2

### How do I get set up? ###

npm install
npm start

## API

API Docs

http://localhost:7010/api/v1/api-docs

or if you love JSON

http://localhost:7010/api/v1/api-docs.json
