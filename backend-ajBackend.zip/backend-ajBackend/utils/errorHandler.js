module.exports = ({ errorType,message,description })=>{
  return {
    message ,
    description ,
    status:200
  };
};
