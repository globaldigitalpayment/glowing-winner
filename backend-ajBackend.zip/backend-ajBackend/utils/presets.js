const preset = {
  maxLoginAttempts: 3,
  resettokenExpiresAt : 24*3600000,
  tokenExpiryTime: '1d',
  rememberTokenExpiryTime: '30d',
  tokenSecret : 'sshhhhh',
  unblockTime: 1, // days
  emailEntered: 'e',
  emailVerified: 'e_v',
  userVerified: 'verified', //kyc stage
  userActive: 'active',
  userInactive: 'inactive',
  userBlocked: 'blocked',
  stateUser : 'USER',
  stateSubscriber : 'SUBSCRIBER'
};

module.exports = preset;
