let crypto = require('crypto');
let shortid = require('shortid');

const logger = require('./../config/logger');
/* module.exports.getRandomToken = () => {
	return new Promise((resolve, reject) => {
		crypto.randomBytes(32, function (ex, buf) {
			var token = buf.toString('hex');
			resolve(token);
		});
	});
}; */

module.exports.genShortId = ()=>{
  return shortid.generate();
};


module.exports.removeFalsy = (req,res,next) => {

  //console.log(req.body);

  const newObj = {};
  Object.keys(req.body).forEach((prop) => {
    if (!!req.body[prop]) {
      newObj[prop] = req.body[prop];
    }
  });
  req.body = newObj;
  logger.debug(req.body);
  return next();
};

module.exports.removeQueryFalsy = (req,res,next) => {
  const newObj = {};
  Object.keys(req.query).forEach((prop) => {
    if (!!req.query[prop]) {
      newObj[prop] = req.query[prop];
    }
  });
  req.query = newObj;
  logger.debug(req.query);
  return next();
};

module.exports.getRandomToken = function () {
  const token = crypto.randomBytes(64).toString('hex');
  //console.log(token);
  return token;
};

module.exports.findElementWithProp = ({ array,prop,value })=>{
  let element = false;
  for (let index = 0; index < array.length; index++) {
    if (array[index][prop] === value) {
      element = array[index];
      break;
    }
  }
  return element;
};

module.exports.returnError = (data, err, res) => {
  return res.json({
    error: {
      message: data,
      dev_message: err
    }
  });
};

