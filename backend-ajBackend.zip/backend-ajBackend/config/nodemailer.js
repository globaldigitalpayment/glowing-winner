const nodemailer = require('nodemailer');
const mailConstsynapsetor = require('./mailTemplates');
const logger = require('./logger');
// const SparkPost = require('sparkpost');
// const client = new SparkPost('2e9092c4bc9a69906808a3ad7ed64fbf0b4ff68d');
const env = require('./env');
// let smtpTransport = require('nodemailer-smtp-transport');

// var smtpTransport = nodemailer.createTransport("SMTP",{
//   service: "Gmail",
//   auth: {
//       user: "******@gmail.com",
//       pass: "*****"
//   }
// });

// const Mailgun = require('mailgun-js');
//Your api key, from Mailgun’s Control Panel done
// const api_key = '94e8e9db7282b3d4ac4f8b990ca6559b-1053eade-72b60789';
// const api_key = '891c922e4016b2e68a2715f799f0348e-060550c6-c13369a8';
// let api_key = '94e8e9db7282b3d4ac4f8b990ca6559b-1053eade-72b60789';
//Your domain, from the Mailgun Control Panel
// const domain = 'tokensale.pexo.io';
let domain = 'mail.quillhash.com';

const devMailer = ({ mailType, to, data }) => {

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'admin@bytus.io',
      pass: 'T1alya1726**'
    }
  });

  // const mailgun = new Mailgun({ apiKey: api_key, domain: domain });

  const sendMail = ({ subject = 'Subject not defined', html = '<h3>Text Unavailable</h3>' }) => {
    //return new Promise((resolve, reject) => {
    const from = '<admin@bytus.io>'; // sender address
    const mailOptions = {
      from,
      to, // list of receivers
      subject, // Subject line
      //text, // plain text body
      html // html body
    };
    //
    // // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return console.log(error);
      }
      console.log('Message sent: %s', info.messageId);
      console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
      return;
    });
    // });
    // const from = 'hello@quillhash.com'; // sender address
    // let mailOptions = {
    //   //Specify email data
    //   from: from,
    //   //The email to contact
    //   to: to,
    //   //Subject and text data
    //   subject: subject,
    //   html: html
    // }


    // if(!!Array.isArray(to)) {
    //   var recipientVars = {};
    //   to.map( (mailTo, index) => {
    //     Object.assign(recipientVars, { [`${mailTo}`]: { id: index, email: `${mailTo}` } } );
    //   });
    //   //console.log('recipientVars : ', recipientVars);
    //   mailOptions = {
    //     'from': from,
    //     'to': to,
    //     'recipient-variables': recipientVars,
    //     'bcc': to,
    //     'subject': subject,
    //     'html': html
    //   };

    // }


    // mailgun.messages().send(mailOptions, (err, body) => {
    //   //If there is an error, render the error page
    //   if (err) {

    //     return  console.log('got an error: ', err);
    //   }
    //   //Else we can greet    and leave
    //   else {

    //     //console.log(body);
    //   }
    // });
  };

  const mailContent = mailConstsynapsetor({ mailType,data });
  const subject = mailContent.subject,
    html = mailContent.html;

  sendMail({ to, subject, html });

};

const sesMailer = ({ mailType, to, data }) => {
  const recepientArr = [];
  if(typeof to === 'string') {
    recepientArr.push({ address: to });
  } else {
    to.forEach(element => {
      recepientArr.push({ address: element });
    });
  }

  let transporter = nodemailer.createTransport(smtpTransport({
    host: 'email-smtp.us-west-2.amazonaws.com',
    port: 465,
    secure: true,
    auth: {
      user: 'AKIAIWPFM4EY5SIMMEEQ',
      pass: 'AqotFs9SOczF3ISHZhXgR8OqtZ9O27Wn+jcqUNrqksfr'
    }
  }));


  const sendMail = ({ subject = 'Subject not defined', html = '<h3>Text Unavailable</h3>' }) => {

    const from = '"Synapse" <hello@mail.synapse.com>'; // sender address
    const mailOptions = {
      from,
      to : recepientArr, // list of receivers
      subject, // Subject line
      //text, // plain text body
      html // html body
    };

    transporter.sendMail(mailOptions)
      .then(response => { // eslint-disable-line
        console.log('Message sent to: %s', to);
        //console.log(response);
        logger.verbose('Message sent to: %s', to);
      })
      .catch(err => {
        console.log('Whoops! Something went wrong');
        console.log(err);
        logger.error(err);
      });
  };

  const mailContent = mailConstsynapsetor({ mailType,data });
  const subject = mailContent.subject,
    html = mailContent.html;

  sendMail({ to, subject, html });

};

if (env === 'development' || env === 'staging' || env === 'production') {
  module.exports = devMailer;
} else {
  module.exports = sesMailer;
//module.exports = sesMailer;
};
