const env = require('./env'),
  responseMsgs = require('./responseMessages.json');

let referralTokenModel = [
  { min:1,max:30,tokens:10 },
  { min:31,max:60,tokens:15 },
  { min:61,max:100,tokens:20 }
];

let getReferralTokenInc = (referralNumber)=>{
  let tokens = 0;
  for (let index = 0; index < referralTokenModel.length; index++) {
    const element = referralTokenModel[index];
    if (element.min <= referralNumber && element.max >= referralNumber) {
      tokens = referralNumber * element.tokens;
      break;
    }
  }
  return tokens;
};

let constantsObj = {
  // 'adminEmail': 'admin@synapse.io',
  'adminEmail': 'admin@bytus.io',
  'adminPassword' : 'admin#123$%',
  'adminFullName' : 'admin',
  getReferralTokenInc,
  responseMsgs,
  'votes': {
    min: 0,
    max: 1000
  },
  'voteRewardTokens' : 0,
  'twitterAuth' : {
    consumer_key: 'vsrrpZOceJGfk0McuYW9RACEN',
    consumer_secret: 'pMIYNa1ZQ4tD8RMPN9QjinTviEWLyBwgQHJwJ9lPD1vUnoNfy3',
    access_token_key: '611968734-qeS88kCXI3ArecoV5HrtercE5xCTebdulUoduv5h',
    access_token_secret: 'N8wZiCyKHDi8SYPPkHSZImXcIvl0DHe9ULYXIAccAiDna'
  },
  'gCaptcha' : {
    url : 'https://www.google.com/recaptcha/api/siteverify',
    secret: '6LdZP14UAAAAABrhp2lNnVEPZLSC81WdABbl4XMt'
  },
  'emailVerifyExpiry': Date.now() + 1800000000, // 30 mins
  'referInviteUrl' : 'https://icocabinet-demo.quillhash.com/signup/refer',
  'ico' : {
    'tokenUsd' : 0.05,
    'ethUsd' : 600,
    // 'ethAddress': '0xdf62834bc8057b0404a145678b49933a360a44a6',

    'stage' : 'Private sale',
    'btcUsd' : 7500,
    // 'btcAddress': '3FtFgSVPPEqusZXhm26mXmTkZHuwCFeGTb',

    'bonus': 0,
    'minInvest' : 100,
    'privateSaleTokenUsd' : 533.3333,
    'preSaleTokenUsd' : 444.4444,
    'mainSaleTokenUsd' : 400
  },
  'possibleTrxnStatus' : ['confirmed', 'pending', 'halted','cancelled'],
  'possibleTokenTransferStatus' : ['yes','no'],
  'possibleIcoPhases' : ['privateSale','preSale','crowdSale']
};

switch (env) {
  case 'production':
    constantsObj.baseUrl = 'http://54.169.82.119:7011';
    // constantsObj.baseUrl = 'https://tokenplatform-user-demo.quillhash.com';
    // constantsObj.baseUrl = 'http://52.77.212.79:6036';
    constantsObj.alertEmail = 'support@bytus.io';
    constantsObj.depositEmail = 'support@bytus.io';
    break;
  case 'staging':
    constantsObj.baseUrl = 'http://54.169.82.119:7011';
    // constantsObj.baseUrl = 'https://tokenplatform-user-demo.quillhash.com';
    // constantsObj.baseUrl = 'http://13.229.146.169:7022';
    constantsObj.alertEmail = 'support@bytus.io';
    constantsObj.depositEmail = 'support@bytus.io';
    break;
  case 'development':
    // constantsObj.baseUrl = 'http://13.229.146.169:7022';
    constantsObj.baseUrl = 'http://54.169.82.119:7011';
    // constantsObj.baseUrl = 'https://tokenplatform-user-demo.quillhash.com';
    constantsObj.alertEmail = 'support@bytus.io';
    constantsObj.depositEmail = 'support@bytus.io';
    break;
  default:
    break;
}

module.exports = constantsObj;
