const ejs = require('ejs'),
  Path = require('path');

const mailfileMap = {
  'FORGOT_PASSSWORD': {
    htmlFileName : 'forgotPassword_spark.js',
    subject: 'bytus.IO - Reset Password'
  },
  'FORGOT_PASSSWORD_RESET': {
    htmlFileName: 'forgotPasswordReset_spark.js',
    subject: 'bytus.IO - Reset Password'
  },
  'AFTER_PASSWORD_CHANGE' : {
    htmlFileName : 'afterPasswordChange_spark.js',
    subject: 'bytus.IO - Password Updated'
  },
  'ACC_VERIFY':{
    htmlFileName : 'verifyAccount_spark.js',
    subject: 'bytus.IO - Email Verification'
  },
  'ACC_VERIFY_ADMIN': {
    htmlFileName: 'verifyAccount_spark.js',
    subject: 'bytus.IO - Email Verification For Admin'
  },
  'ACC_VERIFY_PASS':{
    htmlFileName : 'verifyAccountPass_spark.js',
    subject: 'bytus.IO - Email Verification With Password'
  },
  'AFTER_ADMIN_UPGRADATION' : {
    htmlFileName: 'afterUserToAdmin.js',
    subject: 'bytus.IO - Your account has been upgraded to admin'
  },
  'AFTER_CHANGE_ACCESS' : {
    htmlFileName: 'afterAdminToUser.js',
    subject: 'bytus.IO - Your access control is changed to user now'
  },
  'WHITELIST' : {
    htmlFileName: 'whitelist_spark.js',
    subject: 'bytus.IO - Whitelist Confirmation'
  },
  'AFTER_DEPOSIT' : {
    htmlFileName: 'afterDeposit.js',
    subject: 'bytus.IO -New deposit in private sale'
  },
  'REFER_INVITE':{
    htmlFileName: 'referralInvite.js',
    subject: 'bytus.IO - You have been invited to join bytus.io'
  },
  'EXCEPTION_CAUGHT' :{
    htmlFileName : 'exceptionNotify.js',
    subject: 'bytus.IO - ALERT !! EXCEPTION CAUGHT !!'
  },
  'INTERNAL_SERVER_ERROR' :{
    htmlFileName : 'exceptionNotify.js',
    subject : 'bytus.IO ALERT !! INTERNAL_SERVER_ERROR !!'
  },
  'KYC_REQUEST_ACCEPTED' : {
    htmlFileName : 'kycAccepted.js',
    subject : 'bytus.IO - KYC Approved'
  },
  'KYC_REQUEST_REJECTED' : {
    htmlFileName : 'kycRejected.js',
    subject : 'bytus.IO - KYC Declined'
  },
  'KYC_REQUEST_REPORTED' : {
    htmlFileName : 'kycReported.js',
    subject : 'bytus.IO - KYC request on hold.'
  },
  'LOGIN_ALERT' : {
    htmlFileName : 'loginAlert.js',
    subject : 'bytus.IO - Login Success'
  },
  'USER_SUPPORT' : {
    htmlFileName : 'userSupport.js',
    subject : '[SUPPORT] You have a message from user.'
  },
  'SUBSCRIBE': {
    htmlFileName : 'subscribe.js',
    subject : 'Message from bytus.IO Support Team.'
  },
  'MESSAGE' : {
    htmlFileName : 'message.js',
    subject : 'Message from bytus.IO Support Team.'
  },
  'TICKET_REPLY' : {
    htmlFileName : 'ticketReply.js',
    subject : 'You have a reply from bytus.IO Support team.'
  },
  'INVESTOR_SIGNUP' : {
    htmlFileName : 'investorSignup.js',
    subject: 'bytus.io - Account Created'
  },
  'CUSTOM_TEMPLATE' : {
    htmlFileName : 'customTemp.js',
    subject: 'Message from bytus.io'
  },
  'CONTACTUS': {
    htmlFileName : 'contactUs.js',
    subject: 'Message from bytus.io'
  },
  'PUSH_TO_VENDOR': {
    htmlFileName: 'pushToVendor.js',
    subject: 'Message from bytus.io'
  }
};


module.exports = ({ mailType,data })=>{
  const mailData = mailfileMap[mailType];
  const ejsData = require(Path.join(__dirname,mailData.htmlFileName)); //Path.join(__dirname,mailData.htmlFileName);
  let htmlStr = ejs.render(ejsData.htmlString, data, {});
  // ,
  //   textStr = ejs.render(ejsData.textString, data, {});

  return {
    html : htmlStr,
    subject : mailData.subject
    // ,
    // text : textStr
  };

};
