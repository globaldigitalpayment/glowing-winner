const constants = require('config/constants');

module.exports = {
  htmlString: `<!DOCTYPE html>
    <html>
      <head>
          <meta charset="utf-8" />
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <title>Page Title</title>
          <meta name="viewport" content="width=device-width, initial-scale=1">
      </head>

      <body>
      <table class="main" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #ffffff; border-radius: 3px; border-spacing: 0; border-collapse: collapse; box-shadow: 0 0 0px 0px rgba(0,0,0,0.6);">
      <table style="background-color: black; width: 50%; height: 150px;">
  	<tr>
                            <td style="text-align: center; padding-top: 20px background-color: black;"><a href="https://bytus.io/"><img src="https://zineum-ico-kyc.s3.us-east-2.amazonaws.com/logo%2Cpng1555570487406.png" alt="bytus" width="250" border="0" /></a></td>
                          </tr>
  </table>
      </table>
        Dear <%=fullName%><br></br>
        <p>Thanks for signing up to your bytus Account. </p> </br>
        <p>To complete the registration process, please follow the link: <a href ='${constants.baseUrl}/signin/verify/<%= token %>'>link</a> to verify email</p><br></br>
        <p> In case, above link does not respond to clicks, please try copying and pasting it into the address bar of your internet browser.<br></br>${constants.baseUrl}/signin/verify/<%= token %></p>
        </br>
        <p>
          <br></br>
          Regards,
          <br></br>
          bytus Team
        </p>
      </body>
      <table>
                                <tr>
                              <td style="padding:0">
                                  <table style="border-spacing: 0; border-collapse: collapse; padding: 0;margin: 0; background-color: black;">

                                      <tr>
                                          <td style="text-align:center !important; font-size:16px!important; width:600px !important; font-weight:700; height:50px;color: #fff"> Join Our Community</td>
                                      </tr>
                                      <tr>
                                          <td style="margin-top:110px;">&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td style="text-align:center !important; font-size:16px !important; width:600px !important; font-weight:700; padding-bottom: 15px;">
                                        <a href="#" style="color: transparent;"><img src="https://zineum-ico-kyc.s3.us-east-2.amazonaws.com/icons8-twitter-48%2Cpng1549565251471.png" style="width: 35px;"></a>&nbsp;&nbsp;
                                        <a href = "#" style="color: transparent;"> <img src="https://zineum-ico-kyc.s3.us-east-2.amazonaws.com/icons8-facebook-48%2Cpng1549565333586.png" style="width: 35px;"> </a>&nbsp;&nbsp;
                                        <a href = "#" style="color: transparent;"> <img src="https://zineum-ico-kyc.s3.us-east-2.amazonaws.com/icons8-linkedin-48%2Cpng1549565387108.png" style="width: 35px;"> </a>&nbsp;&nbsp;
                                        
                                        <a href = "#" style="color: transparent;"> <img src="https://zineum-ico-kyc.s3.us-east-2.amazonaws.com/icons8-telegram-app-48%2Cpng1549565466184.png" style="width: 35px;"> </a>&nbsp;&nbsp;
                                        </td>
                                      </tr>
                                      <tr>
                                          <td style="text-align:center !important; font-size:16px!important; width:200px !important;  height:30px;color: #fff">Contact: hello@bytus.io | &copy; 2018, All Rights Reserved</td>
                                      </tr>

                                  </table>
                              </td>
                          </tr>
                      </table>
                  </div>
              </td>
              <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;">&nbsp;</td>
          </tr>
                      </table>
                  </div>
              </td>
              <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;">&nbsp;</td>
          </tr>
      </table>
    </html>`,
  textString: `Follow this link to verify email ${constants.baseUrl}/signin/verify/<%= token %> `
};
