module.exports = {
  htmlString: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>bytus</title>
  </head>
  <body>
  <table width="640" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#fff;">
  <table style="background-color: black; width: 100%">
  	<tr>
                            <td style="text-align: center; padding-top: 20px background-color: black;"><a href="https://bytus.io/"><img src="https://zineum-ico-kyc.s3.us-east-2.amazonaws.com/logo%2Cpng1555570487406.png" alt="bytus" width="250" border="0" /></a></td>
                          </tr>
  </table>
  <tr>
  <td align="left" valign="top" style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; line-height: 30px; padding: 20px 20px 0px 20px;">Hi Team,
  <br><br>
  User with Email: <%=email%> has following issue : <br><br>
  Topic: <%=topic%><br><br>
  Message: <%=msg%>
  <br><br>
  </td>
  </tr>
  <tr>
  <td align="left" valign="top" style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; line-height: 26px; padding: 10px 20px 20px 20px;">Regards,<br />
  bytus Team<br />
  <a href="https://www.bytus.io" target="_blank">www.bytus.io</a></td>
  </tr>
  </table>
  <table width="640" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
                              <td style="padding:0">
                                  <table style="border-spacing: 0; border-collapse: collapse; padding: 0;margin: 0; background-color: black;">

                                      <tr>
                                          <td style="text-align:center !important; font-size:16px!important; width:600px !important; font-weight:700; height:50px;color: #fff"> Join Our Community</td>
                                      </tr>
                                      <tr>
                                          <td style="margin-top:110px;">&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td style="text-align:center !important; font-size:16px !important; width:600px !important; font-weight:700; padding-bottom: 15px;">
                                        <a href="#" style="color: transparent;"><img src="https://zineum-ico-kyc.s3.us-east-2.amazonaws.com/icons8-twitter-48%2Cpng1549565251471.png" style="width: 35px;"></a>&nbsp;&nbsp;
                                        <a href = "#" style="color: transparent;"> <img src="https://zineum-ico-kyc.s3.us-east-2.amazonaws.com/icons8-facebook-48%2Cpng1549565333586.png" style="width: 35px;"> </a>&nbsp;&nbsp;
                                        <a href = "#" style="color: transparent;"> <img src="https://zineum-ico-kyc.s3.us-east-2.amazonaws.com/icons8-linkedin-48%2Cpng1549565387108.png" style="width: 35px;"> </a>&nbsp;&nbsp;
                                        
                                        <a href = "#" style="color: transparent;"> <img src="https://zineum-ico-kyc.s3.us-east-2.amazonaws.com/icons8-telegram-app-48%2Cpng1549565466184.png" style="width: 35px;"> </a>&nbsp;&nbsp;
                                        </td>
                                      </tr>
                                      <tr>
                                          <td style="text-align:center !important; font-size:16px!important; width:200px !important;  height:30px;color: #fff">Contact: hello@bytus.io | &copy; 2018, All Rights Reserved</td>
                                      </tr>

                                  </table>
                              </td>
                          </tr>
                      </table>
                  </div>
              </td>
              <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;">&nbsp;</td>
          </tr>
  </table>
  </body>
  </html>`,
textString: `You have a support message from user`
};
