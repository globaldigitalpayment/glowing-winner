const express = require('express'),
  http = require('http'),
  // mailer = require('./config/nodemailer'),
  config = require('./config/'),
  cors = require('cors');
const { errors } = require('celebrate'),
  mongoose = require('mongoose'),
  env = require('./config/env'),
  constants = require('./config/constants'),
  fs = require('fs');

mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);
mongoose.set('useNewUrlParser', true);

const rateLimit = require("express-rate-limit");

const logger = require('./config/logger.js');
// Adding the root project directory to the app module search path:
require('app-module-path').addPath(__dirname);

const { myEmitter } = require('./app/v1/modules/jobs/controller');
// const { myEmitterPayWithToken } = require('./app/v1/modules/transaction/controller');
const { myEmitterTokenTransferAirBounty } = require('./app/v1/modules/jobs/controller');

// to avoid bottle necking of system
http.globalAgent.maxSockets = Infinity;

mongoose.connect(config.db, {
  auto_reconnect: true,
  socketOptions: {
    keepAlive: 500,
    connectTimeoutMS: 90000,
    socketTimeoutMS: 90000
  },
  connectWithNoPrimary: true
},(err) => {
  if (err) {
    logger.info('❌ ' + 'Mongodb Connection Error');
    logger.error(err);
  } else {
    logger.info('✅ ' + 'Mongodb Connected');
  }

});

const db = mongoose.connection;

db.on('error', () => {
  throw new Error(`${'❌ ' + 'Unable to connect to database at '}${config.db}`);
});
db.once('open', () => {
  logger.info(`${'✅ ' + 'Connected to Database : '}${config.db.substring(config.db.lastIndexOf('/') + 1, config.db.length)}`);
});

const app = express();

app.use( express.static( "public" ) );

// const limiter = rateLimit({
//   windowMs: 15 * 60 * 1000, // 15 minutes
//   max: 100 // limit each IP to 100 requests per windowMs
// });
// app.use(limiter);

app.locals.rootPath = __dirname;
app.set('rootPath', __dirname);

// const corsOptions = {
//   origin: 'https://tokensale.pexo.io',
//   optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
// };
app.use(cors());
app.options('*', cors());

require('./config/express')(app, config);


app.use((req, res, next) => {
  const err = new Error(`${req.path} --	 Path Not Found`);
  err.status = 404;
  next(err);
});
app.use(errors());
app.use((err, req, res, next) => {
  logger.error(err);
  // mailer({ mailType: 'INTERNAL_SERVER_ERROR', to: constants.alertEmail, data: { error: err, errorStack: err.stack } });

  let resObj = {};
  const error = err.stack ? err.stack : err;
  const status = err.status ? err.status : 500;
  console.error('ERROR -> ', error);
  if (env === 'staging' || env === 'production') {
    resObj = { success: false, description: typeof err === 'object' ? err.message : err, message: 'Something broke!' };
  } else {
    resObj = { success: false, description: err.message, message: 'Something broke!', error };

  }

  res.status(status).json(resObj);
});

const server = app.listen(config.port, () => {
  logger.info(`Express server listening on port ${config.port}\nOn env : ${env}`);
});

const io = require('socket.io').listen(server);
const ss = require('socket.io-stream');

const dir = './bountyFiles/';

// io.of('/api/v1/user/payWithToken').on('connection', (socket) => {
//   console.log('Got transaction response');
//   myEmitterPayWithToken.on('res', (data) => {
//     socket.emit('payWithTokenResponse', data);
//   });
// });

io.of('/api/v1/admin/tokenTransfer').on('connection', (socket) => {
  console.log('inside token transfer airdrop socket');
  myEmitterTokenTransferAirBounty.on('airdropRes', (data) => {
    console.log('myEmitterTokenTransferAirBounty: ');
    console.log('myEmitterTokenTransferAirBounty: data : ', data);
    socket.emit('tokenTransferAirbountyResponse', data);
  });
} );

io.of('/admin/uploadSheet').on('connection', (socket) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir);
  }

  myEmitter.on('res', (msg) => {
    socket.emit('bounty-update-response', msg);
  });

  myEmitter.on('resetPasswordRes', (msg) => {
    socket.emit('reset-password-response', msg);
  });


  ss(socket).on('bounty-sheet', (stream, data) => { // eslint-disable-line
    let filename = 'test.csv';
    stream.pipe(fs.createWriteStream(`./bountyFiles/${filename}`));
  });

  ss(socket).on('error', (err) => {
    console.log(err);
  });
});


process.on('unhandledRejection', (reason, p) => {
  logger.error('UNHANDLED REJECTION', reason, p);
  // mailer({ mailType: 'EXCEPTION_CAUGHT', to: constants.alertEmail, data: { error: reason, errorStack: reason.stack } });
});

process.on('uncaughtException', (error) => {
  logger.error('UNCAUGHT EXCEPTION', error);
  // mailer({ mailType: 'EXCEPTION_CAUGHT', to: constants.alertEmail, data: { error: error, errorStack: error.stack } });
  //errorManagement.handler.handleError(error);
  //if(!errorManagement.handler.isTrustedError(error))
  process.exit(1);
});

// If the Node process ends, close the Mongoose connection
process.on('SIGINT', () => {
  db.close(() => {
    console.log('Mongoose default connection disconnected through app termination');
    process.exit(0);
  });
});
