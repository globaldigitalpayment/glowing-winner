const express = require('express'),
  glob = require('glob');
const router = express.Router();
const config = require('config/');
const swaggerUi = require('swagger-ui-express');
const swaggerJSDoc = require('swagger-jsdoc');
const constants = require('config/constants');
const env = require('config/env');
const options = {
  swaggerDefinition: {
    info: {
      title: 'bytus-TOKENSALE', // Title (required)
      version: '1.0.0', // Version (required)
      description: 'API docs for ICO'
    },
    host: constants.baseUrl,
    basePath: '/api/v1',
    tags: [
      {
        name: 'Users',
        description: 'API for users in the system'
      },
      {
        name: 'Admin',
        description: 'API for admin in the system'
      },
      {
        name: 'Refer',
        description: 'API for Referral system'
      }
    ]
  },
  apis: [`${__dirname}/v1/modules/**/route.js`] // Path to the API docs
};

//const swaggerDocument = require('./v1/config/swagger.json');
const swaggerSpec = swaggerJSDoc(options);

router.get('/api-docs.json', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});


//router.use('/', swaggerUi.serve);
// if(env === 'staging' || env === 'development') {
  router.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
// }

const controllers = glob.sync(`app/${config.app.webApi}/modules/**/route.js`);

controllers.forEach((controller) => {
  require(controller)(router);
});

//glob.sync(config.root + '/app/**/route.js');
module.exports = router;
