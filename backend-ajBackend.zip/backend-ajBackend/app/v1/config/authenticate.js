const jwt = require('jsonwebtoken');
let presets = require('utils/presets');
let Session = require('../modules/user/sessionModel');
const logger = require('config/logger');

module.exports = (req, res, next) => {
  console.log(req.body,"body in auth")
  let token = req.headers['x-auth-token'] || req.body.user,
 
    secretOrKey = presets.tokenSecret;
    console.log("token",token);

  try {
    var decoded = jwt.verify(token, secretOrKey); // eslint-disable-line no-var
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired token'
    });
  }

  Session.findOne({
    userId: decoded.id,
    token: token
  }).populate('userId').exec((err, user) => {
    if (err) {
      logger.error('error');
      logger.error(err);
      next(err);
      //res.status(500).json({success:false,message:'Invalid or expired token'})
    }
    if (user && user.userId) {
      req.user = user.userId;
      return next();
      //return done(null, user.userId);
    } else {
      logger.debug('session not found');
      return res.status(401).json({
        success: false,
        message: 'Invalid or expired token'
      });
      //return done(null, false);
      //next(new Error('Invalid or expired token'));
      // or you could create a new account
    }
  });

};
