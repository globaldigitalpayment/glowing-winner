const mongoose = require('mongoose'),
    config = require('../../../config/');

mongoose.connect(config.db, {
    auto_reconnect: true,
    socketOptions: {
        keepAlive: 500,
        connectTimeoutMS: 90000,
        socketTimeoutMS: 90000
    },
    connectWithNoPrimary: true
}, (err) => {
    if (err) {
        //logger.info('❌ ' + 'Mongodb Connection Error');
        //logger.error(err);
    } else {
        //logger.info('✅ ' + 'Mongodb Connected');
    }

});

const db = mongoose.connection;

db.on('error', () => {
    throw new Error(`${'❌ ' + 'Unable to connect to database at '}${config.db}`);
});
db.once('open', () => {
    console.log(`${'✅ ' + 'Connected to Database : '}${config.db.substring(config.db.lastIndexOf('/') + 1, config.db.length)}`);
});

module.exports = db