// load all the things we need
let LocalStrategy = require('passport-local').Strategy,
  FacebookStrategy = require('passport-facebook').Strategy,
  GoogleStrategy = require('passport-google-oauth').OAuth2Strategy,
  JwtStrategy = require('passport-jwt').Strategy,
  ExtractJwt = require('passport-jwt').ExtractJwt,
  presets = require('utils/presets'),
  helper = require('utils/helper'),
  authKeys = require('./authKeys'),
  { genShortId } = require('utils/helper'),
  userController = require('../modules/user/controller.js'),
  mailer = require('config/nodemailer');

// load up the user model
const User = require('../modules/user/model');
const Session = require('../modules/user/sessionModel');
const logger = require('config/logger');
//const
const constants = require('config/constants');
const responseMsgs = constants.responseMsgs;

// expose this function to our app using module.exports
module.exports = function(passport) {
  ///////////////// Local Sigup/ login //////////////////////////////

  passport.use(
    'local-signup',
    new LocalStrategy(
      {
        // by default, local strategy uses username and password, we will override with email
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true // allows us to pass back the entire request to the callback
      },
      (req, email, password, done) => {
        //console.log(req.body);

        // asynchronous
        // User.findOne wont fire unless data is sent back
        process.nextTick(() => {
          // find a user whose email is the same as the forms email
          // we are checking to see if the user trying to login already exists or subscriber
          User.findOne(
            {
              $or: [
                {
                  'local.email': email
                },
                {
                  'email.value': email
                }
              ]
            },
            (err, user) => {
              // if there are any errors, return the error
              if (err) {
                return done(err);
              }

              if (user) {
                if (user.local.email === email) {
                  //  already a user
                  //return res.status(200).json({success:false,message:'Email exists'});
                  return done(null, {
                    isError: true,
                    message: responseMsgs.SIGNUP_LOCAL.EXISTING_EMAIL
                  });
                } else if (user.subscribe.email === email) {
                  // subscriber found. convert to user
                  user.local.email = email.toLowerCase();
                  user.local.password = user.generateHash(password);
                  user.accountVerify.verificationHash = helper.getRandomToken();
                  user.accountVerify.expiresAt = Date.now() + 1800000; //30 mins
                  user.userState = 'USER';
                  user.accountState = 'e';
                  user.personalDetails.fullName = req.body.fullName;
                  user.contributionRange = req.body.contributionRange;
                  user.termsAccepted = req.body.termsAccepted;
                  user.isUs = req.body.isUs;
                  user.subscribe.email = email.toLowerCase();
                  if(!!req.body.channel) {
                    user.refer.channel = req.body.channel;
                  }

                  // save the user
                  user.save(err => {
                    //eslint-disable-line
                    // eslint-disable-line no-shadow
                    if (err) {
                      throw err;
                    }

                    return done(null, user);
                  });
                } else {
                  return done(null, {
                    isError: true,
                    message: `Unknown Error${
                      responseMsgs.SIGNUP_LOCAL.EXISTING_EMAIL
                    }`
                  });
                }
              } else {
                // if there is no user with that email
                // create the user
                const newUser = new User();

                if (req.body.rfcode) {
                  if (req.body.rfcode.trim() !== '') {
                    newUser.temp = req.body.rfcode.trim();
                  }
                }

                // set the user's local credentials
                newUser.local.email = email.toLowerCase();
                newUser.email.value = email;
                newUser.local.isPrimary = true;
                newUser.local.password = newUser.generateHash(password);
                newUser.accountVerify.verificationHash = helper.getRandomToken();
                newUser.accountVerify.expiresAt = constants.emailVerifyExpiry;
                newUser.userState = 'USER';
                newUser.accountState = 'e';
                newUser.personalDetails.fullName = req.body.fullName;
                newUser.contributionRange = req.body.contributionRange;
                newUser.termsAccepted = req.body.termsAccepted;
                newUser.isUs = req.body.isUs;
                newUser.subscribe.email = email.toLowerCase();
                if(!!req.body.channel) {
                  console.log('channel : ', req.body.channel);
                  newUser.refer.channel = req.body.channel;
                }
                // save the user
                newUser.save(err => {
                  // eslint-disable-line no-shadow
                  if (err) {
                    throw err;
                  }
                  return done(null, newUser);
                });
              }
            }
          );
        });
      }
    )
  );


  ///////////////// Local /signup/refer/:refer //////////////////////////////

  // passport.use(
  //   'refer-signup',
  //   new LocalStrategy(
  //     {
  //       // by default, local strategy uses username and password, we will override with email
  //       usernameField: 'email',
  //       passwordField: 'password',
  //       passReqToCallback: true // allows us to pass back the entire request to the callback
  //     },
  //     (req, email, password, done) => {
  //       //console.log(req.body);
  //
  //       // asynchronous
  //       // User.findOne wont fire unless data is sent back
  //       process.nextTick(() => {
  //         // find a user whose email is the same as the forms email
  //         // we are checking to see if the user trying to login already exists or subscriber
  //         let refereeEmail, referee;
  //         if(!!req.params.refer) {
  //           User.find(
  //             {
  //               'refer.code': req.params.refer
  //             },
  //             (err, result) => {
  //               if(err) {
  //                 console.log('err : ', err);
  //                 return done(err);
  //               }else{
  //                 if(result.length === 0) {
  //                   return done(null, {
  //                     isError: true,
  //                     message: 'Invalid refer code'
  //                   });
  //                 }
  //                 refereeEmail = result[0].local.email;
  //                 referee = result[0]._id;
  //                 console.log('refereeEmail : ', refereeEmail);
  //
  //                 User.findOne(
  //                   {
  //                     $or: [
  //                       {
  //                         'local.email': email
  //                       },
  //                       {
  //                         'email.value': email
  //                       }
  //                     ]
  //                   },
  //                   (err, user) => {
  //                     // if there are any errors, return the error
  //                     if (err) {
  //                       return done(err);
  //                     }
  //
  //                     if (user) {
  //                       if (user.local.email === email) {
  //                         //  already a user
  //                         //return res.status(200).json({success:false,message:'Email exists'});
  //                         return done(null, {
  //                           isError: true,
  //                           message: responseMsgs.SIGNUP_LOCAL.EXISTING_EMAIL
  //                         });
  //                       } else if (user.subscribe.email === email) {
  //                         // subscriber found. convert to user
  //                         user.local.email = email.toLowerCase();
  //                         user.local.password = user.generateHash(password);
  //                         user.accountVerify.verificationHash = helper.getRandomToken();
  //                         user.accountVerify.expiresAt = Date.now() + 1800000; //30 mins
  //                         user.userState = 'USER';
  //                         user.accountState = 'e';
  //                         user.personalDetails.fullName = req.body.fullName;
  //                         user.contributionRange = req.body.contributionRange;
  //                         user.termsAccepted = req.body.termsAccepted;
  //                         user.isUs = req.body.isUs;
  //                         user.subscribe.email = email.toLowerCase();
  //                         user.refer.refereeEmail = refereeEmail;
  //                         user.refer.referee = referee;
  //                         if(!!req.query.channel) {
  //                           console.log('channel : ', req.query.channel);
  //                           user.refer.channel = req.query.channel;
  //                         }
  //
  //                         // save the user
  //                         user.save(err => {
  //                           //eslint-disable-line
  //                           // eslint-disable-line no-shadow
  //                           if (err) {
  //                             throw err;
  //                           }
  //
  //                           return done(null, user);
  //                         });
  //                       } else {
  //                         return done(null, {
  //                           isError: true,
  //                           message: `Unknown Error${
  //                             responseMsgs.SIGNUP_LOCAL.EXISTING_EMAIL
  //                           }`
  //                         });
  //                       }
  //                     } else {
  //                       // if there is no user with that email
  //                       // create the user
  //                       const newUser = new User();
  //
  //                       if (req.body.rfcode) {
  //                         if (req.body.rfcode.trim() !== '') {
  //                           newUser.temp = req.body.rfcode.trim();
  //                         }
  //                       }
  //
  //                       // set the user's local credentials
  //                       newUser.local.email = email.toLowerCase();
  //                       newUser.email.value = email;
  //                       newUser.local.isPrimary = true;
  //                       newUser.local.password = newUser.generateHash(password);
  //                       newUser.accountVerify.verificationHash = helper.getRandomToken();
  //                       newUser.accountVerify.expiresAt = constants.emailVerifyExpiry;
  //                       newUser.userState = 'USER';
  //                       newUser.accountState = 'e';
  //                       newUser.personalDetails.fullName = req.body.fullName;
  //                       newUser.contributionRange = req.body.contributionRange;
  //                       newUser.termsAccepted = req.body.termsAccepted;
  //                       newUser.isUs = req.body.isUs;
  //                       newUser.subscribe.email = email.toLowerCase();
  //                       newUser.refer.refereeEmail = refereeEmail;
  //                       newUser.refer.referee = referee;
  //                       if(!!req.query.channel) {
  //                         console.log('channel : ', req.query.channel);
  //                         newUser.refer.channel = req.query.channel;
  //                       }
  //                       // save the user
  //                       newUser.save(err => {
  //                         // eslint-disable-line no-shadow
  //                         if (err) {
  //                           throw err;
  //                         }
  //                         return done(null, newUser);
  //                       });
  //                     }
  //                   }
  //                 );
  //               }
  //             }
  //           );
  //         }
  //       });
  //     }
  //   )
  // );

  ///////////////// Investor Sigup //////////////////////////////

  passport.use(
    'investor-signup',
    new LocalStrategy(
      {
        // by default, local strategy uses username and password, we will override with email
        usernameField: 'email',
        passwordField: 'email',
        passReqToCallback: true // allows us to pass back the entire request to the callback
      },
      (req, email, password, done) => {
        password = genShortId();
        const sendVerificationMail = req.body.sendVerificationMail;

        // asynchronous
        // User.findOne wont fire unless data is sent back
        process.nextTick(() => {
          // find a user whose email is the same as the forms email
          // we are checking to see if the user trying to login already exists or subscriber
          User.findOne(
            {
              $or: [
                {
                  'local.email': email
                },
                {
                  'email.value': email
                }
              ]
            },
            (err, user) => {
              // if there are any errors, return the error
              if (err) {
                return done(err);
              }

              if (user) {
                if (user.local.email === email) {
                  //  already a user
                  user.tokens.total += !!req.body.tokensTransferred ? (req.body.tokensTransferred === true ? req.body.tokens : 0) : 0; //eslint-disable-line
                  user.tokens[req.body.phase] += !!req.body.tokensTransferred ? (req.body.tokensTransferred === true ? req.body.tokens : 0) : 0; //eslint-disable-line
                  user.save((err, user) => { //eslint-disable-line

                    if (err) {
                      throw err;
                    } else {
                      return done(null, {
                        exist: true,
                        email: req.body.email,
                        refereeId: user.refer.referee,
                        updateRefer: !!req.body.tokensTransferred ? (req.body.tokensTransferred === true ? true : false) : false, //eslint-disable-line
                        transactionHash: req.body.transactionHash || '',
                        amount: req.body.amountInvested || 0,
                        tokens: req.body.tokens || 0,
                        status: !!req.body.tokensTransferred ? (req.body.tokensTransferred === true ? 'confirmed' : 'pending') : 'pending', //eslint-disable-line
                        phase: req.body.phase || 'preSale',
                        type: req.body.type || 'Ethereum',
                        id: user._id,
                        tokensTransferred: !!req.body.tokensTransferred ? (req.body.tokensTransferred === true ? 'yes' : 'no') : 'no', //eslint-disable-line
                        bonus: req.body.bonus || 0 ,
                        discount: req.body.discount || 0,
                        isBonusOrDiscount: req.body.isBonusDiscount || 0,
                        tokenPrice: req.body.tokenPrice
                      });
                    }
                  });

                } else if (user.subscribe.email === email) {
                  // subscriber found. convert to user

                  user.local.email = email.toLowerCase();
                  user.local.password = user.generateHash(password);
                  user.accountVerify.isVerified = true;
                  user.accountVerify.verificationHash = helper.getRandomToken();
                  user.accountVerify.expiresAt = Date.now() + 1800000; //30 mins
                  user.userState = 'USER';
                  user.accountState = !!req.body.sendVerificationMail ? 'e' : 'e_v';
                  user.personalDetails.fullName = req.body.fullName;
                  user.termsAccepted = true;
                  user.isUs = true;
                  user.subscribe.email = email.toLowerCase();
                  // save the user
                  user.save(err => {// eslint-disable-line no-shadow
                    if (err) {
                      throw err;
                    }
                    if (!!sendVerificationMail) {
                      userController.sendSignupVerificationMailWillPassword({
                        email: req.body.email,
                        token: user.accountVerify.verificationHash,
                        password: password
                      });
                    } else {
                      mailer({
                        mailType: 'INVESTOR_SIGNUP',
                        to: req.body.email,
                        data: {
                          password,
                          fullName: req.body.fullName,
                          to: email
                        }
                      });
                    }

                    return done(null, user);
                  });
                } else {
                  return done(null, {
                    isError: true,
                    message: `Unknown Error${
                      responseMsgs.SIGNUP_LOCAL.EXISTING_EMAIL
                    }`
                  });
                }
              } else {
                // if there is no user with that email
                // create the user
                const newUser = new User();

                if (req.body.rfcode) {
                  if (req.body.rfcode.trim() !== '') {
                    newUser.temp = req.body.rfcode.trim();
                  }
                }

                // set the user's local credentials
                newUser.local.email = email.toLowerCase();
                newUser.email.value = email;
                newUser.local.isPrimary = true;
                newUser.local.password = newUser.generateHash(password);
                newUser.accountVerify.isVerified = sendVerificationMail ? false : true;
                newUser.accountVerify.verificationHash = helper.getRandomToken();
                newUser.accountVerify.expiresAt = Date.now() + 1800000; //30 mins
                newUser.userState = 'USER';
                newUser.accountState = 'e';
                newUser.personalDetails.fullName = req.body.fullName;
                newUser.personalDetails.saftDoc = req.body.saftDoc;
                newUser.termsAccepted = true;
                newUser.tokens[req.body.phase] = !!req.body.tokensTransferred ? ( req.body.tokensTransferred === true ? req.body.tokens  : 0 ) : 0; //eslint-disable-line
                newUser.tokens.total = !!req.body.tokensTransferred ? (req.body.tokensTransferred === true ? req.body.tokens : 0) : 0; //eslint-disable-line
                newUser.isUs = true;
                newUser.subscribe.email = email.toLowerCase();
                // save the user
                newUser.save(err => { // eslint-disable-line no-shadow

                  if (err) {
                    throw err;
                  }

                  if (!!sendVerificationMail) {
                    userController.sendSignupVerificationMailWillPassword({
                      email: req.body.email,
                      token: newUser.accountVerify.verificationHash,
                      password: password
                    });
                  } else {
                    mailer({
                      mailType: 'INVESTOR_SIGNUP',
                      to: req.body.email,
                      data: { password, fullName: req.body.fullName, to: email }
                    });
                  }

                  return done(null, {
                    email: req.body.email,
                    transactionHash: req.body.transactionHash || '',
                    amount: req.body.amountInvested || 0,
                    tokens:  req.body.tokens || 0,
                    status: !!req.body.tokensTransferred ? ( req.body.tokensTransferred === true ? 'confirmed' : 'pending' ) : 'pending', //eslint-disable-line
                    phase: req.body.phase || 'preSale',
                    type: req.body.type || 'Ethereum',
                    id: newUser._id,
                    tokensTransferred: !!req.body.tokensTransferred ? ( req.body.tokensTransferred === true ? 'yes' : 'no') : 'no', //eslint-disable-line
                    bonus: req.body.bonus || 0,
                    discount: req.body.discount || 0,
                    isBonusOrDiscount: req.body.isBonusDiscount || 0,
                    tokenPrice: req.body.tokenPrice
                  });
                });
              }
            }
          );
        });
      }
    )
  );

  passport.use(
    'local-login',
    new LocalStrategy(
      {
        // by default, local strategy uses username and password, we will override with email
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true // allows us to pass back the entire request to the callback
      },
      (req, email, password, done) => {
        // asynchronous
        // User.findOne wont fire unless data is sent back
        process.nextTick(() => {
          //let regExpEmail = `/${email}/i`;

          // find a user whose email is the same as the forms email
          // we are checking to see if the user trying to login already exists
          User.findOneAndUpdate(
            {
              $and: [
                {
                  'local.email': email.toLowerCase()
                }
              ]
            },
            {
              userIp: req.ip
            },
            (err, user) => {
              // if there are any errors, return the error
              if (err) {
                return done(err);
              }
              // check to see if theres already a user with that email
              if (user) {
                if (user.validPassword(password)) {
                  if (user.blockedAt) {
                    return done(null, {
                      isError: true,
                      message: constants.responseMsgs.LOGIN.ACC_BLOCKED //'User Account Blocked'
                    });
                  } else if (!user.accountVerify.isVerified) {
                    //!user.accountVerify.isVerified
                    return done(null, {
                      isError: true,
                      message: constants.responseMsgs.LOGIN.ACC_UNVERIFIED //'Email unverified , please check your e-mail and verify.'
                    });
                  } else {
                    const rememberMe =
                      req.body.rememberMe && req.body.rememberMe !== 'false'
                        ? true
                        : false;
                    const token = user.genAuthtoken({
                      loginType: 'LOCAL',
                      rememberMe
                    });
                    //req.is2FA_enabled = false;
                    req.token = token;
                    done(null, user);
                  }
                } else {
                  //return done(null, false);
                  return done(null, {
                    isError: true,
                    message: constants.responseMsgs.LOGIN.WRONG_EMAIL_PW //'Email and password does not match'
                  });
                }
              } else {
                //return done(null, false);
                return done(null, {
                  isError: true,
                  message: constants.responseMsgs.LOGIN.WRONG_EMAIL_PW //'Email and password does not match'
                });
              }
            }
          );
        });
      }
    )
  );

  passport.use(
    'superAdmin-local-login',
    new LocalStrategy(
      {
        // by default, local strategy uses username and password, we will override with email
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true // allows us to pass back the entire request to the callback
      },
      (req, email, password, done) => {
        // asynchronous
        // User.findOne wont fire unless data is sent back
        process.nextTick(() => {
          // find a user whose email is the same as the forms email
          // we are checking to see if the user trying to login already exists
          User.findOne(
            {
              $and: [
                {
                  'local.email': email
                },
                {
                  role: {
                    $in: ['SUPER_ADMIN', 'ADMIN']
                  }
                }
              ]
            },
            (err, user) => {
              // if there are any errors, return the error
              if (err) {
                return done(err);
              }
              // check to see if theres already a user with that email
              if (user) {
                if (user.validPassword(password)) {
                  const token = user.genAuthtoken({
                    loginType: 'LOCAL'
                  });
                  //req.is2FA_enabled = false;
                  req.token = token;
                  done(null, user);
                } else {
                  return done(null, {
                    isError: true,
                    message: constants.responseMsgs.LOGIN.WRONG_EMAIL_PW
                  });
                }
              } else {
                return done(null, {
                  isError: true,
                  message: constants.responseMsgs.LOGIN.WRONG_EMAIL_PW
                });
              }
            }
          );
        });
      }
    )
  );

  ///////////////// Facebook Signup/ login //////////////////////////////

  passport.use(
    new FacebookStrategy(
      {
        clientID: 462463444191501,
        clientSecret: '909c4adc85a7832db77b540e2375d4ae',
        callbackURL: 'http://localhost:4000/api/v1/auth/facebook/callback'
      },
      (accessToken, refreshToken, profile, cb) => {
        User.findOrCreate(
          {
            facebookId: profile.id
          },
          (err, user) => {
            return cb(err, user);
          }
        );
      }
    )
  );

  ////////////////////// END of Facebook Signup/ login //////////////////////////////

  ///////////////// Google Sigup/ login //////////////////////////////

  passport.use(
    new GoogleStrategy(
      {
        clientID: authKeys.googleAuth.clientID,
        clientSecret: authKeys.googleAuth.clientSecret,
        callbackURL: authKeys.googleAuth.callbackURL,
        passReqToCallback: true
      },
      (req, token, refreshToken, profile, done) => {
        console.log('Profile : ', profile);
        // make the code asynchronous
        // User.findOne won't fire until we have all our data back from Google
        process.nextTick(() => {
          if (!req.user) {
            // try to find the user based on their google id
            User.findOne(
              {
                $and: [
                  {
                    'google.id': profile.id
                  }
                ]
              },
              (err, user) => {
                if (err) {
                  return done(err);
                }

                if (user) {
                  if (user.blockedAt) {
                    done(null, false);
                  } else {
                    // if a user is found, log them in
                    /* let payload = {
              	loginType: "SOCIAL",
              	id: user._id,
              	userInfo:user.google
              } */
                    req.token = user.genAuthtoken({
                      loginType: 'SOCIAL'
                    });
                    return done(null, user);
                  }
                } else {
                  // if the user isnt in our database, create a new user
                  const newUser = new User();

                  if (req.cookies.pcode) {
                    newUser.temp = req.cookies.pcode;
                  }

                  // set all of the relevant information
                  newUser.google.id = profile.id;
                  newUser.google.token = token;
                  newUser.google.name = profile.displayName;
                  newUser.google.email = profile.emails[0].value; // pull the first email
                  newUser.google.isPrimary = true;
                  newUser.email.value = profile.emails[0].value;
                  // No need to verify email
                  newUser.accountVerify = {};
                  newUser.accountVerify.isVerified = true;
                  newUser.email = {};
                  newUser.email.isVerified = true;
                  newUser.email.value = profile.emails[0].value;

                  console.log('New User: ', newUser);
                  // save the user
                  newUser.save(err => {
                    // eslint-disable-line no-shadow
                    if (err) {
                      throw err;
                    }
                    req.token = newUser.genAuthtoken({
                      loginType: 'SOCIAL'
                    });
                    return done(null, newUser);
                  });
                }
              }
            );
          } else {
            const user = req.user; // pull the user out of the session

            // update the current users facebook credentials
            user.google.id = profile.id;
            user.google.token = token;
            user.google.name = profile.displayName;
            user.google.email = profile.emails[0].value; // pull the first email
            console.log('Existing user : ', user.google);

            // save the user
            user.save(err => {
              if (err) {
                throw err;
              }
              return done(null, user);
            });
          }
        });
      }
    )
  );

  ///////////////////// END of Google Signup/ login //////////////////////////////

  // verify jwt
  const opts = {};
  opts.jwtFromRequest = ExtractJwt.fromHeader('x-auth-token');
  opts.secretOrKey = presets.tokenSecret;
  opts.passReqToCallback = true;
  // opts.issuer = 'accounts.examplesoft.com';
  // opts.audience = 'yoursite.net';
  passport.use(
    new JwtStrategy(opts, (req, jwt_payload, done) => {
      const token = req.headers['x-auth-token'];

      Session.findOne({
        userId: jwt_payload.id,
        token: token
      })
        .populate('userId')
        .exec((err, user) => {
          if (err) {
            logger.error('error');
            logger.error(err);
            return done(err);
          }
          if (user) {
            return done(null, user.userId);
          } else {
            logger.debug('');
            return done(null, false);
            //next(new Error('Invalid or expired token'));
            // or you could create a new account
          }
        });
    })
  );
};
