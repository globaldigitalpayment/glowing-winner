const Path = require('path');
const AWS = require('aws-sdk');

AWS.config.loadFromPath(Path.join(__dirname,'./s3Config.json'));

const s3 = new AWS.S3();

const myBucket = 'quillhash-ico-kyc';

const myKey = 'myBucketKey';

// s3.createBucket({ Bucket: myBucket }, function (err, data) {

// 	if (err) {

// 		console.log(err);

// 	} else {
// 		console.log(data);
// 		/* params = { Bucket: myBucket, Key: myKey, Body: 'Hello!' };

// 		s3.putObject(params, function (err, data) {

// 			if (err) {

// 				console.log(err)

// 			} else {

// 				console.log("Successfully uploaded data to myBucket/myKey");

// 			}

// 		}); */

// 	}

// });

module.exports = s3;
