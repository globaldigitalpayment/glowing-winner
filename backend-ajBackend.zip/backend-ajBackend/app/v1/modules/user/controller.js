const Web3 = require('web3');
const web3 = new Web3(new Web3.providers.HttpProvider(`https://ropsten.infura.io/${process.env.INFURA_ACCESS_TOKEN}`));

const bcrypt = require('bcrypt-nodejs'),
  contractModelFunction = require('../contracts/doa'),
  request = require('request'),
  rpn = require('request-promise-native'),
  modelFunction = require('./doa'),
  mailer = require('config/nodemailer'),
  Session = require('./sessionModel'),
  helper = require('utils/helper'),
  presets = require('utils/presets'),
  errorHandler = require('utils/errorHandler'),
  constants = require('config/constants'),
  logger = require('config/logger'),
  userModel = require('./model'),
  path = require('path'),
  responseMsgs = constants.responseMsgs,
  { addNewTraxn, updateTrxnHash } = require('./../transaction/controller'),
  trxnModelFunction = require('./../transaction/doa'),
  newFile = path.join(__dirname, '../../../../keyValueFile'),
  storage = require('node-persist'),
  contractModel = require('../contracts/model'),
  {
    getAllUserLogs,
    addUpdateProfileLog,
    addUploadImageLog,
    addUploadSaftLog,
    addResetPasswordLog,
    addDepositTransactionLog,
    addTransactionHashLog,
    // addUserDepositLog,
    addSendSupportMailLog,
    // addGetUserRefersLog
  } = require('./../logs/controller'),
  //redis = require('redis'),
  userController = Object.create(null);
require('./script_createAdmin');

const ethers = require('ethers');

const { ethSmartContract } = require('./../Eth/controller');

// keep reference to redis client
// const client = redis.createClient(6379);

// client.on('ready', () => {
//   console.log('Redis is ready');
// });

// client.on('error', () => {
//   console.log('Error in Redis');
// });
//

userController.toggleIsInfoActiveGet = async (req, res, next) => {
  const dataF = {
    _id: req.user._id
  };
  try {
    const findData = await modelFunction.findOne({
      params: dataF
    });
    if(!!findData) {
      return res
        .status(200)
        .json({
          success: true,
          message: 'Successfully found',
          isInfoActive: findData.isInfoActive
        });
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'Invalid Id'
        });
    }
  }catch(err) {
    next(err);
  }

};

userController.toggleIsInfoActive = async (req, res, next) => {
  const dataF = {
    _id: req.user._id
  };
  const dataU = {
    isInfoActive: req.body.isInfoActive
  }

  try {
    const updateData = await modelFunction.findOneAndUpdate({
      query: dataF,
      params: dataU
    });
    if(!!updateData) {
      return res
        .status(200)
        .json({
          success: true,
          message: 'Successfully Updated',
          isInfoActive: req.body.isInfoActive
        });
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'Invalid Id'
        });
    }
  }catch(err) {
    next(err);
  }

};

userController.isSubscriber = ({ email }) => {
  return modelFunction.findOne({
    params: { 'subscribe.email': email },
    selector: 'subscribe'
  });
};

userController.addSubscriber = async ({ email, name, isVerify = true }) => {
  const insertObj = {
    subscribe: {
      email: email,
      name: name
    }
  };

  try {
    if (isVerify) {
      var token = await helper.getRandomToken(); // eslint-disable-line
      insertObj.subscribe.varificationHash = token;
    } else {
      insertObj.subscribe.isVerified = true;
    }
    const result = await modelFunction.create({ //eslint-disable-line
      // eslint-disable-line
      obj: {
        subscribe: { email: email, name: name, verificationHash: token },
        userState: 'SUBSCRIBER',
        email: { value: email },
        local: { email: email }
      }
    });
    mailer({ token, mailType: 'SUBSCRIBE', to: email, data: { to: email } });
  } catch (error) {
    // eslint-disable-line
  }
};

// userController.removeSubscriber = async ({ email }) => {
//   const query = { 'local.email': email, 'subscribe.email': email};
//   // console.log('query : ', query);
//   const params = { $unset: { subscribe: {}, userState: "" } };
//   // console.log('params : ', params);
//   try{
//     const user = await modelFunction.findOneAndUpdate({ query, params });
//     // console.log("user : ", user);
//     // console.log('user : ', user);
//     // return res.status(200).json({success: true, msg: 'User unsubscribed'});
//   }catch(error) {
//     // return res.status(404).json({success: false, msg: 'Invalid ID'});
//   }
// };

userController.verifySubscriber = async ({ token }) => {
  return new Promise((resolve, reject) => {
    try {
      modelFunction.findOne({
        params: { 'subscribe.verificationHash': token },
        cb: (err, result) => {
          if (err) {
            reject(err);
          }
          if (result) {
            result.subscribe.isVerified = true;
            result.subscribe.verificationHash = '';
            result.save(err => { //eslint-disable-line
              // eslint-disable-line
              if (err) {
                throw err;
              }
              resolve(result);
            });
          } else {
            reject('INVALID_TOKEN');
          }
        }
      });
    } catch (error) {
      reject(error);
    }
  });
};

const sendSignupVerificationMail = ({ email: to, token, fullName }) => {
  mailer({ mailType: 'ACC_VERIFY', to, data: { token, fullName, to } });
};
userController.sendSignupVerificationMail = sendSignupVerificationMail;

const sendSignupVerificationMailWillPassword = ({
  email: to,
  token,
  password
}) => {
  mailer({ mailType: 'ACC_VERIFY_PASS', to, data: { token, password, to } });
};
userController.sendSignupVerificationMailWillPassword = sendSignupVerificationMailWillPassword;

// const sendWhitelistMail = ({
//   email: to,
//   fullName
// }) => {
//   mailer({
//     mailType: 'WHITELIST',
//     to,
//     data: {
//       fullName,
//       to
//     }
//   });
// };
// userController.sendWhitelistMail = sendWhitelistMail;

userController.verifyAccountEmail = async ({ token }) => {
  return new Promise((resolve, reject) => {
    try {
      modelFunction.findOne({
        params: { 'accountVerify.verificationHash': token },
        cb: (err, result) => {
          if (err) {
            reject(err);
          }
          if (result) {
            const currentDate = new Date();
            //console.log(result.accountVerify.expiresAt.getTime(),currentDate.getTime());
            if (
              result.accountVerify.expiresAt.getTime() > currentDate.getTime()
            ) {
              result.accountVerify.isVerified = true;
              result.accountVerify.verificationHash = '';
              result.accountState = 'e_v';
              result.email.isVerified = true;
              result.accountVerify.expiresAt = 0;
              result.save(err => { //eslint-disable-line
                // eslint-disable-line
                if (err) {
                  throw err;
                }
                resolve(result);
              });
            } else {
              resolve({ err: 'INVALID_TOKEN' });
            }
          } else {
            resolve({ err: 'INVALID_TOKEN' });
          }
        }
      });
    } catch (error) {
      reject(error);
    }
  });
};

userController.initEmailVerification = async (req, res, next) => {
  const email = req.body.email;
  // newUser.accountVerify.verificationHash = helper.getRandomToken();
  // newUser.accountVerify.expiresAt = Date.now() + 60000; // Date.now() + (3600000*24); // 1d
  try {
    const verificationToken = helper.getRandomToken();
    const query = { 'local.email': email, 'accountVerify.isVerified': false };
    const params = {
      'accountVerify.verificationHash': verificationToken,
      'accountVerify.expiresAt': constants.emailVerifyExpiry
    };
    const user = await modelFunction.findOneAndUpdate({ query, params });
    if (!user) {
      console.log('User not found or already verified');
      return res
        .status(200)
        .json({
          success: false,
          message: 'User not found or already verified'
        });
    }
    if (user.verificationHash === '') {
      console.log('User not found or already verified 1');
      return res
        .status(200)
        .json({
          success: false,
          message: 'User not found or already verified'
        });
    }
    const userName = user.personalDetails.fullName
      ? user.personalDetails.fullName
      : '';
    sendSignupVerificationMail({
      email: email,
      token: verificationToken,
      userName
    });
    return res.status(200).json({ success: true, message: 'Email sent' });
  } catch (error) {
    // eslint-disable-line
    next(error);
  }
};

// userController.forgotPassword = async ({ email }) => {
userController.forgotPassword = async ({ email, type }) => {
  //throw new Error('error test');

  let token = helper.getRandomToken(),
    expiresAt = Date.now() + presets.resettokenExpiresAt;
  try {
    // eslint-disable-next-line no-var
    var user = await modelFunction.findOneAndUpdate({
      // eslint-disable-line
      query: { 'local.email': email },
      params: {
        $set: {
          'resetPassword.token': token,
          'resetPassword.expiresAt': expiresAt
        }
      }
    });
    if (user) {
      const userName = user.personalDetails.fullName
        ? user.personalDetails.fullName
        : '';

      mailer({
        mailType:
          type && type === 'reset'
            ? 'FORGOT_PASSSWORD_RESET'
            : 'FORGOT_PASSSWORD',
        to: email,
        data: { token, userName, to: email }
      });
    }
  } catch (error) {
    return new Error(error);
  }
  return new Promise((resolve, reject) => { // eslint-disable-line
    // eslint-disable-line
    if (user) {
      resolve(user);
    } else {
      resolve(undefined);
    }
  });
};

userController.activateLogs = async (req, res, next) => {
  let userId = req.user.id;
  const query = { _id: userId };
  let params;
  params = {
    $set: {
      saveActivityLogs: req.body.saveActivityLogs,
    }
  };

  try {
    const result = await modelFunction.findOneAndUpdate({ query, params }); // eslint-disable-line
    // console.log('result : ', result);
    return res
      .status(200)
      .json({
        success: true,
        saveActivityLogs: req.body.saveActivityLogs,
        message: 'Successfully updated'
      });
  } catch (error) {
    next(error);
  }
};

userController.updateProfile = async (req, res, next) => {
  const userId = req.user.id;
  const query = { _id: userId };
  let params;
  // const params = {
  //   $set: {
  //     personalDetails: {
  //       fullName: req.body.fullName,
  //       dob: req.body.dob,
  //       phoneNumber: req.body.phone,
  //       gender: req.body.gender,
  //       telegram: req.body.telegram,
  //       twitter: req.body.twitter,
  //       creative: req.body.creative,
  //       youtube: req.body.youtube,
  //       facebook: req.body.facebook,
  //       reddit: req.body.reddit,
  //       linkedIn: req.body.linkedIn,
  //       translation: req.body.translation,
  //       signature: req.body.signature,
  //       loginAlert: req.body.loginAlert,
  //       notifyMe: req.body.notifyMe,
  //       latestNewsAlert: req.body.latestNewsAlert
  //       ethAddress: req.body.ethAddress
  //     }
  //   }
  // };

  let resultFind;
  try {
    resultFind = await modelFunction.findOne({ params: { '_id': userId, 'kycStatus': 'ACCEPTED' } });
    // console.log('resultFind', resultFind);
  }catch(err){
    next(err);
  }

  if(!!resultFind) {
    console.log('cannot update ethAddress');
    params = {
      $set: {
        personalDetails: {
          fullName: req.body.fullName,
          dob: req.body.dob,
          phoneNumber: req.body.phone,
          gender: req.body.gender,
          telegram: req.body.telegram,
          twitter: req.body.twitter,
          creative: req.body.creative,
          youtube: req.body.youtube,
          facebook: req.body.facebook,
          reddit: req.body.reddit,
          linkedIn: req.body.linkedIn,
          translation: req.body.translation,
          signature: req.body.signature,
          loginAlert: req.body.loginAlert,
          notifyMe: req.body.notifyMe,
          latestNewsAlert: req.body.latestNewsAlert,
          ethAddress: resultFind.personalDetails.ethAddress // remains same
        }
      }
    };
  }else {
    console.log('can update ethAddress');
    params = {
      $set: {
        personalDetails: {
          fullName: req.body.fullName,
          dob: req.body.dob,
          phoneNumber: req.body.phone,
          gender: req.body.gender,
          telegram: req.body.telegram,
          twitter: req.body.twitter,
          creative: req.body.creative,
          youtube: req.body.youtube,
          facebook: req.body.facebook,
          reddit: req.body.reddit,
          linkedIn: req.body.linkedIn,
          translation: req.body.translation,
          signature: req.body.signature,
          loginAlert: req.body.loginAlert,
          notifyMe: req.body.notifyMe,
          latestNewsAlert: req.body.latestNewsAlert,
          ethAddress: req.body.ethAddress // this needs to only update if kyc is not accepted
        }
      }
    };
  }

  try {
    const result = await modelFunction.findOneAndUpdate({ query, params }); // eslint-disable-line
  } catch (error) {
    next(error);
  }
  if(!!req.user.saveActivityLogs) {
    let date = new Date();
    date = date.toISOString();
    var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
       req.connection.remoteAddress ||
       req.socket.remoteAddress ||
       req.connection.socket.remoteAddress;
    addUpdateProfileLog({ _id: req.user._id, email: req.user.email.value, updatedAt: date, ip: ip })
      .then(data => {
        console.log('Successfully store log', data);
      })
      .catch(err => {
        logger.error('addUpdateProfileLog is unable to store log');
      });
  }
  res.status(200).json({ success: true, message: 'Profile updated' });
};

userController.uploadImage = async (req, res, next) => {
  const user = req.user;
  const query = { _id: user.id };

  if (req.file) {
    const image = req.file;
    console.log(image);

    const key = `personalDetails.${image.fieldname}`;

    const params = {
      $set: {
        [key]: image.location
      }
    };
    try {
      const result = await modelFunction.findOneAndUpdate({ params, query });
      if (!result.personalDetails.imageProfile) {
        res.status(404).json({ success: false, msg: 'Something went wrong' });
      } else {
        if(!!req.user.saveActivityLogs) {
          var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
             req.connection.remoteAddress ||
             req.socket.remoteAddress ||
             req.connection.socket.remoteAddress;
          let date = new Date();
          date = date.toISOString();
          addUploadImageLog({ _id: req.user._id, email: req.user.email.value, imageUri: image.location ,uploadedAt: date, ip: ip })
            .then(data => {
              console.log('Successfully store log', data);
            })
            .catch(err => {
              logger.error('addUploadImageLog is unable to store log');
            });
        }
        res
          .status(200)
          .json({
            success: true,
            allUploaded: true,
            image: image.fieldname,
            imageUrl: image.location
          });
      }
    } catch (err) {
      next(Boom.badImplementation(err));
    }
  } else {
    res.status(404).json({ success: false, msg: 'No image found' });
  }
};

userController.uploadSaftDoc = async (req, res, next) => {
  const user = req.user;
  const query = { _id: user.id };

  if (req.file) {
    const image = req.file;
    console.log(image);

    const key = `personalDetails.${image.fieldname}`;

    const params = {
      $set: {
        [key]: image.location
      }
    };
    return res
      .status(200)
      .json({
        success: true,
        allUploaded: true,
        image: image.fieldname,
        imageUrl: image.location
      });
    // try {
    //   const result = await modelFunction.findOneAndUpdate({ params, query });
    //   if (!result.personalDetails.saftDoc) {
    //     res.status(404).json({ success: false, msg: 'Something went wrong' });
    //   } else {
    //     if(!!req.user.saveActivityLogs) {
    //       var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
    //          req.connection.remoteAddress ||
    //          req.socket.remoteAddress ||
    //          req.connection.socket.remoteAddress;
    //       let date = new Date();
    //       date = date.toISOString();
    //       addUploadSaftLog({ _id: req.user._id, email: req.user.email.value, imageUri: image.location ,uploadedAt: date, ip: ip })
    //         .then(data => {
    //           console.log('Successfully store log', data);
    //         })
    //         .catch(err => {
    //           logger.error('addUploadSaftLog is unable to store log');
    //         });
    //     }
    //     res
    //       .status(200)
    //       .json({
    //         success: true,
    //         allUploaded: true,
    //         image: image.fieldname,
    //         imageUrl: image.location
    //       });
    //   }
    // } catch (err) {
    //   next(Boom.badImplementation(err));
    // }
  } else {
    res.status(404).json({ success: false, msg: 'No Document found' });
  }
};

userController.userDeposit = async (req, res, next) => {
  await storage.init({
    dir: newFile,
    stringify: JSON.stringify,
    parse: JSON.parse,
    encoding: 'utf8',
    logging: false,
    ttl: false,
    expiredInterval: 2 * 60 * 1000,
    forgiveParseErrors: false
  });
  const staticSale = await storage.getItem('static');
  if (staticSale) { // if working properly
  // if (true) {
    const mainOptions = {
      json: true // Automatically parses the JSON string in the response
    };
    let btcReqOpt1 = Object.assign({}, mainOptions);
    btcReqOpt1.uri = 'https://api.kraken.com/0/public/Ticker?pair=XXBTZUSD';
    let btcAddress = await storage.getItem('btcAddress');
    let ethAddress = await storage.getItem('staticEthAddress');
    let usdtAddress = await storage.getItem('staticUSDTAddress');
    let ethReqOpt1 = Object.assign({}, mainOptions);
    ethReqOpt1.uri = 'https://api.kraken.com/0/public/Ticker?pair=XETHZUSD';
    let usdtReqOpt1 = Object.assign({}, mainOptions);
    usdtReqOpt1.uri = 'https://api.kraken.com/0/public/Ticker?pair=USDTZUSD';

    Promise.all([rpn(btcReqOpt1), rpn(ethReqOpt1), rpn(usdtReqOpt1)])
      .then(async results => {
        //console.log('results : ', results);
        const data = {};
        // @aj
        let staticDiscount, tokenUsd, isBonusOrDiscount;
        staticDiscount = await storage.getItem('staticDiscount');
        isBonusOrDiscount = await storage.getItem('isBonusOrDiscount');
        //console.log('isBonusOrDiscount : ', isBonusOrDiscount);
        tokenUsd = await storage.getItem('staticTokenUsd');
        // if(!!staticDiscount) {
        if(isBonusOrDiscount === 'staticDiscount') { // If latest updated value is of staticDiscount
          data.staticDiscount = staticDiscount;
          data.tokenUsd = tokenUsd;
          // data.tokenUsdAfterStaticDiscount = tokenUsd - (tokenUsd * ( staticDiscount / 100));
          //console.log('tokenUsd : ', data.tokenUsd);
        } else { // If latest updated value is of staticBonus
          data.tokenUsd = tokenUsd;
          //console.log('tokenUsd : ', data.tokenUsd);
        }
        data.isBonusOrDiscount = isBonusOrDiscount;
        // ---@aj
        data.ethAddress = ethAddress;
        data.btcAddress = btcAddress;
        data.usdtAddress = await storage.getItem('staticUSDTAddress');
        // data.tokenUsd = await storage.getItem('staticTokenUsd');
        data.btcUsd = !!Math.round(results[0].result.XXBTZUSD.c[0]) ? Math.round(results[0].result.XXBTZUSD.c[0]): await storage.getItem('staticBtcUsd');
        data.ethUsd = !!Math.round(results[1].result.XETHZUSD.a[0])? Math.round(results[1].result.XETHZUSD.a[0]) : await storage.getItem('staticEthUsd');
        data.usdtUsd = !!Math.round(results[2].result.USDTZUSD.a[0])? Math.round(results[2].result.USDTZUSD.a[0]) : await storage.getItem('staticUsdtUsd');
        data.stage = await storage.getItem('staticStage');
        data.bonus = await storage.getItem('staticBonus');

        data.tokenPerEther =
          Math.round(results[1].result.XETHZUSD.a[0]) /
          await storage.getItem('staticTokenUsd');
        data.tokenPerBtc =
          Math.round(results[0].result.XXBTZUSD.c[0]) /
          await storage.getItem('staticTokenUsd');
        data.tokenPerUsdt =
          Math.round(results[2].result.USDTZUSD.a[0]) /
          await storage.getItem('staticTokenUsd');
        data.minInvest = await storage.getItem('staticMinInvest');
        if(!!Math.round(results[0].result.XXBTZUSD.c[0])) {
          await storage.setItem('staticBtcUsd',Math.round(results[0].result.XXBTZUSD.c[0]));
        }
        if(!!Math.round(results[1].result.XETHZUSD.a[0])) {
          await storage.setItem('staticEthUsd',Math.round(results[1].result.XETHZUSD.a[0]));
        }
        if(!!Math.round(results[2].result.USDTZUSD.a[0])) {
          await storage.setItem('staticUsdtUsd',Math.round(results[2].result.USDTZUSD.a[0]));
        }
        return res.status(200).json({ data: data, success: true });
      })
      .catch(err => {
        logger.error('Unable to fetch live price trxn =>', err, '. Now switching to other live');
        let btcReqOpt2 = Object.assign({}, mainOptions);
        btcReqOpt2.uri = 'https://apiv2.bitcoinaverage.com/convert/global?from=BTC&to=USD';
        let ethReqOpt2 = Object.assign({}, mainOptions);
        ethReqOpt2.uri = 'https://apiv2.bitcoinaverage.com/convert/global?from=ETH&to=USD';
        let btcAddress = storage.getItem('btcAddress');
        let ethAddress = storage.getItem('staticEthAddress');
        let usdtAddress = storage.getItem('staticUSDTAddress');
        let usdtReqOpt2 = Object.assign({}, mainOptions);
        usdtReqOpt2.uri = 'https://apiv2.bitcoinaverage.com/crypto/chart/local/USDT-USD?period=hour';

        Promise.all([rpn(btcReqOpt2), rpn(ethReqOpt2), rpn(usdtReqOpt2)])
          .then(async results => {
            console.log('results : ', results);
            const data = {};
            // @aj
            let staticDiscount, tokenUsd, isBonusOrDiscount;
            staticDiscount = await storage.getItem('staticDiscount');
            tokenUsd = await storage.getItem('staticTokenUsd');
            isBonusOrDiscount = await storage.getItem('isBonusOrDiscount');
            //console.log('isBonusOrDiscount : ', isBonusOrDiscount);
            // if(!!discount) {
            if(isBonusOrDiscount === 'staticDiscount') { // If latest updated value is of staticDiscount
              data.staticDiscount = staticDiscount;
              data.tokenUsd = tokenUsd;
              // data.tokenUsdAfterStaticDiscount = tokenUsd - (tokenUsd * ( staticDiscount / 100));
              //console.log('tokenUsd : ', data.tokenUsd);
            } else { // If latest updated value is of staticBonus
              data.tokenUsd = tokenUsd;
              //console.log('tokenUsd : ', data.tokenUsd);
            }
            data.isBonusOrDiscount = isBonusOrDiscount;
            // ---@aj
            data.ethAddress = ethAddress;
            data.btcAddress = btcAddress;
            data.usdtAddress = await storage.getItem('staticUSDTAddress');
            data.tokenUsd = await storage.getItem('staticTokenUsd');
            data.btcUsd = !!Math.round(results[0].result.XXBTZUSD.c[0]) ? Math.round(results[0].result.XXBTZUSD.c[0]): await storage.getItem('staticBtcUsd');
            data.ethUsd = !!Math.round(results[1].result.XETHZUSD.a[0])? Math.round(results[1].result.XETHZUSD.a[0]) : await storage.getItem('staticEthUsd');
            data.UsdtUsd = !!Math.round(results[2][0].price)? Math.round(results[2][0].price) : await storage.getItem('staticUsdtUsd');
            data.stage = await storage.getItem('staticStage');
            data.bonus = await storage.getItem('staticBonus');
            data.tokenPerEther =
              Math.round(results[1].result.XETHZUSD.a[0]) /
              await storage.getItem('staticTokenUsd');
            data.tokenPerBtc =
              Math.round(results[0].result.XXBTZUSD.c[0]) /
              await storage.getItem('staticTokenUsd');
            data.tokenPerUsdt =
              Math.round(results[2][0].price) /
              await storage.getItem('staticTokenUsd');
            data.minInvest = await storage.getItem('staticMinInvest');
            if(!!Math.round(results[0].result.XXBTZUSD.c[0])) {
              await storage.setItem('staticBtcUsd',Math.round(results[0].result.XXBTZUSD.c[0]));
            }
            if(!!Math.round(results[1].result.XETHZUSD.a[0])) {
              await storage.setItem('staticEthUsd',Math.round(results[1].result.XETHZUSD.a[0]));
            }
            if(!!Math.round(results[2][0].price)) {
              await storage.setItem('staticUsdtUsd',Math.round(results[2][0].price));
            }
            return res.status(200).json({ data: data, success: true });
          })
          .catch(err => {
            logger.error('Unable to fetch live price trxn => second time => ', err,);
            return res.status(200).json({ message: 'failed', status: false });
          });
      });
  } else {
    const mainOptions = {
      json: true // Automatically parses the JSON string in the response
    };
    let btcReqOpt1 = Object.assign({}, mainOptions);
    btcReqOpt1.uri = 'https://api.kraken.com/0/public/Ticker?pair=XXBTZUSD';
    let btcAddress = storage.getItem('btcAddress');
    let ethAddress = storage.getItem('crowdsaleAddress');
    let usdtAddress = storage.getItem('staticUSDTAddress');
    Promise.all([rpn(btcReqOpt1), ethSmartContract()])
      .then(results => {
        //console.log('results else : ', results[1]);
        const data = {};
        data.isBonusOrDiscount = 'discount';
        data.ethAddress = ethAddress;
        data.btcAddress = btcAddress;
        data.usdtAddress = storage.getItem('staticUSDTAddress');
        data.tokenUsd =  results[1].tokenPrice || 0.1;
        data.btcUsd = Math.round(results[0].result.XXBTZUSD.c[0]);
        data.ethUsd = Math.round(results[1].rate / 100);
        data.stage = results[1].stage || 'Private sale Round one';
        data.tokenPerEther = results[1].tokensAmount * data.ethUsd;
        data.tokenPerBtc = results[1].tokensAmount * data.btcUsd;
        data.bonus = parseInt(results[1].bonus) || 0;
        // Added discount
        data.discount = parseInt(results[1].discount) || 0;
        data.minInvest = results[1].minInvest;
        return res.status(200).json({ data: data, success: true });
      })
      .catch(err => {
        logger.error('Unable to fetch live price trxn =>', err, '. Now switching to other live');
        let btcReqOpt2 = Object.assign({}, mainOptions);
        btcReqOpt2.uri = 'https://apiv2.bitcoinaverage.com/convert/global?from=BTC&to=USD';
        let btcAddress = storage.getItem('btcAddress');
        let ethAddress = storage.getItem('crowdsaleAddress');
        let usdtAddress = storage.getItem('staticUSDTAddress');
        Promise.all([rpn(btcReqOpt2), ethSmartContract()])
          .then(results => {
            //console.log('results : ', results);
            const dataC = {};
            data.isBonusOrDiscount = 'discount';
            dataC.ethAddress = ethAddress;
            dataC.usdtAddress = storage.getItem('staticUSDTAddress');
            dataC.btcAddress = btcAddress;
            dataC.tokenUsd =  results[1].tokenPrice || 0.1;
            dataC.btcUsd = Math.round(results[0].result.XXBTZUSD.c[0]);
            dataC.ethUsd = Math.round(results[1].rate / 100);
            dataC.stage = results[1].stage || 'Private sale Round one';
            dataC.tokenPerEther = results[1].tokensAmount * data.ethUsd;
            dataC.tokenPerBtc = results[1].tokensAmount * data.btcUsd;
            dataC.bonus = parseInt(results[1].bonus) || 0;
            // Added discount
            data.discount = parseInt(results[1].discount) || 0;
            dataC.minInvest = results[1].minInvest;
            return res.status(200).json({ data: dataC, success: true });
          })
          .catch(err => {
            logger.error('Unable to fetch live price trxn => Second Time =>', err);
            // console.log(err);
            return res.status(200).json({ message: 'failed', status: false , success : false });
          });
    });
  }
};

// userController.userDeposit = async (req, res, next) => {
//   await storage.init({
//     dir: newFile,
//
//     stringify: JSON.stringify,
//
//     parse: JSON.parse,
//
//     encoding: 'utf8',
//
//     logging: false, // can also be custom logging function
//
//     ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS
//
//     expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache
//
//     // in some cases, you (or some other service) might add non-valid storage files to your
//     // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
//     forgiveParseErrors: false
//   });
//   const staticSale = await storage.getItem('static');
//
//   if (staticSale) {
//     // console.log(client.get('btcUsd'));
//     // console.log(client.get('ethUsd'));
//
//     const mainOptions = {
//       json: true // Automatically parses the JSON string in the response
//     };
//     const btcReqOpt = Object.assign({}, mainOptions);
//     btcReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=XXBTZUSD';
//
//     //let eurPrice = '';
//     const btcAddress = await storage.getItem('btcAddress');
//     const ethAddress = await storage.getItem('staticEthAddress');
//
//     // await request.get(
//     //   'https://api.exchangeratesapi.io/latest',
//     //   (err, response, result) => {
//     //     if (err) {
//     //       console.log('Unable to fetch live eur price');
//     //     }
//     //     if (result) {
//     //       eurPrice = JSON.parse(result).rates.USD;
//     //     }
//     //   }
//     // );
//     const ethReqOpt = Object.assign({}, mainOptions);
//     ethReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=XETHZUSD';
//
//     Promise.all([rpn(btcReqOpt), rpn(ethReqOpt)])
//       .then(async results => {
//         //if (results[0].error.length && results[1].success) {
//         // client.set('btcUsd', Math.round(results[0].price), 'EX', 600);
//         // client.set('ethUsd', Math.round(results[1].price), 'EX', 600);
//         console.log('result0 : ', results[0]);
//         console.log('result0 : ', results[0]);
//         const data = {};
//         data.ethAddress = ethAddress;
//         data.btcAddress = btcAddress;
//         data.tokenUsd = await storage.getItem('staticTokenUsd');
//         data.btcUsd = !!Math.round(results[0].result.XXBTZUSD.c[0]) ? Math.round(results[0].result.XXBTZUSD.c[0]): await storage.getItem('staticBtcUsd');
//         data.ethUsd = !!Math.round(results[1].result.XETHZUSD.a[0])? Math.round(results[1].result.XETHZUSD.a[0]) : await storage.getItem('staticEthUsd');
//         data.stage = await storage.getItem('staticStage');
//         data.bonus = await storage.getItem('staticBonus');
//         data.tokenPerEther =
//           Math.round(results[1].result.XETHZUSD.a[0]) /
//           await storage.getItem('staticTokenUsd');
//         data.tokenPerBtc =
//           Math.round(results[0].result.XXBTZUSD.c[0]) /
//           await storage.getItem('staticTokenUsd');
//         // resData.data.bonus = results[1].bonus;
//         data.minInvest = await storage.getItem('staticMinInvest');
//         //data.eurUsd = eurPrice;
//
//         if(!!Math.round(results[0].result.XXBTZUSD.c[0])) {
//
//           await storage.setItem('staticBtcUsd',Math.round(results[0].result.XXBTZUSD.c[0]));
//
//         }
//
//         if(!!Math.round(results[1].result.XETHZUSD.a[0])) {
//           await storage.setItem('staticEthUsd',Math.round(results[1].result.XETHZUSD.a[0]));
//         }
//         // if(!!req.user.saveActivityLogs) {
//         //   let date = new Date();
//         //   date = date.toISOString();
//         //   addUserDepositLog({ _id: req.user._id, email: req.user.email.value, data: data, submittedAt: date })
//         //     .then(resultData => {
//         //       console.log('Successfully store log', resultData);
//         //     })
//         //     .catch(err => {
//         //       logger.error('addUserDepositLog is unable to store log');
//         //     });
//         // }
//         return res.status(200).json({ data: data, success: true });
//       })
//       .catch(err => {
//         logger.error('Unable to fetch live price trxn =>', err);
//         return res.status(200).json({ message: 'failed', status: false });
//       });
//   } else {
//
//     const mainOptions = {
//       json: true // Automatically parses the JSON string in the response
//     };
//     const btcReqOpt = Object.assign({}, mainOptions);
//     btcReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=XXBTZUSD';
//
//     //let eurPrice = '';
//     const btcAddress = await storage.getItem('btcAddress');
//     const ethAddress = await storage.getItem('crowdsaleAddress');
//
//     // await request.get(
//     //   'https://api.exchangeratesapi.io/latest',
//     //   (err, response, result) => {
//     //     if (err) {
//     //       console.log('Unable to fetch live eur price');
//     //     }
//     //     if (result) {
//     //       eurPrice = JSON.parse(result).rates.USD;
//     //     }
//     //   }
//     // );
//     Promise.all([rpn(btcReqOpt), ethSmartContract()])
//       .then(results => {
//         //if (results[0].error.length && results[1].success) {
//         // client.set('btcUsd', Math.round(results[0].price), 'EX', 600);
//         // client.set('ethUsd', Math.round(results[1].price), 'EX', 600);
//         const data = {};
//         data.ethAddress = ethAddress;
//         data.btcAddress = btcAddress;
//         data.tokenUsd =  results[1].tokenPrice || 0.1;
//         data.btcUsd = Math.round(results[0].result.XXBTZUSD.c[0]);
//         data.ethUsd = Math.round(results[1].rate / 100);
//         data.stage = results[1].stage || 'Private sale Round one';
//         data.tokenPerEther = results[1].tokensAmount * data.ethUsd;
//         data.tokenPerBtc = results[1].tokensAmount * data.btcUsd;
//         data.bonus = parseInt(results[1].bonus) || 0;
//         data.minInvest = results[1].minInvest;
//         //data.eurUsd = eurPrice;
//         // console.log(data);
//         // if(!!req.user.saveActivityLogs) {
//         //   let date = new Date();
//         //   date = date.toISOString();
//         //   addUserDepositLog({ _id: req.user._id, email: req.user.email.value, data: data, submittedAt: date })
//         //     .then(resultData => {
//         //       console.log('Successfully store log', resultData);
//         //     })
//         //     .catch(err => {
//         //       logger.error('addUserDepositLog is unable to store log');
//         //     });
//         // }
//         return res.status(200).json({ data: data, success: true });
//       })
//       .catch(err => {
//         logger.error('Unable to fetch live price trxn =>', err);
//         console.log(err);
//         return res.status(200).json({ message: 'failed', status: false , success : false });
//       });
//   }
// };

// userController.userDeposit = (req, res, next) => {
//   let resData = {
//     success: true,
//     message: 'Live Prices and Addresses received',
//     data: constants.ico
//   };
//   // console.log(client.get('btcUsd'));
//   // console.log(client.get('ethUsd'));

//   const mainOptions = {
//     json: true // Automatically parses the JSON string in the response
//   };
//   const btcReqOpt = Object.assign({}, mainOptions);
//   btcReqOpt.uri = 'https://apiv2.bitcoinaverage.com/convert/global?from=BTC&to=USD';
//   const ethReqOpt = Object.assign({}, mainOptions);
//   ethReqOpt.uri = 'https://apiv2.bitcoinaverage.com/convert/global?from=ETH&to=USD';

//   Promise.all([rpn(btcReqOpt), rpn(ethReqOpt)]).then((results) => {
//     if (results[0].success && results[1].success) {
//       // client.set('btcUsd', Math.round(results[0].price), 'EX', 600);
//       // client.set('ethUsd', Math.round(results[1].price), 'EX', 600);
//       resData.data.btcUsd = Math.round(results[0].price);
//       resData.data.ethUsd = Math.round(results[1].price);
//     }
//     return res.status(200).json(resData);
//   }).catch((err) => {
//     logger.error('Unable to fetch live price trxn =>', err);
//     return res.status(200).json(resData);
//   });

// };

userController.changePasswordThroughToken = async (req, res, next) => {
  //console.log('body', req.body);
  let token = req.params.token,
    newPassword = getPasswordHash(req.body.newPassword); // eslint-disable-line
  // check if valid token
  let query = {
      'resetPassword.token': token,
      'resetPassword.expiresAt': { $gte: Date.now() }
    },
    params = {
      'local.password': newPassword,
      'resetPassword.token': '',
      'resetPassword.expiresAt': 0
    };
  if (req.body.reset && req.body.reset === '1') {
    //console.log('i m here');
    params.forcereset = { oldUser: false };
  }

  try {
    var userResult = await modelFunction.findOne({ params: query }); // eslint-disable-line
    if (userResult) {
      if (userResult.validPassword(req.body.newPassword)) {
        const { status, message, description } = errorHandler({
          errorType: '',
          message: responseMsgs.RESET_PW_WITH_TOKEN.REPEATED_PW,
          description: ''
        });
        return res
          .status(status)
          .json({ success: false, message, description });
      }
    } else {
      const { status, message, description } = errorHandler({
        errorType: '',
        message: responseMsgs.RESET_PW_WITH_TOKEN.INVALID_TOKEN,
        description: ''
      });
      return res.status(status).json({ success: false, message, description });
    }
    var result = await modelFunction.findOneAndUpdate({ query, params }); // eslint-disable-line
  } catch (error) {
    next(error);
  }

  if (result) {
    const userName = result.personalDetails.fullName
      ? result.personalDetails.fullName
      : '';
    mailer({
      mailType: 'AFTER_PASSWORD_CHANGE',
      to: result.email.value,
      data: { userName, to: result.email.value }
    });
    //mailer({ mailType: 'FORGOT_PASSSWORD', to: email,data:{ token,userName } });
    res
      .status(200)
      .json({
        success: true,
        message: responseMsgs.RESET_PW_WITH_TOKEN.SUCCESS
      });
  } else {
    const { status, message, description } = errorHandler({
      errorType: '',
      message: responseMsgs.UNKNOWN_ERR,
      description: ''
    });
    return res.status(status).json({ success: false, message, description });
  }
};

userController.resetPassword = async (req, res, next) => {
  let oldPassword = req.body.oldPassword,
    newPassword = req.body.newPassword;
  if (!req.user.local.email) {
    const { status, message, description } = errorHandler({
      errorType: '',
      message: 'Request Not valid',
      description: ''
    });
    res.status(status).json({ success: false, message, description });
    //return next(new Error('Request Not valid'));
  }
  const email = req.user.local.email;
  try {
    // eslint-disable-next-line no-var
    var user = await modelFunction.findOne({
      params: { 'local.email': email },
      selector: 'local personalDetails'
    }); // eslint-disable-line
  } catch (error) {
    return next(error);
  }
  if (!user) {
    const { status, message, description } = errorHandler({
      errorType: '',
      message: 'Request Not valid',
      description: ''
    });
    return res.status(status).json({ success: false, message, description });
    //return next(new Error('Request Not valid'));
  } else if (!user.validPassword(oldPassword)) {
    const { status, message, description } = errorHandler({
      errorType: '',
      message: 'Incorrect old Password',
      description: ''
    });
    return res.status(status).json({ success: false, message, description });
    //return next(new Error('Incorrect old Password'));
  } else if (user.validPassword(newPassword)) {
    const { status, message, description } = errorHandler({
      errorType: '',
      message: responseMsgs.RESET_PW_WITH_OLD_PW.REPEATED_PW,
      description: ''
    });
    return res.status(status).json({ success: false, message, description });
  }
  user.local.password = user.generateHash(newPassword);
  user.save(err => {
    if (err) {
      console.log(err);
      throw err;
    }
    Session.removeSession({ id: user._id, removeAll: true });
    const token = user.genAuthtoken({ loginType: req.user.loginType });
    const userName = user.personalDetails.fullName
      ? user.personalDetails.fullName
      : '';
    mailer({
      mailType: 'AFTER_PASSWORD_CHANGE',
      to: user.local.email,
      data: { userName, to: user.local.email }
    });
    if(!!req.user.saveActivityLogs) {
      var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
       req.connection.remoteAddress ||
       req.socket.remoteAddress ||
       req.connection.socket.remoteAddress;
      let date = new Date();
      date = date.toISOString();
      addResetPasswordLog({ _id: req.user._id, email: req.user.email.value, submittedAt: date, ip: ip })
        .then(data => {
          console.log('Successfully store log', data);
        })
        .catch(err => {
          logger.error('addResetPasswordLog is unable to store log');
        });
    }
    res
      .status(200)
      .json({
        success: true,
        newAuthToken: token,
        message: responseMsgs.RESET_PW_WITH_OLD_PW.SUCCESS
      });
  });
  //let newPassword = getPasswordHash(req.body.newPassword);
};
// eslint-disable-next-line no-var
var getPasswordHash = password => {
  // eslint-disable-line
  return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

userController.logout = (req, res, next) => {
  const userId = req.user.id;
  const token = req.headers['x-auth-token'];
  Session.removeSession({ id: userId, token, removeAll: false });
  res.status(200).json({ success: true, message: 'User logout successfull' });
};

userController.deleteUser = (req, res, next) => {
  const userId = req.user.id;
  //console.log('userId : ', userId);
  try {
    const result = modelFunction.deleteUser({ _id: userId }); //eslint-disable-line
  } catch (err) {
    next(err);
  }
  res.status(200).json({ success: true, message: 'Sucessfully deleted' });
};

userController.addTransactionForDeposit = async (req, res, next) => {
  await storage.init({
    dir: newFile,

    stringify: JSON.stringify,

    parse: JSON.parse,

    encoding: 'utf8',

    logging: false,  // can also be custom logging function

    ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

    expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

    // in some cases, you (or some other service) might add non-valid storage files to your
    // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
    forgiveParseErrors: false

  });
  const userId = req.user.id,
    userEmail = req.user.local.email;
  console.log(userId, 'user id');
  let trxnRecord = false;
  try {
    let bonus, discount;
    if(!!req.body.bonus) {
      bonus = req.body.bonus;
    }else {
      bonus = 0;
    }

    if(!!req.body.discount) {
      discount = req.body.discount;
    }else {
      discount = 0;
    }

    trxnRecord = await addNewTraxn({
      userId: req.user.id,
      creatorId: req.user.id,
      creatorEmail: req.user.local.email,
      tokens: req.body.tokens, // tokens after bonus
      type: req.body.type, //vote/refer or btc/eth/usd
      fromAddress: req.body.fromAddress, // btc/eth address
      toAddress: req.body.toAddress, // private sale address
      tokenReceivingAddress: req.body.tokenReceivingAddress,
      usdAmount: req.body.usdAmount,
      amount: req.body.amount,
      rate: req.body.type === 'USD' ? 0 : req.body.rate,
      phase: req.body.phase,
      bonus: bonus,
      discount: discount,
      tokenPrice: req.body.tokenPrice,
      transactionHash : req.body.transactionHash,
      isBonusOrDiscount : req.body.isBonusOrDiscount,
      referBonus: await storage.getItem('amountPercent'),
    });
  } catch (error) {
    next(error);
  }

  if (!trxnRecord) {
    logger.error('Unable to record trxn =>', {
      userId,
      tokens: 0,
      creatorId: userId,
      creatorEmail: userEmail
    });
    return next(new Error('please try again'));
  }

  mailer({
    mailType: 'AFTER_DEPOSIT',
    to: constants.depositEmail,
    data: {
      to: constants.depositEmail,
      userId: req.user.id,
      creatorEmail: req.user.local.email,
      tokens: req.body.tokens, // tokens after bonus
      type: req.body.type, //vote/refer or btc/eth/usd
      fromAddress: req.body.fromAddress, // btc/eth address
      toAddress: req.body.toAddress, // private sale address
      tokenReceivingAddress: req.body.tokenReceivingAddress,
      usdAmount: req.body.usdAmount,
      amount: req.body.amount // amount in eth or usd

    }
  });

  mailer({
    mailType: 'AFTER_DEPOSIT',
    to: userEmail,
    data: {
      to: userEmail,
      userId: req.user.id,
      creatorEmail: req.user.local.email,
      tokens: req.body.tokens, // tokens after bonus
      type: req.body.type, //vote/refer or btc/eth/usd
      fromAddress: req.body.fromAddress, // btc/eth address
      toAddress: req.body.toAddress, // private sale address
      tokenReceivingAddress: req.body.tokenReceivingAddress,
      usdAmount: req.body.usdAmount,
      amount: req.body.amount // amount in eth or usd

    }
  });

  if(!!req.user.saveActivityLogs) {
    var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
      req.connection.remoteAddress ||
      req.socket.remoteAddress ||
      req.connection.socket.remoteAddress;
    let date = new Date();
    date = date.toISOString();
    addDepositTransactionLog({ _id: req.user._id, email: req.user.email.value, transactionId: trxnRecord._id, submittedAt: date, ip: ip })
      .then(data => {
        console.log('Successfully store log', data);
      })
      .catch(err => {
        logger.error('addDepositTransactionLog is unable to store log');
      });
  }

  res
    .status(200)
    .json({
      success: true,
      transactionId: trxnRecord._id,
      message: 'Transaction Completed for deposit'
    });
};

userController.addTransactionHash = async (req, res, next) => {
  const trxnId = req.body.transactionId,
    trxnHash = req.body.transactionHash;
  let trxnUpdateResult;
  try {
    trxnUpdateResult = await updateTrxnHash({ trxnId, trxnHash });
  } catch (error) {
    next(error);
  }
  if (trxnUpdateResult) {
    if(!!req.user.saveActivityLogs) {
      var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
       req.connection.remoteAddress ||
       req.socket.remoteAddress ||
       req.connection.socket.remoteAddress;
      let date = new Date();
      date = date.toISOString();
      addTransactionHashLog({ _id: req.user._id, email: req.user.email.value, transactionId: req.body.transactionId, submittedAt: date, ip: ip })
        .then(data => {
          console.log('Successfully store log', data);
        })
        .catch(err => {
          logger.error('addTransactionHashLog is unable to store log');
        });
    }
    res
      .status(200)
      .json({ success: true, message: 'Transaction Hash updated' });
  } else {
    res
      .status(200)
      .json({ success: false, message: 'Transaction Hash update failed' });
  }
};

userController.support = (req, res, next) => {
  try {
    // const topic = req.body.topic,
    //   msg = req.body.message,
    //   email = req.user.local.email;
    let to = null; //eslint-disable-line
    if (req.user.role === 'USER') {
      to = 'hello@quillhash.com';
    } else if (req.user.role === 'ADMIN' || req.user.role === 'SUPER_ADMIN') {
      to = 'nick@rama.email';
    }
    // mailer({
    //   mailType: 'USER_SUPPORT',
    //   to,
    //   data: {
    //     topic,
    //     msg,
    //     email
    //   }
    // });
    if(!!req.user.saveActivityLogs) {
      var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
       req.connection.remoteAddress ||
       req.socket.remoteAddress ||
       req.connection.socket.remoteAddress;
      let date = new Date();
      date = date.toISOString();
      addSendSupportMailLog({ _id: req.user._id, email: req.user.email.value, topic: req.body.topic, submittedAt: date, ip: ip })
        .then(resultData => {
          console.log('Successfully store log', resultData);
        })
        .catch(err => {
          logger.error('addSendSupportMailLog is unable to store log');
        });
    }
    res
      .status(200)
      .json({ success: true, message: 'Our team will respond to you soon.' });
  } catch (err) {
    console.log(err);
    res.status(200).json({ success: false, message: 'Something went wrong.' });
  }
};

userController.getUserRefers = async (req, res, next) => {
  try {
    const result = await modelFunction.find({
      params: { 'refer.referee': req.user._id },
      selector: { 'created_at': 1, 'local.email': 1, 'refer.channel': 1 }
    });

    const results = result.map(async element => {
      //console.log(element._id);
      const txParams = {
        userId: element._id
      };
      const sort = {
        'created_at': -1
      };
      const transactions = await trxnModelFunction.find({
        params: txParams,
        sort: sort,
        selector: {
          'created_at': 1,
          'status': 1,
          'tokens': 1,
          '_id': 0,
          'bonus' : 1,
          'referBonus': 1,
          'initiatedBy.email': 1,
          'refer': 1
        }
      });
      console.log(transactions);
      return transactions;
    });

    Promise.all(results).then(resp => {
      const data = {};
      data.success = true;
      data.users = result;
      data.transactions = resp;
      // if(!!req.user.saveActivityLogs) {
      //   let date = new Date();
      //   date = date.toISOString();
      //   addGetUserRefersLog({ _id: req.user._id, email: req.user.email.value, data: data, submittedAt: date })
      //     .then(resultData => {
      //       console.log('Successfully store log', resultData);
      //     })
      //     .catch(err => {
      //       logger.error('addGetUserRefersLog is unable to store log');
      //     });
      // }
      res.json(data).status(200);
    });

    console.log(result, 'result');
  } catch (error) {
    res
      .status(200)
      .json({ success: false, message: 'Something went wrong.', error });
  }
};

/* const loginLog = ({ userId, ip }) => {

  const data = {
    $push: {
      loginHistory: {
        ip
      }
    }
  };
  return modelFunction.findByIdAndUpdate({ id: userId, data });
}; */

const loginLog = ({ userId }) => {
  const data = {
    // $set: {
    //   //loginAt : new Date()
    // }
    $currentDate: { loginAt: { $type: 'date' } }
  };
  return modelFunction.findByIdAndUpdate({ id: userId, data });
};

userController.addLoginLog = loginLog;

userController.aggregateUsersDateWise = async (req, res, next) => {
  try {
    const findData = await userModel.aggregate([
      {
        $match : {
          role: 'USER'
        }
      },
      {
        $group: {
          _id : {
            month: { $month: '$created_at' },
            day: { $dayOfMonth: '$created_at' },
            year: { $year: '$created_at' }
          },
          countRefer: { $sum:
            {
              $cond: [
                { $and: [
                  { $eq: [ '$refer.referee', null ] }
                ] },
                0, 1 ]
            }
          },
          countUser: { $sum:
            {
              $cond: [
                { $and: [
                  { $eq: [ '$refer.referee', null ] }
                ] },
                1, 0
              ]
            }
          }
        }
      }
    ]);

    if(!!findData) {
      // console.log('aggregateData : ', findData);
      return res
        .status(200)
        .json({
          success: true,
          data: findData,
          message: 'Successfully retrieved data by date'
        });
    }else {
      return res
        .status(200)
        .json({
          success: false,
          data: [],
          message: 'Successfully retrieved data by date'
        });
    }
  }catch(err) {
    next(err);
  }
};

// userController.aggregateUsersDateWise = async (req, res, next) => {
//   const match = {
//     $or: [
//       {
//         role: 'USER'
//       },
//       {
//         refer: {
//           referee: !null
//         }
//       }
//     ]'$value''$value'
//   };
//   const group = {
//     _id : { month: { $month: '$created_at' }, day: { $dayOfMonth: '$created_at' }, year: { $year: '$created_at' } },
//     total: { $sum: 1 },
//     // countRefferal
//
//     // countUsers
//   };
//
//   try{
//     const findData = await modelFunction.aggregatePipeline({ match, group });
//
//     if(!!findData) {
//       // console.log('aggregateData : ', findData);
//       return res
//         .status(200)
//         .json({
//           success: true,
//           data: findData,
//           message: 'Successfully retrieved data by date'
//         });
//     }else {
//       return res
//         .status(200)
//         .json({
//           success: false,
//           data: [],
//           message: 'Successfully retrieved data by date'
//         });
//     }
//   }catch(err) {
//     next(err);
//   }
// };

userController.getUserLogs = async (req, res, next) => {
  try {
    const getLogs = await getAllUserLogs({ _id: req.user._id });
    // console.log('req.user._id : ', req.user._id);
    // console.log('typeof req.user._id : ', typeof req.user._id);
    if(!!getLogs) {
      // console.log('typeof get : ', typeof getLogs.user);
      return res
        .status(200)
        .json({
          success: true,
          data: getLogs,
          message: 'Successfully got all logs'
        });
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'No logs for this _id'
        });
    }
  }catch(err) { next(err); }
};

userController.checkPassword = async (req, res, next) => {
  const params = {
    _id: req.user._id
  };

  try {
    const resultFindOne = await modelFunction.findOne(params);

    if(!!resultFindOne) {
      const validPassword = resultFindOne.validPassword(req.body.password);
      if(!!validPassword) {
        console.log('validPassword : ', validPassword);
        return res
          .status(200)
          .json({
            success: true,
            message: 'Password matches'
          });
      }else {
        return res
          .status(200)
          .json({
            success: false,
            message: 'Incorrect Password'
          });
      }
    }else {
      return res
        .status(400)
        .json({
          success: false,
          message: 'Invalid _id'
        });
    }
  }catch(err) {
    next(err);
  }

};

userController.sendMultipleMails = async (req, res, next) => {
  const mailArr = req.body.mailArr;
  // let mailArrStr = '';
  // mailArr.map( (mailAdd, index) => {
  //   if(index === 0) {
  //     mailArrStr = mailAdd;
  //     // console.log('mailArrStr : ', mailArrStr);
  //   }else {
  //     mailArrStr = `${mailArrStr}, ${mailAdd}`;
  //     // console.log('mailArrStr : ', mailArrStr);
  //   }
  // });
  // console.log('mailArrStr : ', mailArrStr);
  // if(mailArr.length > 0) {
  //   mailer({ mailType: 'WHITELIST', to: mailArrStr });
  //   console.log('mail send to : ', mailArrStr);
  // }
  if(mailArr.length > 0) {
    mailer({ mailType: 'WHITELIST', to: mailArr });
    console.log('mail send to : ', mailArr);
  }

  return res
    .status(200)
    .json({
      success: true
    });
}

userController.contactUs = async (req, res, next) => {
  email = req.body.email;
  name = req.body.name;
  text = req.body.text;

  try {
    mailer({ mailType: 'CONTACTUS', to: constants.alertEmail, data: { email: email, name: name, text: text } });
    return res
      .status(200)
      .json({
        success: true,
        message: 'We will contact you as soon as possible'
      })
  } catch (error) {
    next(error);
  }
};

userController.withdrawToken = async (req, res, next) => {
  await storage.init({
    dir: newFile,

    stringify: JSON.stringify,

    parse: JSON.parse,

    encoding: 'utf8',

    logging: false,  // can also be custom logging function

    ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

    expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

    // in some cases, you (or some other service) might add non-valid storage files to your
    // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
    forgiveParseErrors: false

  });
  const abiLiveAirdroperData = await contractModel.findOne({
    tokenType: 'airdroper',
    useInDashboard: true
  });

  const abiString = abiLiveAirdroperData.abi;
  console.log('abiString : ', abiLiveAirdroperData);
  // let abiString = await storage.getItem('crowdsaleAbi');
  const abiArray = JSON.parse(abiString);
  let provider = ethers.getDefaultProvider('rinkeby');
  let tokenAddress = '0x756036a186C848F5Cc6DC60374Eca083662DaD79';
  // let tokenAddress = req.body.tokenAddress;
  console.log('tokenAddress : ', tokenAddress);
  // hardcoding private key for testing
  const privateKey = '461A28034CB63A30577326918B7DB0ACC52BF3748B5704BA5963E7F02E61CA9D';
  // const privateKey = req.body.privateKey;
  console.log('privateKey : ', privateKey);
  const wallet = new ethers.Wallet(privateKey, provider);
  const crowdsaleContract = new ethers.Contract(tokenAddress, abiArray, wallet);

  try {
    const withdrawTokenData = await crowdsaleContract
      .withdrawMyTokens();
    console.log('withdrawToken : ', withdrawToken);

    if(!!withdrawTokenData) {
      return res
        .status(200)
        .json({
          success: true,
          message: 'Successfully transferred tokens. Please check your balance.'
        });
    } else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'Unsuccessfully attempt to transferred tokens.'
        });
    }
  } catch (err) {
    next(err);
  }

}

// userController.checkBalance = async (req, res, next) => {
//   await storage.init({
//     dir: newFile,
//
//     stringify: JSON.stringify,
//
//     parse: JSON.parse,
//
//     encoding: 'utf8',
//
//     logging: false,  // can also be custom logging function
//
//     ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS
//
//     expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache
//
//     // in some cases, you (or some other service) might add non-valid storage files to your
//     // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
//     forgiveParseErrors: false
//
//   });
//
//   let abiString = await storage.getItem('crowdsaleAbi');
//   const abiArray = JSON.parse(abiString);
//   let provider = ethers.getDefaultProvider('rinkeby');
//   // hardcoding private key for testing
//   const privateKey = '461A28034CB63A30577326918B7DB0ACC52BF3748B5704BA5963E7F02E61CA9D';
//   const wallet = new ethers.Wallet(privateKey, provider);
//   const crowdsaleContract = new ethers.Contract(tokenAddress, abiArray, wallet);
//
//   try {
//     const checkBalance = await crowdsaleContract
//       .checkBalance();
//     console.log('checkBalance : ', checkBalance);
//
//     return res
//       .send(200)
//       .json({
//         success: true,
//         message: 'Successfully retrieved balance',
//         data: checkBalance
//       });
//   } catch (err) {
//     next(err);
//   }
//
// }

userController.showPhaseData = async (req, res, next) => {
  await storage.init({
    dir: newFile,
    stringify: JSON.stringify,
    parse: JSON.parse,
    encoding: 'utf8',
    logging: false, // can also be custom logging function
    ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS
    expiredInterval: 2 * 60 * 1000,
    // every 2 minutes the process will clean-up the expired cache
    // in some cases, you (or some other service) might add non-valid storage files to your
    // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
    forgiveParseErrors: false
});
  try {
    const params = {};
    params.useInDashboard = true;
    params.tokenType = 'crowdsale';
    const dataGet = await contractModelFunction.findOne({
      params
    });
    let abiString = dataGet.abi;
    let crowdsaleAddress = dataGet.address;
    console.log('crowdsaleAddress : ', crowdsaleAddress);
    // let abiString = await storage.getItem('crowdsaleAbi');
    let minInvest = await storage.getItem('minInvest');
    // let crowdsaleAddress = await storage.getItem('crowdsaleAddress');
    // let crowdsaleAddress = '0x5d048e28224c2b406ba3558a23a0a89c4f3acc97';
    const abiArray = JSON.parse(abiString);
    let provider = ethers.getDefaultProvider('rinkeby');
    const privateKey = '461A28034CB63A30577326918B7DB0ACC52BF3748B5704BA5963E7F02E61CA9D';
    wallet = new ethers.Wallet(privateKey, provider);
    const crowdsaleContract = new ethers.Contract(crowdsaleAddress, abiArray, wallet);
    let price, currentStage;
    try {
      price = await crowdsaleContract.ethPrice();
    } catch(err) {
      console.log('ethPrice error', err);
    }
    try {
      currentStage = await crowdsaleContract.getStage();
    } catch(err) {
      console.log('stage error', err);
    }
    console.log('price : ', price);
    console.log('stage : ', currentStage);
    const data = {};
    data.price = price;
    data.stage = currentStage;
    data.minInvest = minInvest;
    return res
      .status(200)
      .json({
        success: true,
        message: 'Successfully retrieved dummy data',
        data
      });
  } catch(err) {
    next(err);
  }
};

module.exports = userController;
