const boom = require('boom'),
  controller = require('./controller'),
  helper = require('utils/helper'),
  { check2FA } = require('../2FA/controller'),
  { celebrate } = require('celebrate'),
  passport = require('passport'),
  request = require('request'),
  constants = require('config/constants'),
  mailer = require('config/nodemailer'),
  moment = require('moment'),
  errorHandler = require('utils/errorHandler'),
  modelFunction = require('./doa'),
  multer = require('multer'),
  multerS3 = require('multer-s3'),
  s3 = require('app/v1/config/s3'),
  { addSignInLog } = require('./../logs/controller');

const updateProfilePicMulter = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'zineum-ico-kyc',
    acl: 'public-read',
    metadata: function (req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function (req, file, cb) {
      const originalName = file.originalname.split('.');
      const ext = `.${originalName[originalName.length - 1]}`;
      cb(null,originalName + Date.now().toString() + ext);
    }
  })
});

const authenticate = require('./../../config/authenticate');
const logger = require('config/logger');
const responseMsgs = constants.responseMsgs;
const voteController = require('../votes/controller');

const validateSchema = require('./schema');

let checkCaptcha = (req, res, next) => { // eslint-disable-line
  // if (req.app.get('env') === 'development') {
  //   return next();
  // }

  const isIpad = !!req.headers['user-agent'].match(/iPad/);
  const isAndroid = !!req.headers['user-agent'].match(/Android/);
  const isWindows = !!req.headers['user-agent'].match(/Windows/);
  const isIphone = !!req.headers['user-agent'].match(/Iphone/);
  const isMac = !!req.headers['user-agent'].match(/Macintosh/);
  let message;
  if(isWindows) {
    message = 'Please verify that you are not a robot. If you are unable to reCaptcha, please press Ctrl+R';
  }
  else if(isAndroid) {
    message = 'Please verify that you are not a robot. If you are unable to see reCaptcha, please reload the site';
  }
  else if(isIpad) {
    message = 'Please verify that you are not a robot. If you are unable to see reCaptcha, please reload the site';
  }
  else if(isMac) {
    message = 'Please verify that you are not a robot. If you are unable to see reCaptcha, please press Command+R';
  }
  else if(isIphone) {
    message = 'Please verify that you are not a robot. If you are unable to see reCaptcha, please reload the site';
  }
  else {
    message = 'Please verify that you are not a robot. If you are unable to see reCaptcha, please reload the site';
  }


  request.post({
    url: constants.gCaptcha.url,
    form: {
      secret: constants.gCaptcha.secret,
      response: !!req.body.data ? req.body.data.captcha : req.body.captcha,
      remoteip: req.ip
    }
  },
  (err, httpResponse, body) => { /* ... */
    if (err) {
      logger.info(err);
      //console.log(req.headers['user-agent']);
      return res.status(200).json({
        success: false,
        message: message
      });
      //return next(boom.badImplementation(err));
    }
    else {
      const resData = JSON.parse(body);
      logger.info(resData);
      if (resData.success) {
      	return next();
      } else {
      	return res.status(200).json({
      		success: false,
      		message: message
      	});
      }
    }

  });

};

const forceResetPassword = async (req,res,next) => {
  try {
    const params = { 'local.email': req.body.email };
    var isUser = await modelFunction.findOne({ params }); //eslint-disable-line
  } catch (error) {
    console.log(error);
  }
  if(!isUser) {
    return res.status(200).json({
      success: false,
      message: 'Please check your email and password'
    });
  }else if (!!isUser.forcereset && !!isUser.forcereset.oldUser) {
    //console.log(isUser);
		let result = await controller.forgotPassword({ email : isUser.local.email , type : 'reset'  }); // eslint-disable-line
    if (result instanceof Error) {
      next(result);
    }
    else {
		 return res.status(200).json({
			 success: true,
			 message: 'your password has been expired , please check your mail and reset password',
			 reset: false
		 });
    }
  }
  else {
    return next();
  }
};


const saveLoginAt = async (req, res, next) => {
  try {
    const date = Date.now();
    const data = {
      $set : {
        'loginAt': date
      }
    };
    const login = await modelFunction.findByIdAndUpdate({ id: req.user.id, data });
    if(login) {
      next();
    }
  }
  catch (err) {
    console.log(err);
  }

};

module.exports = function (router) {
  /**
	 * @swagger
	 * /user/subscribe:
	 *   post:
	 *     description: Subscribe a user
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: email
	 *         description: user's email.
	 *         in: body
	 *         required: true
	 *         type: string
   *       - name: name
   *         description: user's email.
   *         in: body
   *         required: true
   *         type: string
	 *     responses:
	 *       200:
	 *         message: User subscribed
	 */
  router.post('/user/subscribe', celebrate(validateSchema.subscribe), async (req, res, next) => {
    const email = req.body.email;
    let name;
    !!req.body.name ?
      name = req.body.name
      :
      name = null
    try {
      const isSubscribed = await controller.isSubscriber({ email });
      console.log('isSubscribed : ', isSubscribed);
      if (!isSubscribed) {
        var addResult = await controller.addSubscriber({ email, name, isVerify: true }); // eslint-disable-line
      } else {
        return res.status(200).json({ message: 'User already subscribed' });
      }
    } catch (error) {
      return next(boom.badImplementation(error));
    }
    logger.info(addResult);
    return res.status(200).json({ message: 'User subscribed' });

  });

  /**
   * @swagger
   * /unsubscribe:
   *   post:
   *     description: Unsubscribe a user
   *     tags:
   *       - Users
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: email
   *         description: user's email.
   *         in: params
   *         required: true
   *         type: string
   *       - name: reason
   *         description: reason why user unsubscribed.
   *         in: body
   *         required: true
   *         type: string
   *     responses:
   *       200:
   *         message: User unsubscribed
   */
  //  router.put('/unsubscribe', celebrate(validateSchema.unsubscribe), async (req, res, next) => {
  //    const email = req.query.email;
  //    // console.log('Email to be unsubscribed : ', email);
  //    try {
  //      const isSubscribed = await controller.isSubscriber({ email });
  //      if (!isSubscribed) {
  //        res.status(200).json({ message: 'User not subscribed' });
  //      } else {
  //        // user is already subscribed
  //        const result = await controller.removeSubscriber({ email });
  //        // console.log('result : ', result);
  //        return res.status(200).json({success: true, msg: 'User unsubscribed'});
  //      }
  //    } catch (error) {
  //      return next(boom.badImplementation(error));
  //    }
  //
  // });

  /**
	 * @swagger
	 * /signup/local:
	 *   post:
	 *     description: user local signup
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: email
	 *         description: user's email.
	 *         in: body
	 *         required: true
	 *         type: string
	 *       - name: password
	 *         description: user's new password.
	 *         in: body
	 *         required: true
	 *         type: string
	 *       - name: fullName
	 *         description: user's full name.
	 *         in: body
	 *         required: true
	 *         type: string
	 *       - name: contributionRange
	 *         description: user's contribution range.
	 *         in: body
	 *         required: true
	 *         type: string
	 *       - name: rfcode
	 *         description: referral code
	 *         in: body
	 *         required: false
	 *         type: string
   *       - name: channel
   *         description: channel
   *         in: body
   *         required: false
   *         type: string
	 *       - name: termsAccepted
	 *         description: terms checkbox
	 *         in: body
	 *         required: true
	 *         type: boolean
	 *       - name: isUs
	 *         description: us citizen checkbox
	 *         in: body
	 *         required: true
	 *         type: boolean
	 *     responses:
	 *       200:
	 *        	description: Signup success message
	 */

  router.post(
    '/signup/local',
    helper.removeFalsy,
    celebrate(validateSchema.signUp),
    checkCaptcha,
    passport.authenticate('local-signup', { session: false }),
    (req, res, next) => {
      if(req.user.isError) {
        logger.debug(req.user.message);
        return res.status(200).json({ success:false, message: req.user.message });
      } else {
        logger.debug('here in signup');
        const fullName = req.user.personalDetails.fullName ? req.user.personalDetails.fullName : '';
        controller.sendSignupVerificationMail({
          email: req.user.local.email,
          token: req.user.accountVerify.verificationHash,
          fullName
        });
        res.status(200).json({ success: true, message: responseMsgs.SIGNUP_LOCAL.SUCCESS_SIGNUP });
      }
    }
  );

  /**
   * @swagger
   * /signup/local/refer/:refer:
   *   post:
   *     description: user local signup
   *     tags:
   *       - Users
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: email
   *         description: user's email.
   *         in: body
   *         required: true
   *         type: string
   *       - name: password
   *         description: user's new password.
   *         in: body
   *         required: true
   *         type: string
   *       - name: fullName
   *         description: user's full name.
   *         in: body
   *         required: true
   *         type: string
   *       - name: contributionRange
   *         description: user's contribution range.
   *         in: body
   *         required: true
   *         type: string
   *       - name: rfcode
   *         description: referral code
   *         in: body
   *         required: false
   *         type: string
   *       - name: termsAccepted
   *         description: terms checkbox
   *         in: body
   *         required: true
   *         type: boolean
   *     responses:
   *       200:
   *        	description: Signup success message
   */
  // router.post(
  //   '/signup/refer/:refer',
  //   // helper.removeFalsy,
  //   // checkCaptcha,
  //   passport.authenticate('refer-signup', { session: false }),
  //   (req, res, next) => {
  //     if(req.user.isError) {
  //       logger.debug(req.user.message);
  //       return res.status(200).json({ success:false, message: req.user.message });
  //     } else {
  //       logger.debug('here in signup');
  //       const fullName = req.user.personalDetails.fullName ? req.user.personalDetails.fullName : '';
  //       controller.sendSignupVerificationMail({
  //         email: req.user.local.email,
  //         token: req.user.accountVerify.verificationHash,
  //         fullName
  //       });
  //       res.status(200).json({ success: true, message: responseMsgs.SIGNUP_LOCAL.SUCCESS_SIGNUP });
  //     }
  //   }
  // );


  // delete user api
  // takes user id from authentication
  // todo : also delete trasactions of user
  /**
   * @swagger
   *   /local/deleteUser:
   *   delete:
   *     description: deleteuser
   *     tags:
   *       - Contract
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: x-auth-token
   *         in: header
   *         type: string
   *         required: true
   *         description: Token obtained on login
   *
   *     responses:
   *       200:
   *        	description: Successfully remove the user from database'
   */

  router
    .delete(
      '/local/deleteUser',
      authenticate,
      controller.deleteUser
    );


  /**
	 * @swagger
	 * /login/local:
	 *   post:
	 *     description: user local login
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: email
	 *         description: user's email.
	 *         in: body
	 *         required: true
	 *         type: string
	 *       - name: password
	 *         description: user's password.
	 *         in: body
	 *         required: true
	 *         type: string
	 *       - name: otpToken
	 *         description: user's authenticator app otp.
	 *         in: body
	 *         required: false
	 *         type: string
	 *       - name: rememberMe
	 *         description: remember me option
	 *         in: body
	 *         type: boolean
	 *     responses:
	 *       200:
	 *        	description: login success
	 */

  router.post('/login/local',
    helper.removeFalsy,
    celebrate(validateSchema.login),
    // checkCaptcha,
    // passport.authenticate('local-login', { session: false }),
    forceResetPassword,
    passport.authenticate('local-login', { session: false }),
    (req,res,next)=>{
      if(req.user.isError) {
        logger.debug(req.user.message);
        return res.status(200).json({ success:false, message: req.user.message });
      } else {
        next();
      }
    },
    saveLoginAt,
    check2FA ,
    (req, res, next) => {
      //logger.debug(req.token, 'in login local');
      // eslint-disable-next-line no-var
      var time = new moment().format('MMMM Do YYYY, h:mm:ss a');
      // aj comment
      // eslint-disable-next-line no-var
      // var userAgent = req.headers['user-agent'].split('(')[1].split(')')[0];
      const agentAgent = 'testing user agent';
      // eslint-disable-next-line no-var
      var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
         req.connection.remoteAddress ||
         req.socket.remoteAddress ||
         req.connection.socket.remoteAddress;
      //('ip  : ', ip);
      if(!!req.user.saveActivityLogs) {
        let date = new Date();
        date = date.toISOString();
        addSignInLog({ _id: req.user._id, email: req.user.email.value, loginAt: date, ip: ip })
          .then(data => {
            console.log('Successfully store log', data);
          })
          .catch(err => {
            logger.error('userSignInLog is unable to store log');
          });
      }
      if (!req.is2FA_enabled) {
        if (req.user.personalDetails.loginAlert) {
          let device;
          if(!!req.headers['user-agent'].match(/iPad/)) {
            device = 'iPad';
          }else if(!!req.headers['user-agent'].match(/Android/)) {
            device = 'Android';
          }else if(!!req.headers['user-agent'].match(/Windows/)) {
            device = 'Windows';
          }else if(!!req.headers['user-agent'].match(/Iphone/)) {
            device = 'Iphone';
          }else if(!!req.headers['user-agent'].match(/Macintosh/)) {
            device = 'Macintosh';
          }else {
            device = 'Other';
          }

          mailer({
            to : req.user.local.email,
            mailType : 'LOGIN_ALERT',
            data : {
              userName: req.user.personalDetails.fullName,
              email: req.user.email.value,
              ip,
              date: time,
              device
            }
          });
        }
        controller.addLoginLog({ userId : req.user.id });
        res.status(200).json({
					 success: true,
					 is2FA_enabled : false ,
					 authToken: req.token
        });  // success login, disbled 2fa
      } else if (req.is2FA_provided) {
        if (req.is2FA_valid) {
          if (req.user.personalDetails.loginAlert) {
            let device;
            if(!!req.headers['user-agent'].match(/iPad/)) {
              device = 'iPad';
            }else if(!!req.headers['user-agent'].match(/Android/)) {
              device = 'Android';
            }else if(!!req.headers['user-agent'].match(/Windows/)) {
              device = 'Windows';
            }else if(!!req.headers['user-agent'].match(/Iphone/)) {
              device = 'Iphone';
            }else if(!!req.headers['user-agent'].match(/Macintosh/)) {
              device = 'Macintosh';
            }else {
              device = 'Other';
            }

            mailer({
              to : req.user.local.email,
              mailType : 'LOGIN_ALERT',
              data : {
                userName: req.user.personalDetails.fullName,
                email: req.user.email.value,
                ip,
                date: time,
                device
              }
            });
          }
          res.status(200).json({
            success: true,
            is2FA_enabled : true,
						 is2FA_valid:true ,
						 authToken: req.token
          }); // success otp login
        } else {
          res.status(200).json({
						 success: false,
						 is2FA_enabled : true,
						 message : 'Your 2FA is not correct',
						 is2FA_valid:false ,
            authToken: ''
          }); // failed, invalid otp
        }
      } else {
        res.status(200).json({
          success: false,
          is2FA_enabled : true ,
          authToken: '',
          message:constants.responseMsgs.LOGIN.EMPTY_2FA
        }); //  otp not given,un/pw correct
      }

    });


  /**
 * @swagger
 * /auth/facebook:
 *   get:
 *     description: user facebook signup/login
 *     tags:
 *       - Users
 *     produces:
 *       - application/json
 *     parameters:
 *     responses:
 *       200:
 *        	description: Fb login
 */
  router.get('/auth/facebook', passport.authenticate('facebook', { session: false, scope: 'email' }));

  // handle the callback after facebook has authenticated the user
  router.get('/auth/facebook/callback',
    passport.authenticate('facebook', {
      session: false,
      //successRedirect: '/profile',
      failureRedirect: '/'
    }), (req, res) => {
      logger.debug(req.token, 'in google login');
      res.status(200).json({ success: true, authToken: req.token });
    });


  router.get('/connect/facebook', passport.authorize('facebook', {
    scope: ['public_profile', 'email']
  }));

  // handle the callback after facebook has authorized the user
  router.get('/connect/facebook/callback',
    passport.authorize('facebook', {
      successRedirect: '/profile',
      failureRedirect: '/'
    }));


  /**
	* @swagger
	* /auth/google:
	*   get:
	*     description: user Google signup/login
	*     tags:
	*       - Users
	*     produces:
	*       - application/json
	*     parameters:
	*     responses:
	*       200:
	*        	description: Google login
	*/

  router.get('/auth/google', passport.authenticate('google', { session: false, scope: ['profile', 'email'] }));

  // the callback after google has authenticated the user
  router.get('/auth/google/callback',
    passport.authenticate('google', {
      // successRedirect: '/api/v1/auth/google/success',
      failureRedirect: '/',
      session: false
    }), (req, res) => {
      logger.debug(req.token, 'in google login');
      res.status(200).json({ success: true, authToken: req.token });
    });


  router.get('/connect/google', passport.authorize('google', { scope: ['profile', 'email'] }));

  // the callback after google has authorized the user
  router.get('/connect/google/callback',
    passport.authorize('google', {
      successRedirect: '/profile',
      failureRedirect: '/'
    }));


  router.get('/subscribe/verify/:token', async (req, res, next) => {
    const token = req.params.token;
    try {
      var result = await controller.verifySubscriber({ token }); // eslint-disable-line
    } catch (error) {
      return next(error);
    }
    res.status(200).json({ success: true, message: 'Email verified' });
  });

  /**
	* @swagger
	* /user/resend-verification-email:
	*   put:
	*     description: Resend Verification email
	*     tags:
	*       - Users
	*     produces:
	*       - application/json
	*     parameters:
	*       - name: email
	*         description: user's email.
	*         in: body
	*         required: true
	*         type: string
	*     responses:
	*       200:
	*        	description: Success message
	*/

  router.put('/user/resend-verification-email',
    checkCaptcha,
    celebrate(validateSchema.resendVerifyMail),
    controller.initEmailVerification
  );

  /**
	 * @swagger
	 * /account/verify/:token:
	 *   get:
	 *     description: Account verification through Email
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *     responses:
	 *       200:
	 *        	description: Success message
	 */

  router.get('/account/verify/:token', async (req, res, next) => {
    const token = req.params.token;
    try {
      var result = await controller.verifyAccountEmail({ token }); // eslint-disable-line
    } catch (error) {
      return next(boom.badImplementation(error));
    }
    if (result.err === 'INVALID_TOKEN') {
      const { status,message,description } = errorHandler({ errorType:'',message:result.err,description : '' });
      return res.status(status).json({ success:false,message,description });
    }
    voteController.isReferred(result._id);
    //const fullName = result.personalDetails.fullName ? result.personalDetails.fullName : '';

    // controller.sendWhitelistMail({
    //   email: result.email && result.email.value ? result.email.value : result.local.email,
    //   fullName
    // });

    return res.status(200).json({
      'success': true,
      'message': responseMsgs.SIGNUP_LOCAL.SUCCESS_VERIFY_EMAIL ,
      'email' : result.email && result.email.value ? result.email.value : result.local.email  });
  });

  /**
	 * @swagger
	 * /user/profile:
	 *   put:
	 *     description: Update profile
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name : name
	 *         description : user's name
	 *         in : body
	 *         required : false
	 *         type : string
   *       - name: notifyMe
   *         description: notifyMe check
   *         in: body
   *         required: true
   *         type: boolean
	 *       - name : phoneNumber
	 *         description : user's phoneNumber
	 *         in : body
	 *         required : false
	 *         type : string
	 *       - name : telegram
	 *         description : user's telegram address
	 *         in : body
	 *         required : true
	 *         type : string
	 *       - name : twitter
	 *         description : user's twitter address
	 *         in : body
	 *         required : true
	 *         type : string
	 *     responses:
	 *       200:
	 *        	description: success-true
	 */
  // Added notifyMe
  router.put('/user/profile', helper.removeFalsy,celebrate(validateSchema.updateProfile), authenticate, controller.updateProfile);

  // upload image
  /**
    * @swagger
    *   /user/profile/uploadImage:
    *   patch:
    *     description: upload profile image
    *     tags:
    *       - Users
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: header
    *         type: string
    *         required: true
    *         description: Token obtained on login
    *       - name: imageProfile
    *         description: user's profile image.
    *         in: formData
    *         type: string
    *         required: true
    *     responses:
    *       200:
    *        	description: uploadImage success message
    */
  router.patch('/user/profile/uploadImage', passport.authenticate('jwt', { session: false }), updateProfilePicMulter.single('imageProfile'), controller.uploadImage);

  /**
    * @swagger
    * /user/uploadSaft:
    *   patch:
    *     description: upload saft document
    *     tags:
    *       - admin
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: header
    *         type: string
    *         required: true
    *         description: Token obtained on login
    *       - name: saftDoc
    *         description: investor's saft document.
    *         in: formData
    *         type: string
    *         required: true
    *     responses:
    *       200:
    *        	description: uploadDocument success message
    */


  router.patch('/user/uploadSaft', passport.authenticate('jwt', { session: false }), updateProfilePicMulter.single('saftDoc'), controller.uploadSaftDoc);

  /**
	 * @swagger
	 * /user/forgot-password:
	 *   post:
	 *     description: Forgot password
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name : email
	 *         description : email entered by user
	 *         in : body
	 *         required : true
	 *         type : string
	 *     responses:
	 *       200:
	 *        	description: Forgot password
	 */
  router.post('/user/forgot-password', helper.removeFalsy, celebrate(validateSchema.forgotPassword),
  checkCaptcha,
  async (req, res, next) => {
    //throw new Error('error test from route');
    const email = req.body.email;
    try {
      var result = await controller.forgotPassword({ email }); // eslint-disable-line
      if (result instanceof Error) {
        next(result);
      } else if(result) {
        res.status(200).json({ success: true, message: constants.responseMsgs.FORGOT_PWD.SUCCESS });
      } else {
        const { status,message,description } = errorHandler({ errorType:'',message:constants.responseMsgs.FORGOT_PWD.INEXISTENT_EMAIL,description : '' });
        res.status(status).json({ success:false,message,description });
        //next(new Error('Email not found'))
      }
    } catch (error) {
      return next(error);
    }
  });


  /**
	 * @swagger
	 * /user/forgot-password/change/:token:
	 *   put:
	 *     description: change password with token sent on mail
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: token
	 *         in: params
	 *         schema:
	 *           type: string
	 *         required: true
	 *         description: Token obtained on mail
	 *       - name : newPassword
	 *         description : new passsword
	 *         in : body
	 *         required : true
	 *         type : string
	 *     responses:
	 *       200:
	 *        	description:
	 */


  router.put('/user/forgot-password/change/:token', helper.removeFalsy, celebrate(validateSchema.changePasswordThroughToken), controller.changePasswordThroughToken);


  /**
	 * @swagger
	 * /user/reset-password:
	 *   post:
	 *     description: change password (with current password)
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name : oldPassword
	 *         description : current password
	 *         in : body
	 *         required : true
	 *         type : string
	 *       - name : newPassword
	 *         description : new passsword
	 *         in : body
	 *         required : true
	 *         type : string
	 *       - name: x-auth-token
	 *         in: header
	 *         schema:
	 *           type: string
	 *         required: true
	 *         description: Token obtained on login
	 *     responses:
	 *       200:
	 *        	description:
	 */
  router.post(
    '/user/reset-password',
    helper.removeFalsy,
    celebrate(validateSchema.resetPassword),
    authenticate,
    controller.resetPassword
  );


  /**
	 * @swagger
	 * /user/logout:
	 *   delete:
	 *     description: current user logout
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: x-auth-token
	 *         in: header
	 *         schema:
	 *           type: string
	 *         required: true
	 *         description: Token obtained on login
	 *     responses:
	 *       200:
	 *        	description:logout success message
	 */
  router.delete('/user/logout',authenticate,controller.logout);


  /**
	 * @swagger
	 * /user/transactionfordeposit:
	 *   put:
	 *     description: update user transactions for eth and btc deposit
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: x-auth-token
	 *         in: header
	 *         schema:
	 *           type: string
	 *         required: true
	 *         description: Token obtained on login
	 *       - name : tokens
	 *         description : total tokens to transfer
	 *         in : body
	 *         required : true
	 *         type : string
	 *       - name : type
	 *         description : payment mode(eth , btc and usd)
	 *         in : body
	 *         required : true
	 *         type : string
	 *       - name : amount
	 *         description : amount in btc/eth/usd
	 *         in : body
	 *         required : true
	 *         type : string
	 *       - name : fromAddress
	 *         description : user ether/btc transfer address
	 *         in : body
	 *         required : true
	 *         type : string
	 *       - name : toAddress
	 *         description : private sale ether/btc receiving address
	 *         in : body
	 *         required : true
	 *         type : string
	 *       - name : tokenReceivingAddress
	 *         description : address where user wants to receive tokens
	 *         in : body
	 *         required : true
	 *         type : string
	 *       - name : usdAmount
	 *         description : amount in usd
	 *         in : body
	 *         required : true
	 *         type : string
   *       - name : bonus
	 *         description : bonus in percentage
	 *         in : body
	 *         required : false
	 *         type : number
   *       - name : tokenPrice
	 *         description : current tokenPrice
	 *         in : body
	 *         required : false
	 *         type : number
   *       - name : rate
	 *         description : rate At which token is bought
	 *         in : body
	 *         required : false
	 *         type : number
   *       - name : transactionHash
	 *         description : transactionHash
	 *         in : body
	 *         required : true
	 *         type : number
   *       - name : isBonusOrDiscount
	 *         description : isBonusOrDiscount
	 *         in : body
	 *         required : true
	 *         type : boolean
	 *     responses:
	 *       200:
	 *        	description: Transaction Completed for deposit
	 */
   // Added a field static to check for static sale
  router.put('/user/transactionfordeposit',helper.removeFalsy,
    celebrate(validateSchema.depositTransaction), authenticate, controller.addTransactionForDeposit);

	  /**
	 * @swagger
	 * /user/transactionHashUpdate:
	 *   put:
	 *     description: update user transactions Hash
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: x-auth-token
	 *         in: header
	 *         schema:
	 *           type: string
	 *         required: true
	 *         description: Token obtained on login
	 *       - name : transactionId
	 *         description : transaction Id
	 *         in : body
	 *         required : true
	 *         type : string
	 *       - name : transactionHash
	 *         description : transaction Hash
	 *         in : body
	 *         required : true
	 *         type : string
	 *     responses:
	 *       200:
	 *        	description: Transaction Completed for deposit
	 */
  router.put('/user/transactionHashUpdate',helper.removeFalsy,
    celebrate(validateSchema.trxnHashUpdate), authenticate, controller.addTransactionHash);


  /**
   * @swagger
   * /user/deposit:
   *   get:
   *     description: static sale or crowdsale data
   *     tags:
   *       - Users
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: x-auth-token
   *         in: header
   *         schema:
   *           type: string
   *         required: true
   *         description: Token obtained on login
   *     responses:
   *       200:
   *        	description: returns static sale or crowdsale dataa
   */
  router.get('/user/deposit', authenticate, controller.userDeposit);

	  /**
   * @swagger
   * /user/support:
   *   post:
   *     description: send support mail
   *     tags:
   *       - Users
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: x-auth-token
   *         in: header
   *         schema:
   *           type: string
   *         required: true
   *         description: Token obtained on login
   *       - name: topic
   *         in: body
   *         schema:
   *           type: string
   *         required: true
   *         description: enum TOKEN NOT RECEIVED, OTHER ISSUES, FEEDBACK, TECHNICAL ISSUE
   *       - name: message
   *         in: body
   *         schema:
   *           type: string
   *         required: true
   *         description: support message
   *     responses:
   *       200:
   *        	description:Send support mail
   */
  router.post('/user/support', celebrate(validateSchema.support), authenticate, controller.support);

	 /**
   * @swagger
   * /user/getUserRefers:
   *   get:
   *     description: Get the referal code users and transactions of a specific user
   *     tags:
   *       - Users
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: x-auth-token
   *         in: header
   *         schema:
   *           type: string
   *         required: true
   *         description: Token obtained on login
   *     responses:
   *       200:
   *        	description: returns emails and transactions of referal users.
   */
  router.get('/user/getUserRefers',  authenticate, controller.getUserRefers);

  // Ask me password before token withdraw
  /**
  * @swagger
  * /user/auth:
  *   post:
  *     description: Check if user password is correct
  *     tags:
  *       - Users
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: x-auth-token
  *         in: header
  *         schema:
  *           type: string
  *         required: true
  *         description: Token obtained on login
  *       - name: passsword
  *         in: body
  *         schema:
  *           type: string
  *         required: true
  *         description: password
  *     responses:
  *       200:
  *        	description: Success message
  */
  router
    .post(
      '/user/auth',
      authenticate,
      celebrate(validateSchema.checkPassword),
      controller.checkPassword
    );

  // aggregate signup date wise
  /**
  * @swagger
  * /users/usersByDate:
  *   get:
  *     description: Get all users created per day
  *     tags:
  *       - Users
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *        	description: Success message
  */
  router
    .get(
      '/users/usersByDate',
      controller.aggregateUsersDateWise
    );

  // user get logs
  /**
  * @swagger
  * /user/logs:
  *   get:
  *     description: Get all user logs
  *     tags:
  *       - Users
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: x-auth-token
  *         in: header
  *         schema:
  *           type: string
  *         required: true
  *         description: Token obtained on login
  *     responses:
  *       200:
  *        	description: Success message
  */
  router
    .get(
      '/user/logs',
      authenticate,
      controller.getUserLogs
    );

    /**
    * @swagger
    * /user/logs:
    *   put:
    *     description: update saveActivityLogs
    *     tags:
    *       - Users
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: header
    *         schema:
    *           type: string
    *         required: true
    *         description: Token obtained on login
    *       - name: saveActivityLogs
    *         in: body
    *         schema:
    *           type: boolean
    *         required: true
    *         description: saveActivityLogs
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .put(
      '/user/logs',
      authenticate,
      celebrate(validateSchema.saveActivityLogs),
      controller.activateLogs
    )

  router
    .post(
      '/user/multipleUsers',
      controller.sendMultipleMails
    );

    /**
    * @swagger
    * /toggleIsInfoActive:
    *   put:
    *     description: toggle isInfoActive
    *     tags:
    *       - Users
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: header
    *         schema:
    *           type: string
    *         required: true
    *         description: Token obtained on login
    *       - name: isInfoActive
    *         in: body
    *         schema:
    *           type: boolean
    *         required: true
    *         description: isInfoActive
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .put(
      '/toggleIsInfoActive',
      authenticate,
      celebrate(validateSchema.toggleIsInfoActive),
      controller.toggleIsInfoActive
    )

    /**
    * @swagger
    * /toggleIsInfoActive:
    *   put:
    *     description: toggle isInfoActive
    *     tags:
    *       - Users
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: header
    *         schema:
    *           type: string
    *         required: true
    *         description: Token obtained on login
    *       - name: isInfoActive
    *         in: body
    *         schema:
    *           type: boolean
    *         required: true
    *         description: isInfoActive
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/toggleIsInfoActive',
      authenticate,
      controller.toggleIsInfoActiveGet
    )

    /**
    * @swagger
    * /user/contactUs:
    *   post:
    *     description: contact us
    *     tags:
    *       - Users
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: email
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: users email
    *       - name: name
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: users name
    *       - name: text
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: users query
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .post(
      '/user/contactUs',
      celebrate(validateSchema.contactUs),
      controller.contactUs
    )

    /**
    * @swagger
    * /user/withdraw:
    *   post:
    *     description: withdraw tokens
    *     tags:
    *       - Airdrop
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: header
    *         schema:
    *           type: string
    *         required: true
    *         description: Token obtained on login
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .post(
      '/user/withdraw',
      authenticate,
      controller.withdrawToken
    )

  // router
  //   .get(
  //     '/user/airdropBalanceInfo',
  //     authenticate,
  //     controller.checkBalance
  //   )

  /**
  * @swagger
  * /phase:
  *   get:
  *     description: get phase info along with minInvestment and price
  *     tags:
  *       - Contract
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *        	description: Success message
  */
  router
    .get(
      '/phase',
      controller.showPhaseData
    );

};
