const mongoose = require('mongoose'),
  mongoose_delete = require('mongoose-delete'),
  bcrypt = require('bcrypt-nodejs'),
  jwt = require('jsonwebtoken'),
  presets = require('./../../../../utils/presets'),
  { genShortId } = require('./../../../../utils/helper');

const Session = require('./sessionModel');
const logger = require('./../../../../config/logger');

const walletAddressSchema = mongoose.Schema({
  ticker: {
    type: String,
    enum: ['BITCOIN', 'ETHEREUM', 'USDT'],
    required: false
  },
  address: {
    type: String,
    required: false
  },
  balance: {
    type: String,
    required: false
  },
  mnemonic: {
    type: String,
    required: false
  },
  privateKey: {
    type: String,
    required: false
  }
});

const userSchema = new mongoose.Schema({
  local: {
    'email': { type: String, trim: true },
    'password': String,
    'isPrimary': { type: Boolean, default: false },
    '2FA': {
      secretKey: {
        type: String,
        default: ''
      },
      isEnabled: {
        type: Boolean,
        default: false
      }
    }
  },
  investor: {
    contribution: {
      eth: { type: Number },
      btc: { type: Number },
      usd: { type: Number },
      usdt:{ type: Number },
      other: { type: Number }
    },
    sendVerificationMail: { type: Boolean, default: false }
    // account: {
    //   phase : { type : String , enum : constants.possibleIcoPhases , default : 'preSale'  },
    //   type : { type : String ,enum: ['Ethereum','Bitcoin', 'USD', 'Other'] },
    //   usdAmount : { type : Number },
    //   amount : { type : Number  },
    //   transactionHash : { type : String },
    // }
  },
  facebook: {
    id: String,
    token: String,
    email: String,
    name: String,
    isPrimary: { type: Boolean, default: false }
  },
  google: {
    id: String,
    token: String,
    email: String,
    name: String,
    isPrimary: { type: Boolean, default: false }
  },
  //Track
  personalDetails: {
    fullName: { type: String, trim: true },
    phoneNumber: { type: String, trim: true },
    telegram: { type: String, trim: true },
    twitter: { type: String, trim: true },
    creative : { type: String, trim: true },
    youtube : { type: String, trim: true },
    facebook : { type: String, trim: true },
    reddit : { type: String, trim: true },
    linkedIn : { type: String, trim: true },
    translation : { type: String, trim: true },
    signature : { type: String, trim: true },
    ethAddress: { type: String, trim: true },
    dob: { type: String, trim: true },
    gender: { type: String, enum: ['MALE','FEMALE','DECLINE TO STATE', null] },
    loginAlert: { type: Boolean, default: false },
    notifyMe: { type: Boolean, default: false },
    imageProfile: { type: String },
    saftDoc:{ type: String }
  },
  wallets: [walletAddressSchema],
  kycDetails: {
    documentsRequired: String,
    imageFront: String,
    imageBack: String,
    selfie: String,
    residentProof: String,
    extraDocs: { type:Array },
    documentType: String,
    documentNumber: {
      type: String
    },
    kycAttempt : {
      type : Number,
      default : 0
    },
    citizenship: String,
    country: String,
    state: String,
    city: String,
    address: String,
    address2: String,
    rejectReason: Array,
    reportIssue: {
      firstName: Boolean,
      lastName: Boolean,
      dob: Boolean,
      address: Boolean,
      nationality: Boolean,
      idNumber: Boolean,
      frontImage: Boolean,
      backImage: Boolean,
      other: String
    },
    verifiedBy: String,
    verifiedAt: Date
  },
  saveActivityLogs: {
    type: Boolean,
    default: false
  },
  contributionRange: String,
  role: { type: String, enum: ['USER', 'ADMIN', 'SUPER_ADMIN'], default: 'USER', required: true },
  createdAt: { type: Number, default: null },
  loginAt: { type: Date, default: null },
  updatedAt: { type: Number, default: null },
  forcereset : {
    oldUser: { type: Boolean, default: false }
  },
  createdBy: { type: String },
  //unblockAt: { type: Number, default: null, select: false },
  //attempt: { type: Number, default: 1, select: false },
  resetPassword: {
    token: { type: String, default: null },
    attempts: { type: Number, default: 0 },
    expiresAt: { type: Date, default: 0 }
  },
  //Required
  email: {
    value: { type: String, unique: true, trim: true, sparse: true },
    isVerified: { type: Boolean, default: false }
  },
  refer: {
    code: { type: String, trim: true },
    referralCode: { type: String, trim: true },// Confirm and Delete as not required
    totalUsed: { type: Number, default: 0 },
    success: { type: Number, default: 0 },
    referee: { type: mongoose.Schema.Types.ObjectId, default: null, ref: 'user' }, // referred by
    refereeCode: { type: String }, //
    channel: {
      type: String,
      default: null
    },
    refereeEmail: { type: String, trim: true },
    voted: { type: Boolean, default: false } // isVoted
  },
  permissions: {
    verifyKyc: { type: Boolean, default: false },
    sendMail: { type: Boolean, default: false },
    approveTransaction: { type: Boolean, default: false },
    deleteTransaction: { type: Boolean, default: false },
    deleteUser :  { type: Boolean, default: false },
    transferTokens: { type: Boolean, default: false },
    exportTransactionsExcel: { type: Boolean, default: false },
    exportUsersExcel: { type: Boolean, default: false },
    manageSmartContract : { type: Boolean, default: false },
    manageBounty: { type: Boolean, default: false },
    manageAirdrop: { type: Boolean, default: false },
    updateReferalProgram: { type: Boolean, default: false },
    inviteInvestor: { type: Boolean, default: false }
  },
  subscribe: {
    email: { type: String, unique: true, sparse: true },
    name: { type: String },
    //isSubscribed : {type:Boolean},
    verificationHash: { type: String },
    isVerified: { type: Boolean, default: false }
  },
  userState: {
    type: String,
    required: true,
    default: presets.stateUser,
    enum: [presets.stateUser, presets.stateSubscriber]
  },
  accountState: {
    type: String,
    required: true,
    default: presets.emailEntered,
    enum: [presets.emailEntered, presets.emailVerified,
      presets.userVerified, presets.userInactive, presets.userActive, presets.userBlocked
    ]
  },
  votes: [{ type: String }],
  tokens: {
    total: { type: Number, default: 0, min: 0 },
    privateSaleRound1: { type: Number, default: 0, min: 0 },
    privateSaleRound2: { type: Number, default: 0, min: 0 },
    preSale: { type: Number, default: 0, min: 0 },
    crowdSale: { type: Number, default: 0, min: 0 },
    bounty: {
      total: {  type: Number, default: 0, min: 0 },
      facebook: { type: Number, default: 0, min: 0 },
      twitter: { type: Number, default: 0, min: 0 },
      creative: { type: Number, default: 0, min: 0 },
      youtube: { type: Number, default: 0, min: 0 },
      translation: { type: Number, default: 0, min: 0 },
      reddit: { type: Number, default: 0, min: 0 },
      telegram: { type: Number, default: 0, min: 0 },
      signature: { type: Number, default: 0, min: 0 },
      linkedIn: { type: Number, default: 0, min: 0 },
      steemit: { type: Number, default: 0, min: 0 },
      medium: { type: Number, default: 0, min: 0 }
    },
    airdrop: { type: Number, default: 0, min: 0 },
    referral: { type: Number, default: 0 },
    vote: { type: Number, default: 0 }
  },
  kycStatus: {
    type: String,
    enum: ['ACCEPTED', 'REJECTED', 'SUBMITTED', 'PENDING', 'REPORTED','DOCUMENTS'],
    required: true,
    default: 'PENDING'
  },
  accountVerify: {
    verificationHash: { type: String },
    isVerified: { type: Boolean, default: false },
    expiresAt: { type: Date }
  },
  defaultVerificationMethod: {
    type: String,
    enum: ['email', 'otp', 'call'],
    default: 'email'
  },
  termsAccepted: { type: Boolean, default: false, required: true },
  isUs: { type: Boolean, default: false, required: true },
  isWhitelisted: {
    type: Boolean,
    default: false
  },
  isInfoActive: { type: Boolean, default: false, required: true},
  // submittedBountyName: {
  //   type: [String]
  // },
  userIp: { type: String },
  //State Variables
  isBlocked: { type: Boolean, default: false, select: false },
  blockedAt: { type: Date, default: null },
  isActive: { type: Boolean, default: true },
  source: {
    utm: { type: String, default: 'utm' },
    gtm: { type: String, default: 'utm' }
  }
}, {
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at'
  }
});

userSchema.index({
  'local.email': 1,
  'tokens.total': 1,
  'tokens.privateSale': 1,
  'tokens.preSale': 1,
  'tokens.crowdSale': 1,
  'refer.code': 1,
  'refre.totalUsed': 1,
  'refer.success': 1
},{
  name : 'userInex'
});
// hooks

userSchema.pre('save', async function preSave(next) {
  this.refer.code = genShortId();
  logger.debug(this.temp);
  if (this.temp) {
    logger.debug(this.temp);
    this.refer.referee = await getUserIdByReferCode(this.temp); // eslint-disable-line
  }
  logger.debug(this.refer.referee);
  next();
});

userSchema.methods.generateHash = function generateHash(password) {
  return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

// checking if password is valid
userSchema.methods.validPassword = function validPassword(password) {
  return bcrypt.compareSync(password, this.local.password);
};

userSchema.methods.genAuthtoken = function genAuthtoken({ loginType, rememberMe }) {
  let expiresIn = presets.tokenExpiryTime;
  if (rememberMe) {
    expiresIn = presets.rememberTokenExpiryTime;
  }
  try {
    const payload = { loginType, id: this._id, role: this.role };
    var token = jwt.sign(payload, presets.tokenSecret, { expiresIn }); // eslint-disable-line
  } catch (error) {
    logger.error(error);
    throw error;
  }
  Session.addSession({ token, id: this._id });
  return token;
};

const mdOptions = {
  deletedAt: true,
  deletedBy: true,
  overrideMethods: 'all'
};

userSchema.plugin(mongoose_delete, mdOptions);

const User = mongoose.model('User', userSchema);
module.exports = User;

const getUserIdByReferCode = (code) => {
  const updateData = {
    $inc: {
      'refer.totalUsed': 1
    }
  };
  return new Promise((resolve, reject) => {
    User.findOneAndUpdate({ 'refer.code': code }, updateData, (err, result) => {
      if (err) {
        reject(err);
      }
      if (!result) {
        return resolve('');
      }
      logger.debug(err, result);
      return resolve(result._id);
    });
  });

};

// indexing, mongoose-created,update_at,
