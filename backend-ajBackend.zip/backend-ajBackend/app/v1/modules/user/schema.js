const { Joi } = require('celebrate');

module.exports = {
  contactUs: {
    body: Joi.object().keys({
      email: Joi.string().required(),
      name: Joi.string().required(),
      text: Joi.string().required()
    })
  },
  subscribe: {
    body: Joi.object().keys({
      email: Joi.string().required(),
      name: Joi.string()
    })
  },
  unsubscribe: {
    query: Joi.object().keys({
      email: Joi.string().required()
    })
  },
  toggleIsInfoActive: {
    body: Joi.object().keys({
      isInfoActive: Joi.boolean().required()
    })
  },
  signUp: {
    body: Joi.object().keys({
      'email': Joi.string().email().required(),
      'password': Joi.string().min(6).max(30).required(),
      'fullName': Joi.string().min(2).max(100).required(),
      'phoneNumber': Joi.number(),
      'telegram': Joi.string(),
      'contributionRange': Joi.string(),
      'termsAccepted': Joi.boolean().invalid(false).required(),
      'rfcode': Joi.string(),
      'channel': Joi.string().valid('facebook', 'twitter', 'telegram', 'reddit', 'linkedin', 'whatsapp', 'email'),
      'isUs': Joi.boolean().invalid(false).required(),
      'g-recaptcha-response': Joi.string(),
      // aj comment
      'captcha': Joi.string().required()
    })
  },

  depositTransaction: {
    body: Joi.object().keys({
      'tokens': Joi.number().required(),
      'rate': Joi.number().required(),
      'type': Joi.string().valid('Ethereum', 'Bitcoin', 'vote', 'refer','USD', 'USDT').required(),
      'fromAddress': Joi.string(),
      'toAddress': Joi.string(),
      'tokenReceivingAddress': Joi.string(),
      'usdAmount': Joi.number().required(),
      'amount': Joi.number(),
      'phase': Joi.string().required(),
      'bonus': Joi.number(),
      'discount': Joi.number(),
      'tokenPrice': Joi.number(),
      'transactionHash': Joi.string().required(),
      'isBonusOrDiscount': Joi.string().valid('staticDiscount', 'staticBonus', 'discount').required()
    })
  },
  trxnHashUpdate: {
    body: Joi.object().keys({
      'transactionId': Joi.string().required(),
      'transactionHash': Joi.string().required()
    })
  },
  login: {
    body: Joi.object().keys({
      email: Joi.string().email().required(),
      password: Joi.string().required(),
      otpToken: Joi.number(),
      rememberMe: Joi.boolean(),
      // aj comment
     captcha: Joi.string().required()
    })
  },
  resendVerifyMail: {
    body: Joi.object().keys({
      'email': Joi.string().email().required(),
      'captcha': Joi.string().required()
    })
  },
  forgotPassword: {
    body: Joi.object().keys({
      'email': Joi.string().email().required(),
      'captcha': Joi.string().required()
    })
  },
  resetPassword: {
    body: Joi.object().keys({
      oldPassword: Joi.string().min(6).max(30).required(),
      newPassword: Joi.string().min(6).max(30).required()
    })
    // ,
    // headers: Joi.object({
    //   'x-auth-token': Joi.string().required()
    // })
  },
  changePasswordThroughToken: {
    body: Joi.object().keys({
      newPassword: Joi.string().min(6).max(30).required(),
      reset: Joi.string()
    })
  },
  updateWalletDetails: {
    body: Joi.object().keys({

    })
  },
  updateProfile: {
    body: Joi.object().keys({
      fullName : Joi.string(),
      phone : Joi.string(),
      telegram: Joi.string(),
      twitter: Joi.string(),
      creative: Joi.string(),
      youtube: Joi.string(),
      facebook: Joi.string(),
      reddit: Joi.string(),
      linkedIn: Joi.string(),
      translation: Joi.string(),
      signature: Joi.string(),
      dob: Joi.any(),
      gender: Joi.string(),
      loginAlert: Joi.boolean(),
      latestNewsAlert : Joi.boolean(),
      ethAddress: Joi.string().regex(/^0x[a-fA-F0-9]{40}$/).allow(''),
      notifyMe: Joi.boolean(),
      imageProfile: Joi.any()
    })
  },
  support: {
    body: Joi.object().keys({
      topic: Joi.string().valid('TOKEN NOT RECEIVED','OTHER ISSUES','FEEDBACK','TECHNICAL ISSUE').required(),
      message: Joi.string().required()
    })
  },
  checkPassword: {
    body: Joi.object().keys({
      password: Joi.string().required()
    })
  },
  saveActivityLogs: {
    body: Joi.object().keys({
      saveActivityLogs: Joi.boolean().required()
    })
  }
};
