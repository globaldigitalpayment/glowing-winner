const modelFunction = require('./doa'),
  User = require('./model'),
  constants = require('config/constants'),
  storage = require('node-persist'),
  path = require('path'),
  newFile = path.join(__dirname, '../../../../keyValueFile'),
 
  logger = require('config/logger');


const createAdmin = async () => {

  const newUser = new User;
  newUser.role = 'SUPER_ADMIN';

  newUser.local = {
    email: constants.adminEmail,
    password: newUser.generateHash(constants.adminPassword)
  };

  newUser.personalDetails = {
    fullName: constants.adminFullName
  };

  newUser.accountVerify = {
    isVerified: true
  };

  newUser.isInfoActive = true;

  try {
    const params = { 'local.email': constants.adminEmail };
    var isUser = await modelFunction.findOne({ params }); // eslint-disable-line
  } catch (error) { // eslint-disable-line
  }
  await storage.init({
    dir: newFile,

    stringify: JSON.stringify,

    parse: JSON.parse,

    encoding: 'utf8',

    logging: false,  // can also be custom logging function

    ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

    expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

    // in some cases, you (or some other service) might add non-valid storage files to your
    // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
    forgiveParseErrors: false

  });
  
  await storage.setItem('staticEthAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
 
    if(!!await storage.setItem('staticEthAddress')) {
      await storage.setItem('staticEthAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
    }
    if(!!await storage.setItem('staticTokenAddress')){
      await storage.setItem('staticTokenAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
    }

    if(!!await storage.setItem('staticCrowdsaleAddress')) {
      await storage.setItem('staticCrowdsaleAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
    }
    if(!! await storage.setItem('btcAddress')) {
      await storage.setItem('btcAddress',"1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX");
    }
    if (!!await storage.setItem('staticTokenUsd')) {
      await storage.setItem('staticTokenUsd',10);
    }
    if (!!await storage.setItem('staticEthUsd')) {
      await storage.setItem('staticEthUsd',100);
    }
    if (!!await storage.setItem('staticStage')) {
      await storage.setItem('staticStage',"Private Sale");
    }
    if (!!await storage.setItem('staticBtcUsd')) {
      await storage.setItem('staticBtcUsd',5000);
    }

    if (!!await storage.setItem('staticMinInvest')) {
      await storage.setItem('staticMinInvest',0);
    }
    // if (!!req.body.staticBonus && !req.body.staticDiscount) {
    //   // If latest updated value is staticBonus, then
    //   // isBonusDiscount value will be "staticBonus"
    //   await storage.setItem('staticBonus',req.body.staticBonus);
    //   await storage.setItem('isBonusOrDiscount', 'staticBonus');
    //   // We'll also set the value of staticDiscount to 0
    //   await storage.setItem('staticDiscount', 0);
    // }
    // // staticDiscount @aj
    // if (!!req.body.staticDiscount && !req.body.staticBonus) {
    //   // If latest updated value is of staticDiscount, then
    //   // isBonusDiscount value will be "staticDiscount"
    //   await storage.setItem('staticDiscount',req.body.staticDiscount);
    //   await storage.setItem('isBonusOrDiscount', 'staticDiscount');
    //   // We'll also set the value of staticBonus to 0
    //   await storage.setItem('staticBonus', 0);
    // }

    // --------staticDiscount @aj
    if (!!await storage.setItem('staticPrivateSaleTokenUsd')) {
      await storage.setItem('staticPrivateSaleTokenUsd',0);
    }
    if (!!await storage.setItem('staticPreSaleTokenUsd')) {
      await storage.setItem('staticPreSaleTokenUsd',0);
    }
    if (!!await storage.setItem('staticMainSaleTokenUsd')) {
      await storage.setItem('staticMainSaleTokenUsd',0);
    }

    if (!!await storage.setItem('staticStatus')) {
      await storage.setItem('staticStatus',);
    }
    if (!!await storage.setItem('staticAmountPercent')) {
      await storage.setItem('staticAmountPercent',0);
    }

    // eslint-disable-next-line eqeqeq
    if (!!await storage.setItem('ethAddress')) {
      await storage.setItem('ethAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
    }
    if (!!await storage.setItem('tokenAddress')) {
      await storage.setItem('tokenAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
    }

    if (!!await storage.setItem('crowdsaleAddress')) {
      await storage.setItem('crowdsaleAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
    }

    if (!!await storage.setItem('tokenUsd')) {
      await storage.setItem('tokenUsd',10);
    }
    if (!!await storage.setItem('ethUsd')) {
      await storage.setItem('ethUsd',100);
    }
    if (!!await storage.setItem('stage')) {
      await storage.setItem('stage','PRIVATE SALE');
    }
    if (!!await storage.setItem('btcUsd')) {
      await storage.setItem('btcUsd',5000);
    }

    if (!!await storage.setItem('minInvest')) {
      await storage.setItem('minInvest',0);
    }
    if (!!await storage.setItem('bonus')) {
      await storage.setItem('bonus',0);
    }
    // discount Added
    // if (!!req.body.discount) {
    //   await storage.setItem('discount',req.body.discount);
    // }
    // ------ discount @aj
    if (!!await storage.setItem('privateSaleTokenUsd')) {
      await storage.setItem('privateSaleTokenUsd',10);
    }
    if (!!await storage.setItem('preSaleTokenUsd')) {
      await storage.setItem('preSaleTokenUsd',10);
    }
    if (!!await storage.setItem('mainSaleTokenUsd')) {
      await storage.setItem('mainSaleTokenUsd',10);
    }

    if (!!await storage.setItem('status')){
      await storage.setItem('status',false);
    }
    if (!!await storage.setItem('amountPercent')) {
      await storage.setItem('amountPercent',0);
    }


  //@TODO: what to do previous super admin email
  if (!isUser) {
    await storage.init({
      dir: newFile,
  
      stringify: JSON.stringify,
  
      parse: JSON.parse,
  
      encoding: 'utf8',
  
      logging: false,  // can also be custom logging function
  
      ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS
  
      expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache
  
      // in some cases, you (or some other service) might add non-valid storage files to your
      // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
      forgiveParseErrors: false
  
    });

  
   
      if(!!await storage.setItem('staticEthAddress')) {
        await storage.setItem('staticEthAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
      }
      if(!!await storage.setItem('staticTokenAddress')){
        await storage.setItem('staticTokenAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
      }
  
      if(!!await storage.setItem('staticCrowdsaleAddress')) {
        await storage.setItem('staticCrowdsaleAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
      }
      if(!! await storage.setItem('btcAddress')) {
        await storage.setItem('btcAddress',"1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX");
      }
      if (!!await storage.setItem('staticTokenUsd')) {
        await storage.setItem('staticTokenUsd',10);
      }
      if (!!await storage.setItem('staticEthUsd')) {
        await storage.setItem('staticEthUsd',100);
      }
      if (!!await storage.setItem('staticStage')) {
        await storage.setItem('staticStage',"Private Sale");
      }
      if (!!await storage.setItem('staticBtcUsd')) {
        await storage.setItem('staticBtcUsd',5000);
      }
  
      if (!!await storage.setItem('staticMinInvest')) {
        await storage.setItem('staticMinInvest',0);
      }
      // if (!!req.body.staticBonus && !req.body.staticDiscount) {
      //   // If latest updated value is staticBonus, then
      //   // isBonusDiscount value will be "staticBonus"
      //   await storage.setItem('staticBonus',req.body.staticBonus);
      //   await storage.setItem('isBonusOrDiscount', 'staticBonus');
      //   // We'll also set the value of staticDiscount to 0
      //   await storage.setItem('staticDiscount', 0);
      // }
      // // staticDiscount @aj
      // if (!!req.body.staticDiscount && !req.body.staticBonus) {
      //   // If latest updated value is of staticDiscount, then
      //   // isBonusDiscount value will be "staticDiscount"
      //   await storage.setItem('staticDiscount',req.body.staticDiscount);
      //   await storage.setItem('isBonusOrDiscount', 'staticDiscount');
      //   // We'll also set the value of staticBonus to 0
      //   await storage.setItem('staticBonus', 0);
      // }
  
      // --------staticDiscount @aj
      if (!!await storage.setItem('staticPrivateSaleTokenUsd')) {
        await storage.setItem('staticPrivateSaleTokenUsd',0);
      }
      if (!!await storage.setItem('staticPreSaleTokenUsd')) {
        await storage.setItem('staticPreSaleTokenUsd',0);
      }
      if (!!await storage.setItem('staticMainSaleTokenUsd')) {
        await storage.setItem('staticMainSaleTokenUsd',0);
      }
  
      if (!!await storage.setItem('staticStatus')) {
        await storage.setItem('staticStatus',);
      }
      if (!!await storage.setItem('staticAmountPercent')) {
        await storage.setItem('staticAmountPercent',0);
      }
  
      // eslint-disable-next-line eqeqeq
      if (!!await storage.setItem('ethAddress')) {
        await storage.setItem('ethAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
      }
      if (!!await storage.setItem('tokenAddress')) {
        await storage.setItem('tokenAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
      }
  
      if (!!await storage.setItem('crowdsaleAddress')) {
        await storage.setItem('crowdsaleAddress',"0x439949C5D9D7bCbC6d75acF90Ce5150AAB330133");
      }
  
      if (!!await storage.setItem('tokenUsd')) {
        await storage.setItem('tokenUsd',10);
      }
      if (!!await storage.setItem('ethUsd')) {
        await storage.setItem('ethUsd',100);
      }
      if (!!await storage.setItem('stage')) {
        await storage.setItem('stage','PRIVATE SALE');
      }
      if (!!await storage.setItem('btcUsd')) {
        await storage.setItem('btcUsd',5000);
      }
  
      if (!!await storage.setItem('minInvest')) {
        await storage.setItem('minInvest',0);
      }
      if (!!await storage.setItem('bonus')) {
        await storage.setItem('bonus',0);
      }
      // discount Added
      // if (!!req.body.discount) {
      //   await storage.setItem('discount',req.body.discount);
      // }
      // ------ discount @aj
      if (!!await storage.setItem('privateSaleTokenUsd')) {
        await storage.setItem('privateSaleTokenUsd',10);
      }
      if (!!await storage.setItem('preSaleTokenUsd')) {
        await storage.setItem('preSaleTokenUsd',10);
      }
      if (!!await storage.setItem('mainSaleTokenUsd')) {
        await storage.setItem('mainSaleTokenUsd',10);
      }
  
      if (!!await storage.setItem('status')){
        await storage.setItem('status',false);
      }
      if (!!await storage.setItem('amountPercent')) {
        await storage.setItem('amountPercent',0);
      }
  
    newUser.save((err) => {
      if (err) {
        throw err;
      }
      logger.info('SUPER_ADMIN created');
      return 'SUPER_ADMIN created';
    });

  }
  else if (isUser && isUser.role !== 'SUPER_ADMIN') {
    isUser.role = 'SUPER_ADMIN';
    isUser.save( (err) => {
      if (err) {
        logger.error(err);
        throw err;
      }
    });
    logger.info('SUPER_ADMIN already exist. role updated');
    return 'SUPER_ADMIN already exist';
  } else  if(isUser && isUser.role === 'SUPER_ADMIN') {

    logger.info('SUPER_ADMIN already exist.');
    return 'SUPER_ADMIN already exist';
  }
  else {
    logger.info('NO condition matched for superAdmin');
    return 'NO condition matched for superAdmin';
  }
  

};

createAdmin();
