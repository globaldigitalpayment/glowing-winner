const mongoose = require('mongoose');

let sessionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref:'User' },
  token: [String]
});

// hooks

sessionSchema.pre('save', async (next) => {
  next();
});

sessionSchema.statics.addSession = ({ id, token = '' }) => {
  Session.update({ userId: id }, { $push: { token } }, { upsert: true }). // eslint-disable-line
    then(result => result).
    catch(err => { throw err; });
};

sessionSchema.statics.removeSession = ({ id, token = '', removeAll=false }) => {
  let params = {};
  if (removeAll) {
    params = { $set: { token: [] } };
  } else {
    params = { $pull: { token } };
  }

  Session.update({ userId: id }, params, { upsert: true }) // eslint-disable-line
    .then(result => result)
    .catch(err => { throw err; });
};

let Session = mongoose.model('Session', sessionSchema);
module.exports = Session;
