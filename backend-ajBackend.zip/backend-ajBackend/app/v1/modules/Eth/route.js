'use strict';
const Web3 = require('web3');
const fs = require('fs');
require('dotenv').config();

const web3 = new Web3(new Web3.providers.HttpProvider(`https://ropsten.infura.io/${process.env.INFURA_ACCESS_TOKEN}`));
const obj = JSON.parse(fs.readFileSync('build/contracts/CrowdSale.json', 'utf8'));
const abiArray = obj;
const contractAddress = process.env.CONTRACT_ADDRESS;
const crowdsaleContract =  new web3.eth.Contract(abiArray,contractAddress);
//const redis = require('redis');

// keep reference to redis client

// const client = redis.createClient(6379);
// client.on('ready', () => {
//   console.log('Redis is ready');
// });

// client.on('error', () => {
//   console.log('Error in Redis');
// });

const config = {
	 'Private sale': 50,
	 'Private sale end': 25,
	 'Pre ICO': 25,
	 'Pre ICO end': '0',
	 'ICO' : '0',
	 'ICO end' : '0',
	 'tokenPrice': {
		 'ETH': null,
		 'BTC' : null,
	 	 'USD': '0.03'
	 }
};

const controller = require('./controller');

module.exports = function(router) {
  /**
   * @swagger
   * /eth/smartcontract:
   *   get:
   *     description: Get current ethereum rate in dollar and stage
   *     tags:
   *       - Eth
   *     produces:
   *       - application/json
   *     responses:
   *       200:
   *
   */
  router.get('/eth/smartcontract',async (req,res,next) => {
    let currentRate, currentStage;


    // client.get('stage', (err, stage) => {
    //   console.log(stage);
    // });

    // client.get('rate', (err, rate) => {
    //   console.log(rate);
    // });

    // try {
    //   currentRate =await client.get('stage');
    // }
    // catch(err) {
    //   next(err);
    // }


    try {
      currentRate = await crowdsaleContract.methods.ethPrice().call();
    } catch (error) {
      next(error);
    }

    if (!!currentRate) {
      try {
        currentStage = await crowdsaleContract.methods.getStage().call();
      } catch (error) {
        next(error);
      }


      res.status(200).json({
        'stage': currentStage,
        'rate': currentRate,
        'bonus': config[currentStage]
      });
    }
    else {
      res.status(200).json({
        success : false,
        message :  'Error in fetching live price from smart contract'
      });
    }

  });

  router.get('/mkl',controller.ethSmartContract);

};
