'use strict';
const Web3 = require('web3');
require('dotenv').config();
const storage = require('node-persist'),
  path = require('path');
const newFile = path.join(__dirname, '../../../../keyValueFile');

const controller = Object.create(null);

controller.ethSmartContract = async () => {
  await storage.init({
    dir: newFile,

    stringify: JSON.stringify,

    parse: JSON.parse,

    encoding: 'utf8',

    logging: false,  // can also be custom logging function

    ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

    expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

    // in some cases, you (or some other service) might add non-valid storage files to your
    // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
    forgiveParseErrors: false

  });

  //console.log('Inside eth');

  //('address and network and crowdsaleAbi');
  let abiString = await storage.getItem('crowdsaleAbi');
  // console.log('crowdsaleAbi : ', abiString);
  abiString = !!abiString && abiString.replace(/'/g, '\"');
  // console.log('crowdsaleAbi : ', abiString);
  const abiArray = JSON.parse(abiString);
  // console.log('crowdsaleAbi.parse : ', abiArray);
  const contractAddress = await storage.getItem('crowdsaleAddress');
  // console.log('contractAddress : ', contractAddress);
  const network = await storage.getItem('network');
  // console.log('network : ', network);

  console.log('----------------------------------------------------------------------');
  const web3 = new Web3(new Web3.providers.HttpProvider(`https://${network}.infura.io/bcojZFdgTHPc8qdQGN3D`));

  if (!!abiString && !!contractAddress && !!network) {
    const crowdsaleContract = new web3.eth.Contract(abiArray, contractAddress);
    try {
      console.log('---------------------- STARTS -------------------------');

      const stage = await crowdsaleContract.methods.getStage().call();

      // Checking for error
      // const stage = await crowdsaleContract.methods.getStage().call();
      //console.log('getStage : ', stage);
      try {
        const tokenPriceInCurrentSale = await crowdsaleContract.methods.tokenPriceInCurrentSale().call();
        //console.log('tokenPriceInCurrentSale : ', tokenPriceInCurrentSale);
      } catch(err) {
        //console.log('err getStage : ', err);
      }
      try {
        const minimumInvestmentInCurrentSale = await crowdsaleContract.methods.minimumInvestmentInCurrentSale().call();
        //console.log('minimumInvestmentInCurrentSale : ', minimumInvestmentInCurrentSale);
      } catch(err) {
        //console.log('err minimumInvestmentInCurrentSale : ', err);
      }

      try {
        const tokenAmount = await crowdsaleContract.methods.tokenAmount(100).call();
        //console.log('tokenAmount : ', tokenAmount);
      } catch(err) {
        //console.log('err tokenAmount : ', err);
      }

      try {
        const discountInCurrentSale = await crowdsaleContract.methods.discountInCurrentSale().call();
        console.log('discountInCurrentSale : ', discountInCurrentSale);
      } catch(err) {
        console.log('err discountInCurrentSale : ', err);
      }

      //console.log('---------------------- END -------------------------');

      if(stage === 'CrowdSale Not Started') {
      // if(false) {
        console.log('****------***** RUN');
        return new Promise((resolve, reject) => {
          return resolve({
            'stage': stage,
            'rate': 0,
            'minInvest': 0,
            'tokenPrice': 0,
            'tokensAmount': 0,
            'discount': 0,
            'bonus': 0
          });
        });
      }else {
        return new Promise((resolve, reject) => {
          let currentRate, currentStage, currentPrice, minInvest, bonus, discount;
          //console.log('inside promise : ');
          Promise.all([
            crowdsaleContract.methods.ethPrice().call(),
            crowdsaleContract.methods.getStage().call(),
            crowdsaleContract.methods.tokenPriceInCurrentSale().call(),
            // Added --->   crowdsaleContract.methods.minimumInvestmentInCurrentSale().call(),
            crowdsaleContract.methods.minimumInvestmentInCurrentSale().call(),
            crowdsaleContract.methods.tokenAmount(100).call(),
            crowdsaleContract.methods.discountInCurrentSale().call()
          ]).then((results) => {
            //console.log('results : ', results);
            currentRate = results[0];
            currentStage = results[1];
            currentPrice = results[2];
            minInvest = results[3];
            // No bonus in abi
            // bonus = results[5];
            bonus = 0;
            discount = results[5];
            resolve({
              'stage': currentStage,
              'rate': currentRate,
              'minInvest': minInvest,
              'tokenPrice': currentPrice, // Need to be converted in usd (now in cents)
              'tokensAmount': results[4] / (10 ** 18), //eslint-disable-line
              // No bonus
              // 'bonus': results[5],
              'discount': results[5],
              'bonus': 0
            });
          }).catch((err) => {
            console.log('Catch Block');
            reject(err);
          });
        });
      }
    }catch(err) {
      console.log('ERROR : eth : ', err);
    }
    // console.log('crowdsaleContract : ', crowdsaleContract);


  } else {

    return new Promise((resolve, reject) => { //eslint-disable-line

      resolve({
        'stage': 'Sale Not Started Yet or No contract live',
        'rate': 0,
        'minInvest': 0,
        'tokenPrice': 0,
        'tokensAmount': 0,
        'bonus' : 0,
        'discount': 0
      });
    });
  }

};

module.exports = controller;
