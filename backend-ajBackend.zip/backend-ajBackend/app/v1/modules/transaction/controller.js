/* eslint-disable no-unused-vars */
const mongoose = require('mongoose'),
  doa = require('./doa'),
  userDoa = require('./../user/doa'),
  logger = require('config/logger'),
  path = require('path'),
  moment = require('moment'),
  newFile = path.join(__dirname, '../../../../keyValueFile'),
  storage = require('node-persist'),
  { addTrxnStatusLog, addTrxnTokensTransferredLog } = require('./../logs/controller');

const Web3 = require('web3');
var web3 = new Web3(new Web3.providers.HttpProvider('https://ropsten.infura.io/'));

// const EventEmitter = require('events');
// class MyEmitter extends EventEmitter {}
// let myEmitterPayWithToken = new MyEmitter();
// myEmitterPayWithToken.setMaxListeners(1100000000000000000);
const request = require('request');

const controller = Object.create(null);

const getTrxnStats = ({ status = undefined, isStatsAll = false }) => {
  const match = { };
  //const match = { deleted:false };
  if (status) {
    match.status = status;
  }
  //match.$or =  [{type : 'Ethereum'}, {type : 'Bitcoin'}];

  const group = {
    _id: { type: '$type' },
    amount: { $sum: '$amount' },
    token: { $sum: '$tokens' },
    totalTrxns: { $sum: 1 }
  };
  if (isStatsAll) {
    group._id.status = '$status';
  }

  return doa.aggregatePipeline({ match, group });
};

controller.getTrxnStats = getTrxnStats;

controller.addNewTraxn = async ({
  userId,
  tokens,
  creatorId,
  creatorEmail,
  type,
  fromAddress,
  toAddress,
  tokenReceivingAddress,
  usdAmount,
  amount,
  transactionHash,
  rate,
  phase,
  tokensTransferred,
  status,
  bonus,
  tokenPrice,
  referBonus,
  discount,
  isBonusOrDiscount
}) => {
  const newObj = {
    userId,
    tokens,
    initiatedBy: {
      id: creatorId,
      email: creatorEmail
    },
    type,
    fromAddress,
    toAddress,
    tokenReceivingAddress,
    usdAmount,
    amount,
    transactionHash,
    rate,
    phase,
    tokensTransferred,
    status,
    bonus,
    tokenPrice,
    referBonus,
    discount,
    isBonusOrDiscount
  };

  return doa.create({ obj: newObj });
};

controller.updateReferBonusTransferred = async (req, res, next) => {
  const trxnId = req.params._id;
  const data = {
    $set: {
      referBonusTransferred: req.body.referBonusTransferred
    }
  };
  const options = {
    new: true
  };
  let updatedResult;
  try {
    updatedResult = await doa.findByIdAndUpdate({ id: trxnId, data, options });
  }catch(err) {
    next(err);
  }

  if(!!updatedResult) {
    return res
      .status(200)
      .json({
        success: true,
        data: updatedResult,
        message: 'Successfully updated referBonusTransferred'
      });
  }else {
    return res
      .status(200)
      .json({
        success: false,
        message: 'InvalidId'
      });
  }
};

controller.updateTrxnHash = ({ trxnId,trxnHash })=>{
  const data = {
    $set : {
      transactionHash : trxnHash
    }
  };
  return doa.findByIdAndUpdate({ id:trxnId,data });
};

controller.getTransactions = async (req, res, next) => {
  let userId, params={};
  if (req.user.role === 'ADMIN' || req.user.role === 'SUPER_ADMIN') {
    userId = req.params.userId;
    if (!userId) {
      params = {};
    } else {
      params = {
        userId
      };
    }
  } else if (req.user.role === 'USER') {
    userId = req.user.id;
    if (!userId) {
      return res.status(200).json({
        success: false,
        message: 'Invalid request',
        totalTransactions: 0,
        transactions: [],
        nextPage: false
      });
    }
    params = {
      userId
    };
  }


  if (req.query.status) {
    params.status = req.query.status;
  }
  if (req.query.tokensTransferred) {
    params.tokensTransferred = req.query.tokensTransferred;
  }
  if (req.query.phase) {
    params.phase = req.query.phase;
  }
  if (!!req.query.type) {
    params.type = req.query.type;
  }
  if (req.query.method) {
    params.method = req.query.method;
  }
  if (req.query.direction) {
    params.direction = req.query.direction;
  }

  if (req.query.email) {
    params['initiatedBy.email'] = req.query.email;
  }

  if (req.query.description) {
    params.description = { '$regex' : req.query.description };
  }
  if (req.query.toAddress) {
    params.toAddress = req.query.toAddress;
  }
  if (req.query.tokensUL) {
    params.tokens ? '' : params.tokens={};
    params.tokens.$lte = req.query.tokensUL;
  }
  if (req.query.tokensLL) {
    params.tokens ? '' : params.tokens={};
    params.tokens.$gte = req.query.tokensLL;
  }
  if (req.query.amountUL) {
    params.amount ? '' : params.amount={};
    params.amount.$lte = req.query.amountUL;
  }
  if (req.query.amountLL) {
    params.amount ? '' : params.amount={};
    params.amount.$gte = req.query.amountLL;
  }
  if (req.query.usdAmountUL) {
    params.usdAmount ? '' : params.usdAmount={};
    params.usdAmount.$lte = req.query.usdAmountUL;
  }
  if (req.query.usdAmountLL) {
    params.usdAmount ? '' : params.usdAmount={};
    params.usdAmount.$gte = req.query.usdAmountLL;
  }
  if (req.query.updateType) {
    params['statusUpdatedBy.updateType'] = req.query.updateType;
  }

  if(!!req.query.minCreatedAt && !!req.query.maxCreatedAt) {
    if(Date.parse(req.query.maxCreatedAt) < Date.parse(req.query.minCreatedAt)) {
      //console.log('min date is greater');
      return res
        .status(400)
        .json({
          success: false,
          message: 'Bad Request: maxCreatedAt must be greater then minCreatedAt'
        });
    }else {
      let minCreatedAt = moment(req.query.minCreatedAt).set({
        'hour': 00,
        'minute': 00,
        'second': 00,
        'millisecond': 000
      });
      let maxCreatedAt = moment(req.query.maxCreatedAt).set({
        'hour': 23,
        'minute': 59,
        'second': 59,
        'millisecond': 999
      });
      params.created_at = {
        $gte: minCreatedAt,
        $lte: maxCreatedAt
      };
    }
  }
  if(!!req.query.minCreatedAt && !req.query.maxCreatedAt){
    let minCreatedAt = moment(req.query.minCreatedAt).set({
      'hour': 00,
      'minute': 00,
      'second': 00,
      'millisecond': 000
    });
    params.created_at = {
      $gte: minCreatedAt
    };
  }

  if(!req.query.minCreatedAt && !!req.query.maxCreatedAt){
    let maxCreatedAt = moment(req.query.maxCreatedAt).set({
      'hour': 23,
      'minute': 59,
      'second': 59,
      'millisecond': 999
    });
    // console.log('maxCreated : ', maxCreated);
    params.created_at = {
      $lte: maxCreatedAt
    };
  }

  const page = req.query.page && req.query.page > 0 ? parseInt(req.query.page) : 1,
    limit = req.query.limit && req.query.limit > 0 ? parseInt(req.query.limit) : 10;

  let sortBy = req.query.sortBy,
    sortOrder;
  sortOrder = req.query.order ? req.query.order : -1;
  if (!sortBy) {
    sortBy = 'created_at';
    sortOrder = -1;
  }

  const sort = {
    [sortBy]: sortOrder
  };

  const P_totalCount = doa.count({ params });
  var P_transactions = doa.find({ // eslint-disable-line no-var
    params,
    sort,
    skip: (page - 1) * limit,
    limit: limit
  });

  Promise.all([P_totalCount, P_transactions]).then((results) => {
    res.status(200).json({
      success: true,
      totalTransactions: results[0],
      transactions: results[1],
      nextPage: page * limit >= results[0] ? false : true
    });
  }).catch((error) => {
    next(error);
  });

};


controller.updateTrxnTransferStatus = async (req, res, next) => {

  const userId = req.user.id;
  let trxnFindResult, userUpdateResult, userUpdateData, trxnUpdateLogs; // eslint-disable-line
  const trxnId = req.params.transactionId;
  const tokenTransferStatus = req.body.status;
  const ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    req.connection.socket.remoteAddress;

  if (!mongoose.Types.ObjectId.isValid(trxnId)) {
    return res.status(200).json({
      success: false,
      message: 'Invalid transaction id'
    });
  }

  try {
    trxnFindResult = await doa.findOne({
      params: {
        _id: trxnId
      }
    });
  } catch (error) {
    next(error);
  }
  if (tokenTransferStatus === 'yes' && trxnFindResult.status !== 'confirmed') {
    return res.status(200).json({
      success: false,
      message: 'Transaction is not yet confirmed.'
    });
  }
  if (tokenTransferStatus === trxnFindResult.tokensTransferred) {
    return res.status(200).json({
      success: false,
      message: `Transaction tokenTransferStatus already ${tokenTransferStatus} `
    });
  }

  trxnFindResult.tokensTransferred = tokenTransferStatus;
  trxnFindResult.transferUpdatedBy.type = req.body.updateType;
  trxnFindResult.transferUpdatedBy.email = req.user.local.email;

  try {
    trxnUpdateLogs = await addTrxnTokensTransferredLog({
      trxnId,
      userId,
      ip,
      tokensTransferred: tokenTransferStatus
    });
    trxnFindResult = await trxnFindResult.save();
  } catch (error) {
    return next(error);
  }

  if (!trxnUpdateLogs) {
    logger.error('Trxn updateTrxnTransferStatus not recorded in history', trxnId, userId, tokenTransferStatus);
  }


  return res.status(200).json({
    success: true,
    message: 'Transaction tokenTransferStatus updated'
  });


};

controller.updateTrxnStatus = async (req, res, next) => {
  await storage.init({
    dir: newFile,

    stringify: JSON.stringify,

    parse: JSON.parse,

    encoding: 'utf8',

    logging: false,  // can also be custom logging function

    ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

    expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

    // in some cases, you (or some other service) might add non-valid storage files to your
    // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
    forgiveParseErrors: false

  });
  const userId = req.user.id;
  let trxnFindResult, userUpdateResult, userUpdateData, trxnUpdateLogs , oldStatus; // eslint-disable-line
  const trxnId = req.params.transactionId;
  const tokenTransferStatus = req.body.status;
  const ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    req.connection.socket.remoteAddress;

  if (!mongoose.Types.ObjectId.isValid(trxnId)) {
    return res.status(200).json({ success: false, message: 'Invalid transaction id' });
  }

  try {
    trxnFindResult = await doa.findOne({ params: { _id: trxnId } });
    oldStatus = trxnFindResult.status;
  } catch (error) {
    return next(error);
  }
  // if (tokenTransferStatus === 'yes' && trxnFindResult.status !== 'confirmed') {
  //   return res.status(200).json({ success: false, message: 'Transaction is not yet confirmed.' });
  // }
  if (tokenTransferStatus === trxnFindResult.status) {
    return res.status(200).json({ success: false, message: `Transaction tokenTransferStatus already ${tokenTransferStatus} ` });
  }

  trxnFindResult.status = req.body.status;
  trxnFindResult.transferUpdatedBy.type = req.body.updateType;
  trxnFindResult.transferUpdatedBy.email = req.user.local.email;
  /*

  if referral bonus token will be re calculated again,
  if i change the referral bonus % at that moment, and
  if the transaction is still pending.I think it is better to based on % of the referral commission on the moment of investors buy the token, instead of it will calculate again
  if the referral % has change.

  */
  //trxnFindResult.referBonus = await storage.getItem('amountPercent');

  try {
    trxnUpdateLogs = await addTrxnStatusLog({ trxnId, userId, status: tokenTransferStatus, ip });
    trxnFindResult = await trxnFindResult.save();
  } catch (error) {
    return next(error);
  }

  if (!trxnUpdateLogs) {
    logger.error('Trxn updateTrxnTransferStatus not recorded in history', trxnId, userId, tokenTransferStatus);
  }


  if (req.body.status === 'confirmed') {
    try {
      const findResult = await userDoa.findById({ id:trxnFindResult.userId,projection:'refer tokens' });

      if (!!findResult.refer.referee) {

        const refereeId = findResult.refer.referee;
        const params = { _id:refereeId };
        const referre = await userDoa.findOne({ params });
        const referTokens = (trxnFindResult.referBonus / 100) * (trxnFindResult.tokens * 100 / (trxnFindResult.bonus + 100)); //eslint-disable-line

        let data = { // eslint-disable-line
          $inc: {
            'tokens.referral': referTokens,
            'tokens.total': referTokens
          }

        };
        const insertResult = await userDoa.findByIdAndUpdate({ id: referre.id,data }); // eslint-disable-line
      }
    } catch (error) {
      next(Boom.badImplementation(error));
    }
    userUpdateData = {
      $inc: {
        'tokens.total': trxnFindResult.tokens,
        [`tokens.${trxnFindResult.phase}`]: trxnFindResult.tokens
      }
    };
  } else {
    if (oldStatus === 'confirmed') {

      try {
        const findResult = await userDoa.findById({
          id: trxnFindResult.userId,
          projection: 'refer tokens'
        });

        if (findResult.refer.referee) {

          const refereeId = findResult.refer.referee;
          const params = {
            _id: refereeId
          };
          const referre = await userDoa.findOne({
            params
          });
          //const referTokens = (trxnFindResult.referBonus / 100 ) * trxnFindResult.tokens; //eslint-disable-line

          const referTokens = (trxnFindResult.referBonus / 100) * (trxnFindResult.tokens * 100 / (trxnFindResult.bonus + 100)); //eslint-disable-line


          let data = { // eslint-disable-line
            $inc: {
              'tokens.referral': -referTokens,
              'tokens.total': -referTokens
            }
          };
          const insertResult = await userDoa.findByIdAndUpdate({
            id: referre.id,
            data
          }); // eslint-disable-line
        }
      } catch (error) {
        next(Boom.badImplementation(error));
      }

      userUpdateData = {
        $inc: {
          'tokens.total': -1 * trxnFindResult.tokens,
          [`tokens.${trxnFindResult.phase}`]: -1 * trxnFindResult.tokens
        }
      };
    }

  }

  try {
    userUpdateResult = await userDoa.findByIdAndUpdate({
      id: trxnFindResult.userId,
      data: userUpdateData
    });
  } catch (error) {
    return next(error);
  }

  return res.status(200).json({ success: true, message: 'Transaction tokenTransferStatus updated' });

};

controller.getTrxnStatsForAdmin = async (req, res, next) => {
  let result, resObj = {
    forTrxnStatus: req.query.status ? req.query.status : 'ALL',
    totalTansactions: 0,
    tokens: 0,
    btc: 0,
    eth: 0
  };
  try {
    result = await getTrxnStats({ status: req.query.status });
  } catch (error) {
    next(error);
  }

  result.forEach(element => {
    if (element._id.type === 'Ethereum') {
      resObj.eth = element.amount;
    } else if (element._id.type === 'Bitcoin') {
      resObj.btc = element.amount;
    }
    resObj.totalTansactions = resObj.totalTansactions + element.totalTrxns;
    resObj.tokens = resObj.tokens + element.token;

  });


  res.status(200).json({ success: true, stats: resObj });

};

controller.getAllStats = async (req, res, next) => {
  let results;
  const resObj = {
    confirmed_eth: 0,
    confirmed_btc: 0,
    pending_eth: 0,
    pending_btc: 0,
    halted_eth: 0,
    halted_btc: 0,
    cancelled_eth: 0,
    cancelled_btc: 0,
    confirmed_tokens: 0,
    pending_tokens: 0,
    halted_tokens: 0,
    cancelled_tokens: 0,
    confirmed_trxnsCount: 0,
    pending_trxnsCount: 0,
    halted_trxnsCount: 0,
    cancelled_trxnsCount: 0
  };
  try {
    results = await getTrxnStats({ isStatsAll: true });
    //res.status(200).json({ result });
  } catch (error) {
    next(error);
  }

  results.forEach(element => {
    if (element._id.status === 'confirmed') {
      if (element._id.type === 'Ethereum') {
        resObj.confirmed_eth = element.amount;
      } else if (element._id.type === 'Bitcoin') {
        resObj.confirmed_btc = element.amount;
      }
      resObj.confirmed_tokens = resObj.confirmed_tokens + element.token;
      resObj.confirmed_trxnsCount = resObj.confirmed_trxnsCount + element.totalTrxns;
    } else if (element._id.status === 'pending') {
      if (element._id.type === 'Ethereum') {
        resObj.pending_eth = element.amount;
      } else if (element._id.type === 'Bitcoin') {
        resObj.pending_btc = element.amount;
      }
      resObj.pending_tokens = resObj.pending_tokens + element.token;
      resObj.pending_trxnsCount = resObj.pending_trxnsCount + element.totalTrxns;
    } else if (element._id.status === 'halted') {
      if (element._id.type === 'Ethereum') {
        resObj.halted_eth = element.amount;
      } else if (element._id.type === 'Bitcoin') {
        resObj.halted_btc = element.amount;
      }
      resObj.halted_tokens = resObj.halted_tokens + element.token;
      resObj.halted_trxnsCount = resObj.halted_trxnsCount + element.totalTrxns;
    } else if (element._id.status === 'cancelled') {
      if (element._id.type === 'Ethereum') {
        resObj.cancelled_eth = element.amount;
      } else if (element._id.type === 'Bitcoin') {
        resObj.cancelled_btc = element.amount;
      }
      resObj.cancelled_tokens = resObj.cancelled_tokens + element.token;
      resObj.cancelled_trxnsCount = resObj.cancelled_trxnsCount + element.totalTrxns;
    }
  });
  res.status(200).json({ success: true, stats: resObj });

};


controller.getExcelSheet = async (req,res,next) =>{
  let userId, params={};
  if (req.user.role === 'ADMIN' || req.user.role === 'SUPER_ADMIN') {
    userId = req.params.userId;
    if (!userId) {
      params = {};
    } else {
      params = {
        userId
      };
    }
  } else if (req.user.role === 'USER') {
    userId = req.user.id;
    if (!userId) {
      return res.status(200).json({
        success: false,
        message: 'Invalid request',
        totalTransactions: 0,
        transactions: [],
        nextPage: false
      });
    }
    params = {
      userId
    };
  }

  if (req.query.status) {
    params.status = req.query.status;
  }
  if (req.query.tokensTransferred) {
    params.tokensTransferred = req.query.tokensTransferred;
  }
  if (req.query.phase) {
    params.phase = req.query.phase;
  }
  if (req.query.type) {
    params.type = req.query.type;
  }
  if (req.query.method) {
    params.method = req.query.method;
  }
  if (req.query.direction) {
    params.direction = req.query.direction;
  }
  if (req.query.description) {
    params.description = { '$regex' : req.query.description };
  }
  if (req.query.toAddress) {
    params.toAddress = req.query.toAddress;
  }
  if (req.query.tokensUL) {
    params.tokens ? '' : params.tokens={};
    params.tokens.$lte = req.query.tokensUL;
  }
  if (req.query.tokensLL) {
    params.tokens ? '' : params.tokens={};
    params.tokens.$gte = req.query.tokensLL;
  }
  if (req.query.amountUL) {
    params.amount ? '' : params.amount={};
    params.amount.$lte = req.query.amountUL;
  }
  if (req.query.amountLL) {
    params.amount ? '' : params.amount={};
    params.amount.$gte = req.query.amountLL;
  }
  if (req.query.usdAmountUL) {
    params.usdAmount ? '' : params.usdAmount={};
    params.usdAmount.$lte = req.query.usdAmountUL;
  }
  if (req.query.usdAmountLL) {
    params.usdAmount ? '' : params.usdAmount={};
    params.usdAmount.$gte = req.query.usdAmountLL;
  }
  if (req.query.updateType) {
    params.statusUpdatedBy.updateType = req.query.updateType;
  }
  const P_totalCount = await doa.count({ params });
  const page = req.query.page && req.query.page > 0 ? parseInt(req.query.page) : 1,
    limit = req.query.limit && req.query.limit > 0 ? parseInt(req.query.limit) : P_totalCount;

  let sortBy = req.query.sortBy,
    sortOrder;
  sortOrder = req.query.order ? req.query.order : -1;
  if (!sortBy) {
    sortBy = 'created_at';
    sortOrder = -1;
  }

  const sort = {
    [sortBy]: sortOrder
  };

  var P_transactions = doa.find({ // eslint-disable-line no-var
    params,
    sort,
    skip: (page - 1) * limit,
    limit: limit
  });

  Promise.all([P_totalCount, P_transactions]).then((results) => {
    let transaction;
    const transactions = [];
    for (transaction in results[1]) {
      if(transaction !== undefined) {
        const obj = {};
        obj.email = results[1][transaction].initiatedBy.email;
        obj.status = results[1][transaction].status;
        obj.tokens = results[1][transaction].tokens;
        obj.amount = results[1][transaction].amount;
        obj.created_at = results[1][transaction].created_at;
        obj.updated_at = results[1][transaction].updated_at;
        obj.tokensTransferred = results[1][transaction].tokensTransferred;
        obj.transactionHash = results[1][transaction].transactionHash;
        obj.phase = results[1][transaction].phase;
        obj.deleted = results[1][transaction].deleted;
        obj.userId = results[1][transaction].userId;
        obj._id = results[1][transaction]._id;
        obj.type = results[1][transaction].type;
        obj.fromAddress =results[1][transaction].fromAddress;
        obj.toAddress = results[1][transaction].toAddress;
        obj.tokenReceivingAddress = results[1][transaction].tokenReceivingAddress;
        obj.usdAmount = results[1][transaction].usdAmount;
        obj.statusUpdateType = results[1][transaction].statusUpdateType;
        obj.statusUpdateBy = results[1][transaction].statusUpdateBy;
        transactions.push(obj);
      }
    }


    res.status(200).json({
      success: true,
      totalTransactions: results[0],
      transactions,
      nextPage: page * limit >= results[0] ? false : true
    });
  }).catch((error) => {
    next(error);
  });
};

// controller.trxndetailsHash = async (req, res, next) => {
//   try {
//     let getTransactionDetails, transactionDetails;
//     getTransactionDetails = await axios
//       .get(
//         `https://api-ropsten.etherscan.io/api?module=account&action=txlistinternal&txhash=${req.params.tx}&apikey=QZT28CGN1B29ENZTMDUKENIYBCJ9PWIZ87`
//       )
//       .then((res) => {
//         console.log('url check trnx data : ', `https://api-ropsten.etherscan.io/api?module=account&action=txlistinternal&txhash=${req.params.tx}&apikey=QZT28CGN1B29ENZTMDUKENIYBCJ9PWIZ87`);
//         transactionDetails = res.data;
//         console.log('res.data : ', res.data);
//       })
//       .catch((err) => next(err));
//
//       if(transactionDetails.status == '1'){
//         return res
//           .status(200)
//           .json({
//             success: true,
//             message: 'Success',
//             resultArr: transactionDetails.result,
//             amount: (transactionDetails.result[0].value) / 1000000000000000000
//           });
//       } else {
//         return res
//           .status(200)
//           .json({
//             success: false,
//             message: 'No txn data found'
//           });
//       }
//   } catch (err) {
//     next(err);
//   }
// }


controller.trxndetailsHash = async (req, res, next) => {
  try {
    let getTransactionDetails, transactionDetails;
    getTransactionDetails = await request.get({
      url: `https://api-ropsten.etherscan.io/api?module=account&action=txlistinternal&txhash=${req.params.tx}&apikey=QZT28CGN1B29ENZTMDUKENIYBCJ9PWIZ87`
    }, async (err, httpResponse, body) => {
      const ResBody = body ? JSON.parse(body) : {};
      if(err) {
        console.log('error : ', err);
      } else if(!!ResBody){
        console.log('ResBody : ', ResBody);
        console.log('body : ', body);
        transactionDetails = ResBody;
        console.log('transactionDetails : ', transactionDetails);

        if(transactionDetails.status == '1'){
          return res
            .status(200)
            .json({
              success: true,
              message: 'Success',
              resultArr: transactionDetails.result,
              amount: (transactionDetails.result[0].value) / 1000000000000000000
            });
        } else {
          return res
            .status(200)
            .json({
              success: false,
              message: 'No txn data found'
            });
        }
      }
    });
  } catch (err) {
    next(err);
  }
}

controller.payWithToken = async (req,res,next)=>{
  try {
    let getTransactionDetails, transactionDetails;
    await storage.init({
      dir: newFile,

      stringify: JSON.stringify,

      parse: JSON.parse,

      encoding: 'utf8',

      logging: false,  // can also be custom logging function

      ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

      expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

      // in some cases, you (or some other service) might add non-valid storage files to your
      // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
      forgiveParseErrors: false

    });
    // console.log("body",req.body);
    // console.log("params",req.params);
    // console.log(req.user,"user");
    // console.log("email : ", req.user.local.email);

    const txHash = req.body.tx;

    let trxn = {};
    trxn.userId = req.user._id;
    trxn.initiatedBy =  {
      id:req.user._id,
      email:req.user.local.email
    };

    trxn.type = 'Token';
    trxn.trxnfromAddress = req.user.personalDetails.ethAddress;
    trxn.toAddress = req.body.receiveAddr;
    trxn.tokenReceivingAddress = req.user.personalDetails.ethAddress;
    trxn.transactionHash = req.body.tx;
    trxn.rate = await storage.getItem('tokenUsd');
    trxn.phase = await storage.getItem('stage');
    trxn.status ='pending';
    trxn.tokenPrice = await storage.getItem('tokenUsd');

     if(!!txHash) {
       try {
         const dataGetTransaction = await web3.eth.getTransaction(txHash);
         console.log('data **** web3.eth.getTransaction : ', dataGetTransaction);

         const value = (dataGetTransaction.value) / 1000000000000000000;
         console.log('dataGetTransaction => value : ', value);
         trxn.amount = value;
         console.log('trxn : ', trxn);
       } catch (err) {
         trxn.status = 'cancelled';
       }

       const trxnData = await doa.create({obj:trxn});
       console.log('trxnData model : ', trxnData);
       // myEmitterPayWithToken.emit('res', {
       //  'Success':true,
       //  'trx':trxn
       // });
       console.log('res success send');
       return res
        .status(200)
        .json({
         'Success':true,
         'trx':trxn
        });
     } else {
       return res.json({
        'Success':false,
        'message': 'no transaction hash'
       }).status(200)
     }
  } catch (error) {
    // console.log(error,"error");
    return res.json({
     "Success":false,
     "error":error
    }).status(200)
  }
}

// controller.payWithToken = async (req,res,next)=>{
//   try {
//     let getTransactionDetails, transactionDetails;
//     await storage.init({
//       dir: newFile,
//
//       stringify: JSON.stringify,
//
//       parse: JSON.parse,
//
//       encoding: 'utf8',
//
//       logging: false,  // can also be custom logging function
//
//       ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS
//
//       expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache
//
//       // in some cases, you (or some other service) might add non-valid storage files to your
//       // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
//       forgiveParseErrors: false
//
//     });
//     // console.log("body",req.body);
//     // console.log("params",req.params);
//     // console.log(req.user,"user");
//     // console.log("email : ", req.user.local.email);
//
//     const txHash = req.body.tx;
//
//      if(!!txHash) {
//        console.log('url check trnx data : ', `https://api-ropsten.etherscan.io/api?module=account&action=txlistinternal&txhash=${req.body.tx}&apikey=QZT28CGN1B29ENZTMDUKENIYBCJ9PWIZ87`);
//        getTransactionDetails = await axios
//          .get(
//            `https://api-ropsten.etherscan.io/api?module=account&action=txlistinternal&txhash=${req.body.tx}&apikey=QZT28CGN1B29ENZTMDUKENIYBCJ9PWIZ87`
//          )
//          .then((res) => {
//            console.log('url check trnx data : ', `https://api-ropsten.etherscan.io/api?module=account&action=txlistinternal&txhash=${req.body.tx}&apikey=QZT28CGN1B29ENZTMDUKENIYBCJ9PWIZ87`);
//            transactionDetails = res.data;
//            console.log('res.data : ', res.data);
//            console.log('**************************************');
//            console.log('res : ', res);
//          })
//          .catch((err) => err.response.data);
//
//          let trxn = {};
//          trxn.userId = req.user._id;
//          trxn.initiatedBy =  {
//            id:req.user._id,
//            email:req.user.local.email
//          };
//
//          trxn.type = 'Token';
//          trxn.trxnfromAddress = req.user.personalDetails.ethAddress;
//          trxn.toAddress = req.body.receiveAddr;
//          trxn.tokenReceivingAddress = req.user.personalDetails.ethAddress;
//          trxn.transactionHash = req.body.tx;
//          trxn.rate = await storage.getItem('tokenUsd');
//          trxn.phase = await storage.getItem('stage');
//          trxn.status ='pending';
//          trxn.tokenPrice = await storage.getItem('tokenUsd');
//
//          // console.log('transactionDetails.result[0].isError :', (transactionDetails.result[0].isError));
//          // console.log('transactionDetails.result[0].isError : typeof : ', typeof(transactionDetails.result[0].isError));
//          // console.log('transactionDetails.result[0].isError == 0 ?', transactionDetails.result[0].isError == '0');
//          // if(transactionDetails.result[0].isError == '0') {
//
//          // console.log('transactionDetails : data : status : ', transactionDetails.status);
//          console.log('all transactionDetails : ', transactionDetails);
//          console.log('transactionDetails : data : status : typeof', typeof (transactionDetails.status));
//          console.log('transactionDetails : data : status == 1 ?', transactionDetails.status == '1');
//          if(transactionDetails.status == '1') {
//            trxn.amount = (transactionDetails.result[0].value) / 1000000000000000000;
//          } else {
//            if(!!(transactionDetails.result[0])) {
//              console.log('if amount is available');
//              trxn.amount = (transactionDetails.result[0].value) / 1000000000000000000;
//            }
//            trxn.status ='cancelled';
//          }
//
//          doa.create({obj:trxn});
//          res.json({
//            "Success":true,
//            "trx":trxn
//          }).status(200);
//      } else {
//        res.json({
//         "Success":false,
//         "message": "no transaction hash"
//        }).status(200)
//      }
//   } catch (error) {
//     console.log(error,"error");
//     res.json({
//      "Success":false,
//      "error":error
//     }).status(200)
//   }
// }

// controller.payWithToken = async (req,res,next)=>{
//   try {
//     await storage.init({
//       dir: newFile,
//
//       stringify: JSON.stringify,
//
//       parse: JSON.parse,
//
//       encoding: 'utf8',
//
//       logging: false,  // can also be custom logging function
//
//       ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS
//
//       expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache
//
//       // in some cases, you (or some other service) might add non-valid storage files to your
//       // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
//       forgiveParseErrors: false
//
//     });
//     console.log("body",req.body);
//     console.log("params",req.params);
//     console.log(req.user,"user");
//
//     let trxn = {
//
//         userId:req.user._id,
//         creatorId:req.user._id,
//         creatorEmail:req.user.local.email,
//         type:'Token',
//         fromAddress:req.user.personalDetails.ethAddress,
//         toAddress:req.body.receiveAddr,
//         tokenReceivingAddress:req.user.personalDetails.ethAddress,
//         transactionHash:req.body.tx,
//         rate:await storage.getItem('tokenUsd'),
//         phase: await storage.getItem('stage'),
//         status:'pending',
//         tokenPrice:await storage.getItem('tokenUsd'),
//
//     }
//
//     doa.create({obj:trxn});
//     res.json({
//       "Success":true,
//       "trx":trxn
//      }).status(200)
//   } catch (error) {
//     console.log(error,"error");
//     res.json({
//      "Success":false,
//      "error":error
//     }).status(200)
//   }
// }
module.exports = controller;
