const mongoose = require('mongoose'),
  mongoose_delete = require('mongoose-delete'),
  constants = require('config/constants')
  axios= require("axios");

const txnRecordSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  tokens: { type: Number , default : 0 , min : 0 },
  rate: { type: Number  },
  status : { type : String , enum: constants.possibleTrxnStatus, default : 'pending' },
  tokensTransferred : { type : String , default : 'no' },
  initiatedBy: {
    id: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    email: { type : String }
  },
  statusUpdatedBy : {
    type : { type : String , enum : ['default','manual','cron'] },
    email : { type : String, default : null }
  },
  transferUpdatedBy : {
    type : { type : String , enum : ['default','manual','cron'] },
    email : { type : String, default : null }
  },
  phase : { type : String },
  type : { type : String ,enum: ['vote','refer','Ethereum','Bitcoin','USD', 'USDT', 'Token','Other'] },
  method : { type : String ,enum: ['deposit','bonus','purchase']  },
  blockNumber : { type : String },
  fromAddress : { type : String }, // from address user is sending
  toAddress : { type: String }, // where user is sending eth/btc
  tokenReceivingAddress : { type : String } , // address where user wants token
  usdAmount : { type : Number } ,
  amount : { type : Number , min : 0  }, // amount in btc or eth
  transactionHash : { type : String },
  direction : { type : String , enum : ['out','in'] },
  description : { type : String  },
  bonus:  { type : Number , min : 0 },
  discount: { type : Number , min : 0 },
  isBonusOrDiscount: { type: String },
  tokenPrice : { type: Number },
  referBonus : { type: Number , default : 0 },
  referBonusTransferred: { type: Boolean, default: false }
},
{
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at'
  }
});

txnRecordSchema.index({
  'userId' : 1,
  'tokens' : 1,
  'status' : 1,
  'tokensTransferred' : 1,
  'phase' : 1,
  'type' : 1,
  'usdAmount' : 1,
  'amount' : 1,
  'direction' : 1
},{
  name : 'trxnIndex'
});

const mdOptions = {
  deletedAt : true,
  deletedBy : true,
  overrideMethods: 'all'
};

txnRecordSchema.plugin(mongoose_delete,mdOptions);

const Transaction = mongoose.model('Transaction', txnRecordSchema);
module.exports = Transaction;
