const { Joi } = require('celebrate'),
  constants = require('config/constants');

module.exports = {
  updateStatus: {
    body: Joi.object().keys({
      status: Joi.any().valid(constants.possibleTrxnStatus).required(),
      updateType: Joi.any().valid(['manual','cron']).required()
    })
  },
  updateReferBonusTransferred: {
    body: Joi.object().keys({
      referBonusTransferred: Joi.boolean().required()
    }),
    params: Joi.object().keys({
      _id: Joi.string().required()
    })
  },
  transferStatus : {
    body: Joi.object().keys({
      status: Joi.any().valid(constants.possibleTokenTransferStatus).required(),
      updateType: Joi.any().valid(['default','manual','cron']).required()
    })
  },
  getTrnxsAdmin : {
    query: Joi.object().keys({
      status: Joi.any().valid(constants.possibleTrxnStatus),
      tokensTransferred : Joi.any().valid(constants.possibleTokenTransferStatus),
      phase: Joi.string(),
      email : Joi.string(),
      type : Joi.any().valid(['vote','refer','Ethereum','Bitcoin', 'USD']),
      method : Joi.any().valid(['deposit','bonus','purchase']),
      direction : Joi.any().valid(['out','in']),
      description : Joi.string(),
      toAddress : Joi.string(),
      tokensUL : Joi.number(),
      tokensLL : Joi.number(),
      amountUL : Joi.number(),
      amountLL : Joi.number(),
      usdAmountUL : Joi.number(),
      usdAmountLL : Joi.number(),
      page : Joi.number(),
      limit : Joi.number(),
      sortBy : Joi.any().valid('created_at','tokens','usdAmount','amount'),
      order : Joi.number().valid(1, -1),
      // type: Joi.string().valid('Ethereum','Bitcoin','USD')
      minCreatedAt: Joi.date().iso(),
      maxCreatedAt: Joi.date().iso()
    })
  },
  getTrxnsUser : {
    query: Joi.object().keys({
      status: Joi.any().valid(constants.possibleTrxnStatus),
      type : Joi.any().valid(['Ethereum','Bitcoin', 'USD']),
      page : Joi.number(),
      limit : Joi.number(),
      order : Joi.number().valid(1, -1),
      sortBy : Joi.any().valid('created_at','tokens','usdAmount','amount'),
      minCreatedAt: Joi.date().iso(),
      maxCreatedAt: Joi.date().iso()
    })
  },
  getTrxnsStatsAdmin : {
    query: Joi.object().keys({
      status: Joi.any().valid(constants.possibleTrxnStatus)
    })
  }
};
