const { celebrate } = require('celebrate');
const controller = require('./controller');
const validateSchema = require('./schema');
const { removeQueryFalsy } = require('utils/helper');

const authenticate = require('./../../config/authenticate');
const checkIfAdminOrSuperAdmin = (req, res, next) => {
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};

const checkPermissions = (permission) => {
  return function(req, res, next) {
    if(req.user.permissions[permission] || req.user.role === 'SUPER_ADMIN') {
      next();
    }else{
      res.status(200).json({
        success: false,
        message: 'You are not allowed to perform this operation'
      });
    }
  };
};

const checkIfUser = (req, res, next) => {
  if (req.user.role === 'USER') {
    next();
  } else {
    res.status(401).json({ success:false,message:'Invalid Access',description:'' });
    //next(Boom.unauthorized('Invalid Access'))
  }
};

module.exports = function (router) {

  /**
	   * @swagger
	   * /user/transactions:
	   *  get:
	   *   description : API for users to get their own transactions
	   *   tags:
	   *    - transactions
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *        type: string
	   *      required: true
	   *      description: Token obtained on login
	   *    - name: page
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: page number
	   *    - name: limit
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: number of records req on each page
	   *    - name: sortBy
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: created_at tokens usdAmount  amount
	   *    - name: order
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: from 1 or -1 asc or desc
     *    - name: type
     *      in: query
     *      schema:
     *        type: string
     *      required: false
     *      description: type valid are  Ethereum, Bitcoin, USD
     *    - name: minCreatedAt
     *      in: query
     *      schema:
     *        type: string
     *      required: false
     *      description: date
     *    - name: maxCreatedAt
     *      in: query
     *      schema:
     *        type: string
     *      required: false
     *      description: date
	   *  responses:
	   *    200:
	   *     	description: success message
	   */

  router.get('/user/transactions', removeQueryFalsy, authenticate,celebrate(validateSchema.getTrxnsUser), controller.getTransactions);

  /**
	   * @swagger
	   * /admin/transactions/{userId}:
	   *  get:
	   *   description : Get a users transactions
	   *   tags:
	   *    - transactions
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *        type: string
	   *      required: true
	   *      description: Token obtained on login
	   *    - name: userId
	   *      in: params
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: userId if not returns all trxns of all users
	   *    - name: page
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: page number
	   *    - name: limit
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: number of records req on each page
	   *    - name: sortBy
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: created_at tokens usdAmount  amount
	   *    - name: order
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: from 1 or -1 asc or desc
	   *    - name: status
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: from confirmed pending halted cancelled
	   *    - name: tokensTransferred
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: from yes or no
	   *    - name: phase
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: from privateSale preSale crowdSale
	   *    - name: type
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: from vote refer Ethereum Bitcoin
	   *    - name: method
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: from deposit bonus purchase
	   *    - name: direction
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: from out or in
	   *    - name: description
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: any string.regex search
	   *    - name: toAddress
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: to address
	   *    - name: tokensUL
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: upper limit of tokens
	   *    - name: tokensLL
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: lower limit of tokens
	   *    - name: amountUL
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: from
	   *    - name: amountLL
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: from
	   *    - name: usdAmountUL
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: from
	   *    - name: usdAmountLL
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: from
     *    - name: minCreatedAt
     *      in: query
     *      schema:
     *        type: string
     *      required: false
     *      description: date
     *    - name: maxCreatedAt
     *      in: query
     *      schema:
     *        type: string
     *      required: false
     *      description: date
	   *
	   *  responses:
	   *    200:
	   *     	description: success message
	   */
  router.get('/admin/transactions/:userId?',
    removeQueryFalsy,
    celebrate(validateSchema.getTrnxsAdmin),
	 authenticate,
	 checkIfAdminOrSuperAdmin,
	  controller.getTransactions);

  /**
	   * @swagger
	   * /admin/transaction/status/{transactionId}:
	   *  put:
	   *   description : update transaction status
	   *   tags:
	   *    - transactions
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *        type: string
	   *      required: true
	   *      description: Token obtained on login
	   *    - name: status
	   *      in: params
	   *      schema:
	   *        type: string
	   *      required: true
	   *      description: new trxn status (confirmed|pending|halted|cancelled)
	   *  responses:
	   *    200:
	   *     	description: success message
	   */
  router.put('/admin/transaction/status/:transactionId',
    authenticate,
    checkPermissions('approveTransaction'),
    checkIfAdminOrSuperAdmin,
    controller.updateTrxnStatus);

  /**
	   * @swagger
	   * /admin/transaction-stats:
	   *  get:
	   *   description : get transaction stats for admin
	   *   tags:
	   *    - transactions
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *        type: string
	   *      required: true
	   *      description: Token obtained on login
		 *    - name: status
	   *      in: params
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: trxn status
	   *  responses:
	   *    200:
	   *     	description: success message
	   */
  router.get('/admin/transaction-stats',
	  celebrate(validateSchema.getTrnxsAdmin),
    authenticate,
    checkIfAdminOrSuperAdmin,
    controller.getTrxnStatsForAdmin);


  /**
	   * @swagger
	   * /admin/all-transaction-stats:
	   *  get:
	   *   description : get all-transaction stats for admin
	   *   tags:
	   *    - transactions
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *        type: string
	   *      required: true
	   *      description: Token obtained on login
	   *  responses:
	   *    200:
	   *     	description: success message
	   */
  router.get('/admin/all-transaction-stats',
    authenticate,checkIfAdminOrSuperAdmin,
    controller.getAllStats);

  /**
	 * @swagger
	 * /admin/transaction/tokens/{transactionId}:
	 *  put:
	 *   description : update transaction token transfer status
	 *   tags:
	 *    - transactions
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *        type: string
	 *      required: true
	 *      description: Token obtained on login
	 *    - name: status
	 *      in: params
	 *      schema:
	 *        type: string
	 *      required: true
	 *      description: new trxn transfer status (yes|no)
	 *  responses:
	 *    200:
	 *     	description: success message
	 */
  router.put('/admin/transaction/tokens/:transactionId',
    celebrate(validateSchema.transferStatus),
	 authenticate,
    checkIfAdminOrSuperAdmin,
		 checkPermissions('transferTokens'),
			 controller.updateTrxnTransferStatus);

  /**
	 * @swagger
	 * /admin/excel/transaction:
	 *  get:
	 *   description : API to download excel sheet of transactions
	 *   tags:
	 *    - transactions
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *        type: string
	 *      required: true
	 *      description: Token obtained on login
	 *    - name: page
	 *      in: query
	 *      schema:
	 *        type: number
	 *      required: false
	 *      description: page number
	 *    - name: limit
	 *      in: query
	 *      schema:
	 *        type: number
	 *      required: false
	 *      description: number of records req on each page
	 *    - name: status
	 *      in: query
	 *      schema:
	 *        type: string
	 *      required: false
	 *      description: pending halted cancelled confirmed
	 *    - name: tokensTransferred
	 *      in: query
	 *      schema:
	 *        type: string
	 *      required: false
	 *      description: yes no
	 *    - name: phase
	 *      in: query
	 *      schema:
	 *        type: string
	 *      required: false
	 *      description: privateSale preSale crowdSale
	 *    - name: type
	 *      in: query
	 *      schema:
	 *        type: string
	 *      required: false
	 *      description: payment type
	 *    - name: direction
	 *      in: query
	 *      schema:
	 *        type: string
	 *      required: false
	 *      description: direction
	 *    - name: toAddress
	 *      in: query
	 *      schema:
	 *        type: string
	 *      required: false
	 *      description: to Address
	 *    - name: tokensUL
	 *      in: query
	 *      schema:
	 *        type: number
	 *      required: false
	 *      description: max tokens
	 *    - name: tokensLL
	 *      in: query
	 *      schema:
	 *        type: number
	 *      required: false
	 *      description: min tokens
	 *    - name: amountUL
	 *      in: query
	 *      schema:
	 *        type: number
	 *      required: false
	 *      description: max amount
	 *    - name: amountLL
	 *      in: query
	 *      schema:
	 *        type: number
	 *      required: false
	 *      description: min amount
	 *    - name: usdAmountUL
	 *      in: query
	 *      schema:
	 *        type: number
	 *      required: false
	 *      description: max USD amount
	 *    - name: usdAmountLL
	 *      in: query
	 *      schema:
	 *        type: number
	 *      required: false
	 *      description: min USD amount
	 *    - name: sortBy
	 *      in: query
	 *      schema:
	 *        type: string
	 *      required: false
	 *      description: created_at tokens usdAmount  amount
	 *  responses:
	 *    200:
	 *     	description: success message
	 */

  router.get('/admin/excel/transaction',
	 celebrate(validateSchema.transferStatus),
	 authenticate,
		 checkPermissions('exportTransactionsExcel'),
		 controller.getExcelSheet);

     /**
     * @swagger
     * /admin/update/referBonusTransferred/:_id:
     *   put:
     *     description: referBonusTransferred
     *     tags:
     *       - Users
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: x-auth-token
     *         in: header
     *         schema:
     *           type: string
     *         required: true
     *         description: Token obtained on login
     *       - name: _id
     *         in: params
     *         schema:
     *           type: string
     *         required: true
     *         description: referBonusTransferred
     *       - name: referBonusTransferred
     *         in: body
     *         schema:
     *           type: boolean
     *         required: true
     *         description: referBonusTransferred
     *     responses:
     *       200:
     *        	description: Success message
     */
  router
    .put(
      '/admin/update/referBonusTransferred/:_id',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.updateReferBonusTransferred),
      controller.updateReferBonusTransferred
	);

  router
    .get(
      '/user/testHash/:tx',
      controller.trxndetailsHash
    );

  router.post('/user/payWithToken',
  authenticate,
	controller.payWithToken);

//  router.get('/user/payWithToken',
// 	authenticate,
// 	controller.payWithToken);

};
