const mongoose = require('mongoose');

const messageSchema = mongoose.Schema({
  message: {
    type: String,
    required: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  type: {
    type: String,
    enum: ['USER','ADMIN','SUPER_ADMIN']
  },
  createdAt: { type: String }
});


const ticketSchema = new mongoose.Schema({
  ticketId: { type: String },
  transactionId: { type: mongoose.Schema.Types.ObjectId, ref:'Transaction' },
  userId: { type: mongoose.Schema.Types.ObjectId, ref:'User' },
  subject: { type: String },
  messages : [messageSchema],
  status : { type : String, enum : ['CLOSED','OPEN'],default : 'OPEN' },
  mailNotification: {
    type: Boolean,
    default: false
  }
},
{
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at'
  }
});

// hooks

messageSchema.pre('save', async function (next) {
  this.createdAt = new Date();
  next();
});

const Ticket = mongoose.model('Ticket', ticketSchema);
module.exports = Ticket;
