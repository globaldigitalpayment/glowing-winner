const controller = require('./controller');
const authenticate = require('./../../config/authenticate');
const { celebrate } = require('celebrate');
const validateSchema = require('./schema');

const checkIfAdminOrSuperAdmin = (req, res, next) => {
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};
module.exports = function (router) {

  /**
	 * @swagger
	 * /ticket:
	 *  post:
	 *   description : Create new ticket
	 *   tags:
	 *    - ticket
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *        type: string
	 *      required: true
	 *      description: Token obtained on login
	 *    - name: query
	 *      in: body
	 *      schema:
	 *        type: string
	 *      required: true
	 *      description: Query string for ticket
	 *  responses:
	 *    200:
	 *     	description: success message
	 */
  // added parameter name: transactionId

  router.post('/ticket', authenticate, controller.createTicket);

  /**
	 * @swagger
	 * /ticket:
	 *  get:
	 *   description : Create
	 *   tags:
	 *    - ticket
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *        type: string
	 *      required: true
	 *      description: Token obtained on login
	 *  responses:
	 *    200:
	 *     	description: result contain tickets
	 */

  router.get('/admin/tickets', authenticate, checkIfAdminOrSuperAdmin, controller.getAllTickets);

  router.get('/tickets', authenticate, controller.getUserTickets);

  router.patch('/ticket/message/:ticketId', authenticate, controller.sendMessage);

  router.get('/ticket/messages/:ticketId', authenticate, controller.getMessages);

  router
    .put(
      '/ticket/mailNotification',
      authenticate,
      celebrate(validateSchema.mailNotificationUpdate),
      controller.mailNotificationUpdate
    )

  /**
	 * @swagger
	 * /ticket-status/{ticketId}':
	 *  put:
	 *   description : Close tickst
	 *   tags:
	 *    - ticket
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *        type: string
	 *      required: true
	 *      description: Token obtained on login
	 *    - name: ticketId
	 *      in: params
	 *      schema:
	 *        type: string
	 *      required: true
	 *      description: ticketid to close
	 *  responses:
	 *    200:
	 *     	description: success message
	 */

  router.put('/closeTicket/:ticketId', authenticate, controller.closeTicket);
};
