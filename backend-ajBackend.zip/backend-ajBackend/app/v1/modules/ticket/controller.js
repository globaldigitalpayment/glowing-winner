const modelFunction = require('./doa');
const controller = Object.create(null);
const mongoose = require('mongoose');
const shortId = require('shortid'),
  {
    addCreateTicketLog,
    // addGetUserTicketsLog,
    addSendMessageLog,
    // addGetMessagesLog,
    addCloseTicketLog
   } = require('./../logs/controller'),
  mailer = require('config/nodemailer'),
  userModelFunction = require('./../user/doa'),
  moment = require('moment');

controller.createTicket = (req,res,next)=>{
  console.log('transctionId in string format : ', req.body.transactionId);
  // console.log("transctionId in ObjectId format : ", mongoose.Types.ObjectId(req.body.transactionId));
  const ticket = {
    userId : req.user.id,
    ticketId : shortId.generate(),
    messages: [{
      message: req.body.message,
      userId: req.user.id,
      type: 'USER'
    }],
    subject: req.body.subject
  };
  console.log('transactionid : ', req.body.transactionId);
  if(!!req.body.transactionId && mongoose.Types.ObjectId.isValid(req.body.transactionId)) {
    ticket.transactionId = mongoose.Types.ObjectId(req.body.transactionId);
  }

  try {
    modelFunction.create({ obj:ticket });
  } catch (error) {
    next(error);
  }
  if(!!req.user.saveActivityLogs) {
    var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
      req.connection.remoteAddress ||
      req.socket.remoteAddress ||
      req.connection.socket.remoteAddress;
    let date = new Date();
    date = date.toISOString();
    addCreateTicketLog({ _id: req.user._id, email: req.user.email.value, submittedAt: date, ip: ip })
      .then(data => {
        console.log('Successfully store log', data);
      })
      .catch(err => {
        logger.error('addCreateTicketLog is unable to store log');
      });
  }
  res.status(200).json({ success:true,message:'Ticket Created' });
};


controller.getAllTickets =async (req,res,next)=>{
  const page = req.query.page && req.query.page > 0 ? parseInt(req.query.page) : 1,
    limit = req.query.limit && req.query.limit > 0 ? parseInt(req.query.limit) : 10;

  try {
    const params = {};
    const sort = {
      'created_at': -1
    };
    const query = 'userId';
    if(req.query.status) {
      params.status = req.query.status;
    }
    if(req.query.date) {
      const start = new moment(req.query.date).startOf('day').toISOString();
      const end = new moment(req.query.date).endOf('day').toISOString();
      params.created_at ? '' : params.created_at={ };
      params.created_at.$gte = start;
      params.created_at.$lte = end;
    }
    if(req.query.sortBy) {
      if(!!req.query.sortBy && req.query.sortBy === 'newest') {
        sort.created_at = -1;
      }
      if(!!req.query.sortBy && req.query.sortBy === 'oldest') {
        sort.created_at = 1;
      }
    }
    const T_totalCount = await modelFunction.count({ params });
    const tickets = await modelFunction.find({ params, sort, query, skip: (page - 1) * limit, limit: limit });
    const userTickets = [];
    tickets.forEach(element => {
      const obj = {
        subject: element.subject,
        status: element.status,
        ticketId: element.ticketId,
        transactionId: element.transactionId,
        messages: element.messages,
        createdAt: new moment(element.created_at).format('h:mm a,Do MMMM YYYY'),
        email: !!element.userId && !!element.userId.local ? element.userId.local.email : ''
      };
      userTickets.push(obj);
    });
    res.status(200).json({
      tickets: userTickets,
      nextPage: page * limit >= T_totalCount ? false : true
    });
  } catch (error) {
    next(error);
  }
};

controller.getUserTickets = async (req,res,next) => {
  try {
    const params = {
      userId: mongoose.Types.ObjectId(req.user.id)
    };
    const sort = {
      created_at : -1
    };
    const tickets = await modelFunction.find({ params, sort });
    const userTickets = [];
    tickets.forEach(element => {
      const obj = {
        subject: element.subject,
        status: element.status,
        ticketId: element.ticketId,
        mailNotification: element.mailNotification,
        transactionId: element.transactionId,
        messages: element.messages,
        createdAt: new moment(element.created_at).format('h:mm a,Do MMMM YYYY')
      };
      userTickets.push(obj);
    });
    // if(!!req.user.saveActivityLogs) {
    //   let date = new Date();
    //   date = date.toISOString();
    //   addGetUserTicketsLog({ _id: req.user._id, email: req.user.email.value, userTickets: userTickets, submittedAt: date })
    //     .then(data => {
    //       console.log('Successfully store log', data);
    //     })
    //     .catch(err => {
    //       logger.error('addGetUserTicketsLog is unable to store log');
    //     });
    // }
    res.status(200).json({
      tickets: userTickets
    });
  } catch (error) {
    next(error);
  }
};

controller.sendMessage = async (req, res, next) => {
  let mailNotification = false;
  const query = {
    ticketId : req.params.ticketId
  };
  const updateData = {
    $push: {
      messages: {
        message: req.body.message,
        type: req.user.role,
        userId: req.user.id,
        createdAt: new Date()
      }
    }
  };

  // try {
  //   let message = await modelFunction.findOneAndUpdate({ query, params: updateData });
  // } catch (error) {
  //   next(error);
  // }

  try {
    const ticketData = await modelFunction.find({
      params: {
        ticketId: req.params.ticketId
      }
    });
    // console.log('ticketData : ', ticketData);
    if(!!ticketData) {
      // console.log('mailNotification : ', ticketData[0].mailNotification);
      mailNotification = ticketData[0].mailNotification;
      const message = await modelFunction.findOneAndUpdate({
        query,
        params: updateData
      });

      if (req.user.role === 'ADMIN' || req.user.role === 'SUPER_ADMIN') {
        try {
          const user = await userModelFunction.findById({
            id: message.userId
          });
          // console.log(user.local.email);
          // console.log(user.personalDetails.fullName);
          // console.log(message.subject);
          if(!!mailNotification) {
            mailer({
              mailType: 'TICKET_REPLY',
              to: user.local.email,
              data: {
                fullName: user.personalDetails.fullName,
                subject: message.subject,
                to: user.local.email
              }
            });
          }
        } catch (err) {
          next(err);
        }
      }
    }
  } catch (error) {
    next(error);
  }

  if(!!req.user.saveActivityLogs) {
    var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
      req.connection.remoteAddress ||
      req.socket.remoteAddress ||
      req.connection.socket.remoteAddress;
    let date = new Date();
    date = date.toISOString();
    addSendMessageLog({ _id: req.user._id, email: req.user.email.value, ticketId : req.params.ticketId, submittedAt: date, ip: ip })
      .then(data => {
        console.log('Successfully store log', data);
      })
      .catch(err => {
        logger.error('addSendMessageLog is unable to store log');
      });
  }
  res.status(200).json({
    success: true,
    message: 'Message sent!'
  });
};

controller.closeTicket = async (req,res,next)=>{
  const ticketId = req.params.ticketId;
  const query = {
    ticketId : ticketId
  };
  const updateData = {
    $set:{
      status : 'CLOSED'
    }
  };
  try {
    let result = await modelFunction.findOneAndUpdate({ query,params:updateData }); // eslint-disable-line
  } catch (error) {
    next(error);
  }
  if(!!req.user.saveActivityLogs) {
    var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
      req.connection.remoteAddress ||
      req.socket.remoteAddress ||
      req.connection.socket.remoteAddress;
    let date = new Date();
    date = date.toISOString();
    addCloseTicketLog({ _id: req.user._id, email: req.user.email.value, ticketId : req.params.ticketId, submittedAt: date, ip: ip })
      .then(data => {
        console.log('Successfully store log', data);
      })
      .catch(err => {
        logger.error('addCloseTicketLog is unable to store log');
      });
  }
  res.status(200).json({ success:true,message:'Ticket Closed' });
};

controller.mailNotificationUpdate = async (req, res, next) => {
  try {
    const query = {
      ticketId: req.body.ticketId
    };
    const params = {
      mailNotification: req.body.mailNotification
    };

    const updateTicket = await modelFunction.findOneAndUpdate({
      query,
      params
    });
    if(!!updateTicket) {
      return res
        .status(200)
        .json({
          success: true,
          message: 'mail notification updated',
          data: updateTicket
        });
    } else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'Invalid details'
        });
    }
  } catch (error) {
    next (error);
  }
};

controller.getMessages = async (req, res, next) => {
  try {
    const params = {
      ticketId : req.params.ticketId
    };
    const ticket = await modelFunction.find({ params });

    // if(!!req.user.saveActivityLogs) {
    //   let date = new Date();
    //   date = date.toISOString();
    //   addGetMessagesLog({ _id: req.user._id, email: req.user.email.value, ticketId : req.params.ticketId, messages: ticket[0].messages, submittedAt: date })
    //     .then(data => {
    //       console.log('Successfully store log', data);
    //     })
    //     .catch(err => {
    //       logger.error('addGetMessagesLog is unable to store log');
    //     });
    // }
    res.status(200).json({
      messages: ticket[0].messages
    });
  } catch (error) {
    next (error);
  }

};

module.exports = controller;
