const { Joi } = require('celebrate');

module.exports = {
  mailNotificationUpdate: {
    body: Joi.object().keys({
      mailNotification: Joi.boolean().required(),
      ticketId: Joi.string().required()
    })
  }
};
