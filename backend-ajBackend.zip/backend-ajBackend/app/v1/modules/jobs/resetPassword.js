const Agenda = require('agenda');
const dburl = 'mongodb://localhost:27017/zineum-ico';
const modelFunction = require('../user/model');
const agenda = new Agenda();
const _ = require('lodash');

process.on('message', (msg) => {
  require('../../config/dbConnection');
  callThisFunc();
  console.log('Child Process Started : ', msg);
});
//callThisFunc();
function callThisFunc() {
  agenda.database(dburl, 'agendaJobs');

  function graceful() {
    agenda.stop(() => {
      process.exit(0);
    });
  }

  process.on('SIGTERM', graceful);
  process.on('SIGINT', graceful);

  const message = '';
  agenda.define('Reset all passwords in db', (job, done) => {
    console.log('Inside reset all passwords agenda!!');
    modelFunction.count({ 'forcereset.oldUser' : false, 'role': 'USER' }, (err, count) => {
      if (err) {
        process.send('error occurred : ',err.stack);
        return done(err);
			  }

			  console.log('count is : ', count);

			  const arr = [];

      if (count === 0) {
        process.send('Done resetting passwords');
        return done(null, 'done resetting passwords ---------------------------------------------------------');
      }

      const streams = modelFunction.find({
        'forcereset.oldUser': false,
        'role': 'USER'
      }, {}).limit(count).lean().stream();

      streams.on('data', (user) => {
        //@TODO: check if error here
        /*
				  need to pause for data processing
				*/
        streams.pause();

        console.log(user._id);
        arr.push(user._id);
        streams.emit('update resetKey', user);
			  });

			  streams.on('update resetKey', (user) => {
        //console.log(user._id, user.local.email);
        process.send(`Resetting password for : ${user.local.email}`);
        modelFunction.findOne({
          _id: user._id
        }, (err, res) => {
          if (err) {return streams.emit('final call', err);}
          modelFunction.findOneAndUpdate({ _id :  user._id }, { $set: { forcereset: { oldUser: true } } }, 
            (err, res) => {
              if (err) {
                return streams.emit('final call', err);
              } else {
                streams.emit('final call');
              }
            });
        });
			  });

			  streams.on('final call', (d) => {

        if (arr.length === count) {
				  console.log('done all');
				  process.send('Done resetting passwords');
				  done(null, 'done resetting passwords ---------------------------------------------------------');
        } else {
				  if(!!d) {console.log(d);}
				  console.log('resetting passwords-----------------keep patience--------------------------------');
				  /*
					resume after processing data
				  */
				  streams.resume();
        }

			  });

			  streams.on('error', (err2) => {
        console.log('error catched');
        console.log(err2);
        logger.error(err2);
        streams.resume();
			  });

			  streams.on('close', () => {
        // all done
        console.log('all done');
			  });
    });
  });


  agenda.on('ready', () => {

    agenda.cancel({
      name: 'Reset all passwords in db'
    }, (err, numRemoved) => {
      console.log(err, numRemoved);
      agenda.now('Reset all passwords in db');
    });

    agenda.start();
  });


  agenda.on('start', (job) => {
    console.log('Job %s starting', job.attrs.name);
  });

  agenda.on('complete', (job) => {
    console.log('Job %s finished', job.attrs.name);
  });

  agenda.on('fail:transfer tokens to users', (err, job) => {
    console.log('Job failed with error: %s', err.message);
  });

}
