const Agenda = require('agenda');
const dburl = 'mongodb://localhost:27017/bytus-ico';
const agenda = new Agenda();

const _ = require('lodash');
const storage = require('node-persist');
const path = require('path');
const newFile = path.join(__dirname, '../../../../keyValueFile');

let Web3 = require('web3');

const ethers = require('ethers');

const EventEmitter = require('events');
class MyEmitter extends EventEmitter {}
const myEmitterTokenTransferAirBounty = new MyEmitter();
myEmitterTokenTransferAirBounty.setMaxListeners(1100000000000000000);

const airdropModelFunction = require('./doa');

process.on('message', (msg) => {
  require('../../config/dbConnection');
  callThisFunc(msg);
  console.log('Child Process Started : ', msg);
});
//callThisFunc();
callThisFunc = async (msg) => {
  // console.log('req callThisFunc : ', req);
  agenda.database(dburl, 'agendaJobs');

  function graceful() {
    agenda.stop(() => {
      process.exit(0);
    });
  }

  process.on('SIGTERM', graceful);
  process.on('SIGINT', graceful);

  let message = '';
  let isValidAddressObjectArray = true;
  let transferData = msg.data;
  let privateKey = msg.data.privateKey;
  let decimals = msg.data.decimals;
  let addressArr = [];
  let balanceArr = [];
  let newJsonData;
  agenda.define('Transfer token', async (job, done) => {
    console.log('Inside token transfer agenda!!');
    try {
      // checking if valid address
      const validTokenAddress = Web3.utils.isAddress(transferData.tokenAddress);

      if(!!validTokenAddress) {
        const tokenAddress = msg.data.tokenAddress;
        // Valid token address
        console.log('valid token address');
        // token address is valid
        // now we need to look into json/csv data and analyse all addresses

        // JSON case
        const jsonData = transferData.fileData;
        const jsonParseData = JSON.parse(jsonData);
        console.log('jsonParseData : ', jsonParseData);
        // go through each object and check for address validation
        // array of address is :
        newJsonData = jsonParseData.map( item => Object.keys(item) );
        // Check if all addresses are valid
        newJsonData.map((item) => {
          // if(web3.utils.isAddress(address)) {
          if(! Web3.utils.isAddress(item[0])) {
            isValidAddressObjectArray = false
          }
        });

        if(!!isValidAddressObjectArray) {
          await storage.init({
            dir: newFile,

            stringify: JSON.stringify,

            parse: JSON.parse,

            encoding: 'utf8',

            logging: false,  // can also be custom logging function

            ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

            expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

            // in some cases, you (or some other service) might add non-valid storage files to your
            // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
            forgiveParseErrors: false

          });

          let emitSuccessRes = true;
          // Valid json data array
          console.log('valid jsonData addresses');
          // Approved
          console.log('Now we are ready to initiate airdrop');
          //initiating airdrop
          console.log('Initiating airdrop');
          // retrieving ABI
          let abiString = await storage.getItem('crowdsaleAbi');
          // console.log('abiString1  : ', abiString);
          // console.log('abiString2  : ', abiString);
          const abiArray = JSON.parse(abiString);
          let provider = ethers.getDefaultProvider('rinkeby');
          // const crowdsaleContract = new web3.eth.Contract(abiArray, tokenAddress);
          const privateKey = '461A28034CB63A30577326918B7DB0ACC52BF3748B5704BA5963E7F02E61CA9D';
          wallet = new ethers.Wallet(privateKey, provider);
          const crowdsaleContract = new ethers.Contract(tokenAddress, abiArray, wallet);
          // console.log('crowdsaleContract : ', crowdsaleContract);
          // Calling airDropTransfer function form crowdsale contract
          console.log('jsonParseData after initiating airdrop');
          jsonParseData.map( async (ObjectItem, index) => {
            const addressIndividual = (newJsonData[index])[0];
            // addressIndividualDoubleInvertedComma = addressIndividual.replace(/'/g, '\"');
            // addressArr.push(addressIndividualDoubleInvertedComma);
            addressArr.push(addressIndividual);
            const amountIndividual = ObjectItem[newJsonData[index]];
            console.log('Individual address : ', addressIndividual);
            console.log('Individual address amount to be transferred: ', amountIndividual);
            balanceArr.push(Number(amountIndividual));


            // If failure
            // emitSuccessRes = false
          });

          // calling abi method to transfer tokens (airdrop)



          console.log('addressArr : ', addressArr);
          console.log('balanceArr : ', balanceArr);
          const airdropTransfer = await crowdsaleContract
            .addAirDropAddress(
              addressArr,
              balanceArr
            );
          console.log('airdropTransfer : ', airdropTransfer);


          if(!!airdropTransfer) {
            emitSuccessRes = true;
          } else {
            emitSuccessRes = false;
          }


          // If emitSuccessRes = true
          // emit the response so that user can see the response via socker.io
          if(emitSuccessRes === true) {
            // success implies we need to store json data to airdrops database collection

            const dataAdded = await airdropModelFunction.create({
              obj: {
                tokenAddress: transferData.tokenAddress,
                decimals,
                privateKey,
                jsonData: jsonParseData
              }
            });
            console.log('dataAdded : ', dataAdded);
            process.send({ 'successMessage': 'Airbounty success' });
          }else {
            process.send({ 'failureMessage': 'Airbounty failed' });
          }

          // process.send('Success');


          // process.send(`Success : token address : ${transferData.tokenAddress}`);
        }else {
          process.send('invalid json data address');
        }
      } else {
        process.send('Invalid Token Address');
      }
    } catch(err) {
      console.log('error : ', err);
      message = 'Invalid details'
    }
  });


  agenda.on('ready', () => {

    agenda.cancel({
      name: 'Transfer token'
    }, (err, numRemoved) => {
      console.log(err, numRemoved);
      agenda.now('Transfer token');
    });

    agenda.start();
  });


  agenda.on('start', (job) => {
    console.log('Job %s starting', job.attrs.name);
  });

  agenda.on('complete', (job) => {
    console.log('Job %s finished', job.attrs.name);
  });

  agenda.on('fail:transfer tokens to users', (err, job) => {
    console.log('Job failed with error: %s', err.message);
  });

}

module.exports = {
  myEmitterTokenTransferAirBounty
};
