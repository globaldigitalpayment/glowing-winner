const Agenda = require('agenda');
const dburl = 'mongodb://localhost:27017/bytus-ico';
const modelFunction = require('../user/model');
const agenda = new Agenda();
const csv = require('csvtojson');
// const { ExcelReader, ExcelWriter } = require('node-excel-stream');
const fs = require('fs');
const _ = require('lodash');

process.on('message', (msg) => {
  require('../../config/dbConnection');
  callThisFunc(); //eslint-disable-line
  console.log('Child Process Started : ', msg);
});
//callThisFunc();
function callThisFunc() {
  agenda.database(dburl, 'agendaJobs');

  function graceful() {
    agenda.stop(() => {
      process.exit(0);
    });
  }

  process.on('SIGTERM', graceful);
  process.on('SIGINT', graceful);


  const readStream = fs.createReadStream('./bountyFiles/test.csv');

  const requiredHeaders = [
    'ERC20 Wallet Address',
    'Total Creative Stakes',
    'Total Youtube Stakes',
    'Total Twitter Stakes',
    'Total Facebook Stakes',
    'Total Translation Stakes',
    'Total Reddit Stakes',
    'Telegram Stakes',
    'Total Signature Stakes',
    'Total LinkedIn Stakes'];

  let message = '';
  agenda.define('Update Users Bounty tokens in db', (job, done) => { //eslint-disable-line
    console.log('Inside update users bounty agenda!!');
    csv().fromStream(readStream).on('header', (header) => {
      if(_.difference(requiredHeaders,header).length !== 0) {
        message = 'Invalid Headers';
        // process.send('Invalid Headers');
      }else{
        process.send('Bounty stakes are updating.');
      }
    });
    csv()
      .fromStream(readStream)
      .subscribe(async (rowData)=>{
        if(!!rowData['ERC20 Wallet Address']) {
          try {
            const user = await modelFunction.findOne({ 'personalDetails.ethAddress': rowData['ERC20 Wallet Address'] });

            if (user) {
              try {
                const params = {
                  $set : {}
                };
                let change = false;
                if (user.tokens.bounty.facebook <= rowData['Total Facebook Stakes']) {
                  params.$set['tokens.bounty.facebook'] = rowData['Total Facebook Stakes'];
                  change = true;
                }
                if (user.tokens.bounty.creative <= rowData['Total Creative Stakes']) {
                  params.$set['tokens.bounty.creative'] = rowData['Total Creative Stakes'];
                  change = true;
                }
                if (user.tokens.bounty.youtube <= rowData['Total Youtube Stakes']) {
                  params.$set['tokens.bounty.youtube'] = rowData['Total Youtube Stakes'];
                  change = true;
                }
                if (user.tokens.bounty.twitter <= rowData['Total Twitter Stakes']) {
                  params.$set['tokens.bounty.twitter'] = rowData['Total Twitter Stakes'];
                  change = true;
                }
                if (user.tokens.bounty.translation <= rowData['Total Translation Stakes']) {
                  params.$set['tokens.bounty.translation'] = rowData['Total Translation Stakes'];
                  change = true;
                }
                if (user.tokens.bounty.reddit <= rowData['Total Reddit Stakes']) {
                  params.$set['tokens.bounty.reddit'] = rowData['Total Reddit Stakes'];
                  change = true;
                }
                if (user.tokens.bounty.telegram <= rowData['Telegram Stakes']) {
                  params.$set['tokens.bounty.telegram'] = rowData['Telegram Stakes'];
                  change = true;
                }
                if (user.tokens.bounty.signature <= rowData['Total Signature Stakes']) {
                  params.$set['tokens.bounty.signature'] = rowData['Total Signature Stakes'];
                  change = true;
                }
                if (user.tokens.bounty.linkedIn <= rowData['Total LinkedIn Stakes']) {
                  params.$set['tokens.bounty.linkedIn'] = rowData['Total LinkedIn Stakes'];
                  change = true;
                }
                if (change) {
                  const test = await modelFunction.findOneAndUpdate({ 'personalDetails.ethAddress': rowData['ERC20 Wallet Address'] }, params);
                  process.send(`Stakes updated for : ${test.local.email}`);
                  console.log('Stakes updated for : ', test.local.email);
                }
              } catch(error) {
                console.log('error updating tokens : ', error);
              }
            }
          }
          catch (error) {
            console.log('Errororororoor');
          }
        }
        // });
      }).then(() => {
        console.log(message);
        if(message == 'Invalid Headers') {
          process.send('Invalid Headers');
        } else {
          process.send('Bounty stakes updated');
          console.log('done parsing');
        }
      });
  });


  agenda.on('ready', () => {

    agenda.cancel({
      name: 'Update Users Bounty tokens in db'
    }, (err, numRemoved) => {
      console.log(err, numRemoved);
      agenda.now('Update Users Bounty tokens in db');
    });

    agenda.start();
  });


  agenda.on('start', (job) => {
    console.log('Job %s starting', job.attrs.name);
  });

  agenda.on('complete', (job) => {
    console.log('Job %s finished', job.attrs.name);
  });

  agenda.on('fail:transfer tokens to users', (err, job) => { //eslint-disable-line
    console.log('Job failed with error: %s', err.message);
  });

}
