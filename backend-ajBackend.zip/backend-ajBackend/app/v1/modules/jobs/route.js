const { controller }  =require('./controller');

const authenticate = require('./../../config/authenticate');

const checkIfAdminOrSuperAdmin = (req, res, next) => {
  if (req.user.role === 'SUPER_ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};

module.exports = function (router) { // eslint-disable-line
  /**
    * @swagger
    * /jobs/agendash:
    *   get:
    *     description:
    *     tags:
    *       - jobs
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *
    */
  // router.use('/jobs/agendash', Agendash(agenda));


  /**
     * @swagger
     * /admin/updateBountyTokens:
     *   put:
     *     description: job to update users bounty tokens
     *     tags:
     *       - admin
     *     produces:
     *       - application/json
     *     responses:
     *       200:
     *
     */

  router.put('/admin/updateBountyTokens',authenticate, checkIfAdminOrSuperAdmin, controller.updateTokens);

  /**
    * @swagger
    * /admin/resetAllPassword:
    *   put:
    *     description: jobs to reset users password
    *     tags:
    *       - admin
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *
    */

  router.put('/admin/resetAllPassword', authenticate, checkIfAdminOrSuperAdmin, controller.resetPassword);

  router
    .post(
      '/admin/tokenTransfer',
      authenticate,
      checkIfAdminOrSuperAdmin,
      // celebrate(validateSchema.tokenTransfer),
      controller.tokenTransfer
    );
};
