const controller = Object.create(null);
const { fork } = require('child_process');
const MyEmitter = require('events');
const myEmitter = new MyEmitter();

const myEmitterTokenTransferAirBounty = new MyEmitter();

controller.updateTokens = async function (req, res) {
  try {
    const bountyFilePath = './app/v1/modules/jobs/updateUserBountyTokens.js';
    const forked = fork(bountyFilePath);

    forked.on('message', (msg) => {
      console.log(msg);
      myEmitter.emit('res', msg);
    });
    res.send({
      success: true,
      message: 'Bounty update started'
    });
    forked.send('Update bounty tokens!');
    ///// calling bounty job -- END
  } catch(err) {
    console.log(err);
  }

};

controller.resetPassword = async function (req, res) {
  try {
    const resetPassFilePath = './app/v1/modules/jobs/resetPassword.js';
    const forked = fork(resetPassFilePath);

    forked.on('message', (msg) => {
      console.log(msg);
      myEmitter.emit('resetPasswordRes', msg);
    });
    res.send({
      success: true,
      message: 'Reset Password Job started'
    });
    forked.send('Reset Password!');
    ///// calling bounty job -- END
  } catch(err) {
    console.log(err);
  }
};



controller.tokenTransfer = async function (req, res) {
  try {
    const tokenTransferFilePath = './app/v1/modules/jobs/tokenTransferBackend.js';
    const data = req.body;
    console.log('data : ', data);
    const forked = fork(tokenTransferFilePath);

    forked.on('message', (msg) => {
      console.log(msg);
      myEmitter.emit('res', msg,);
    });

    res.send({
      success: true,
      message: 'Token transfer Job started'
    });

    forked.on('message', async (msg) => {
      // console.log('data : ***---****', data );
      console.log('SuccessAirbounty ***', msg);
      if(!!msg.successMessage) {
        myEmitterTokenTransferAirBounty.emit('airdropRes', {
          'success': true,
          'message': 'Successfully transferred all tokens'
        });
      }else {
        myEmitterTokenTransferAirBounty.emit('airdropRes', {
          'success': true,
          'message': 'Airdrop process failed'
        });
      }
    })
    forked.send({ data: data});

    ///// calling bounty job -- END
  } catch(err) {
    console.log(err);
  }
};


module.exports = {
  controller,
  myEmitter,
  myEmitterTokenTransferAirBounty
};
