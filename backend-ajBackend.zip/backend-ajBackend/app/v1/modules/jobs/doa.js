let model = require('../Airdrop/model'),
  date = require('../../../../utils/datesHelper');

const create = function ({
  obj,
  cb = () => { } // eslint-disable-line
}) {
  return new Promise((resolve, reject) => {
    new model(obj).save((err, data) => {
      if (!err) {
        resolve(data);
        return cb(false, data);
      } else {
        reject(err);
        return cb(err, false);
      }
    });
  });

};


const obj = {
  create
};

module.exports = obj;
