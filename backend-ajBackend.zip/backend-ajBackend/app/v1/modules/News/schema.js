const { Joi } = require('celebrate');

module.exports = {
  newsImage: {
    body: Joi.object().keys({
      imageUri: Joi.any()
    })
  },
  createNews: {
    body: Joi.object().keys({
      title: Joi.string().required(),
      subject: Joi.string().required(),
      imageUri: Joi.string()
    })
  },
  editNews: {
    body: Joi.object().keys({
      title: Joi.string().required(),
      subject: Joi.string().required(),
      imageUri: Joi.string()
    }),
    params: Joi.object().keys({
      _id: Joi.string().required()
    })
  },
  deleteNews: {
    params: Joi.object().keys({
      _id: Joi.string().required()
    })
  }
};
