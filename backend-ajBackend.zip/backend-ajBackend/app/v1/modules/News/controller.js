const faqModel = require('../News/model');
const modelFunction = require('./doa');
const controller = Object.create(null);


controller.newsImage = async(req, res, next) => {
  const userId = req.user._id;

  if (!!req.file) {
    const image = req.file;
    console.log('image : ', image);
    console.log('image location : ', image.location);
    return res
      .status(200)
      .json({
        success: true,
        message: 'image stored successfully',
        imageUri: image.location
      });
}else {
  console.log('req.file : ', req.file);
  return res
    .status(200)
    .json({
      success: false,
      message: 'no image to store'
    });
}

};

controller.createNews = async (req, res, next) => {
  const params = {};
  params.title = req.body.title,
  params.subject = req.body.subject
  req.body.imageUri ?
    (params.imageUri = req.body.imageUri)
    :
    null
  let createData;
  try {
    createData = await modelFunction.create({ obj: params })
  }catch(err) {
    next(err);
  }

  return res
    .status(200)
    .json({
      success: true,
      data: createData,
      message: 'News Successfully Submitted'
    });
};

controller.editNews = async(req, res, next) => {
  const id = {
    _id: req.params._id
  };
  const data = {};
  data.title = req.body.title,
  data.subject = req.body.subject,
  req.body.imageUri ?
    (data.imageUri = req.body.imageUri)
    :
    null
  const options = {
    new: true
  };

  let findAndUpdate;
  try {
    findAndUpdate = await modelFunction.findByIdAndUpdate({
      id,
      data,
      options
    });
  }catch(err) {
    next(err);
  }

  if(!!findAndUpdate) {
    return res
      .status(200)
      .json({
        success: true,
        data: findAndUpdate,
        message: 'Successfully edited'
      });
  }else {
    return res
      .status(200)
      .json({
        success: false,
        message: 'No such News exists'
      });
  }

};

controller.deleteNews = async (req, res, next) => {
  const userId = req.params._id;

  let result;
  try{
    // its just parameter name its deleting news
    result = await modelFunction.deleteUser(userId)
  }catch(err) {
    next(err);
  }
  if(result) {
    return res
      .status(200)
      .json({
        success: true,
        message: 'Successfully deleted'
      });
  }else {
    return res
      .status(200)
      .json({
        success: false,
        message: 'Invalid Id'
      });
  }

};

controller.getAllNews = async (req, res, next) => {
  const params = {};
  let result;
  try{
    result = await modelFunction.find({ params: params })
  }catch(err) {
    next(err);
  }
  if(result.length > 0) {
    return res
      .status(200)
      .json({
        success: true,
        result: result,
        message: 'Successfully got all news'
      });
  }else {
    return res
      .status(200)
      .json({
        success: true,
        result: [],
        message: 'No news'
      });
  }
};

module.exports = controller;
