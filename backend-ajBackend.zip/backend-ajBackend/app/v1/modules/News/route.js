const { celebrate } = require('celebrate'),
  controller = require('./controller'),
  multer = require('multer'),
  multerS3 = require('multer-s3'),
  s3 = require('app/v1/config/s3'),
  { removeQueryFalsy } = require('utils/helper');

const imageMulter = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'zineum-ico-kyc',
    acl: 'public-read',
    metadata: function (req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function (req, file, cb) {
      const originalName = file.originalname.split('.');
      const ext = `.${originalName[originalName.length - 1]}`;
      cb(null,originalName + Date.now().toString() + ext);
    }
  })
});

const authenticate = require('./../../config/authenticate');
const validateSchema = require('./schema');

const checkIfAdmin = (req, res, next) => {
  if (req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({ success: false, message: 'Invalid Access', description: '' });
  }
};

const checkIfAdminOrSuperAdmin = (req, res, next) => {
//   console.log(req.user);
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};


module.exports = function (router) {
    /**
       * @swagger
       *   /user/news :
       *   get:
       *     description: get all news
       *     tags:
       *       - News
       *     produces:
       *       - application/json
       *
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .get(
      '/user/news',
      controller.getAllNews
    );

    /**
       * @swagger
       *   /admin/news/:_id :
       *   get:
       *     description: delete a news
       *     tags:
       *       - News
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: x-auth-token
       *         in: header
       *         schema:
       *         type: string
       *         required: true
       *       - name: _id
       *         description: _id.
       *         in: params
       *         type: string
       *         required: true
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .delete(
      '/admin/news/:_id',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.deleteNews),
      controller.deleteNews
    );

    /**
       * @swagger
       *   /admin/news/image :
       *   patch:
       *     description: no storing only giving imageUri of image as response
       *     tags:
       *       - News
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: x-auth-token
       *         in: header
       *         schema:
       *         type: string
       *         required: true
       *       - name: imageUri
       *         description: image
       *         in: body
       *         type: string
       *         required: true
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .patch(
      '/admin/news/image',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.newsImage),
      imageMulter.single('imageUri'),
      controller.newsImage
    );


    /**
       * @swagger
       *   /admin/news :
       *   post:
       *     description: CREATE news
       *     tags:
       *       - News
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: x-auth-token
       *         in: header
       *         schema:
       *         type: string
       *         required: true
       *       - name: title
       *         description: title
       *         in: body
       *         type: string
       *         required: true
       *       - name: subject
       *         description: subject
       *         in: body
       *         type: string
       *         required: true
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .post(
      '/admin/news',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.createNews),
      controller.createNews
    );

    /**
       * @swagger
       *   /admin/news/:_id :
       *   put:
       *     description: edit a news
       *     tags:
       *       - News
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: x-auth-token
       *         in: header
       *         schema:
       *         type: string
       *         required: true
       *       - name: title
       *         description: title
       *         in: body
       *         type: string
       *         required: true
       *       - name: subject
       *         description: subject.
       *         in: body
       *         type: string
       *         required: true
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .put(
      '/admin/news/:_id',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.editNews),
      controller.editNews
    );
};
