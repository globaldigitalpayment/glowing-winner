const { Joi } = require('celebrate');

module.exports = {
  // mnemonicCall: {
  //   body: Joi.object().keys({
  //     mnemonicPhrase: Joi.string().required(),
  //     argumentsData: Joi
  //   })
  // },
  tokenTransfer: {
    body: Joi.object().keys({
      tokenAddress: Joi.string().required(),
      decimals: Joi.number().required(),
      fileType: Joi.string().valid('json', 'csv').required(),
      fileData: Joi.string().required(),
      trnxOption: Joi.string().valid('backend').required(),
      privateKey: Joi.string().required()
    })
  },
  contractData: {
    body: Joi.object().keys({
      name: Joi.string().required(),
      address: Joi.string().required(),
      network: Joi.string().required(),
      tokenType: Joi.any().valid('token', 'crowdsale', 'airdropCentral', 'airdroper'),
      abi: Joi.string().required(),
      useInDashboard: Joi.boolean()
    })
  },
  blockVerify: {
    params: Joi.object().keys({
      _id: Joi.string().required()
    }),
    body: Joi.object().keys({
      blocked: Joi.boolean(),
      verify: Joi.boolean()
    })
  },
  updateContractData: {
    body: Joi.object().keys({
      name: Joi.string().required(),
      address: Joi.string().required(),
      network: Joi.string().required(),
      tokenType:Joi.any().valid('token', 'crowdsale', 'airdropCentral', 'airdroper'),
      abi: Joi.string().required(),
      useInDashboard: Joi.boolean()

    })
  },
  listSubAdmins: {
    query: Joi.object().keys({
      page: Joi.number(),
      limit: Joi.number(),
      sortBy: Joi.any().valid('email', 'createdBy', 'created_at'),
      order: Joi.number().valid(1, -1),
      email: Joi.string(),
      createdBy: Joi.string(),
      minCreatedAt: Joi.date().iso(),
      maxCreatedAt: Joi.date().iso()
    })
  },
  listUsers: {
    query: Joi.object().keys({
      userState: Joi.any().valid('USER', 'SUBSCRIBER'),
      kycStatus: Joi.any(),
      page: Joi.number(),
      limit: Joi.number(),
      sortBy: Joi.any().valid('fullName', 'created_at', 'referralTokens', 'totalTokens'),
      order: Joi.number().valid(1, -1),
      name: Joi.string(),
      phone: Joi.string(),
      isAccVerified: Joi.boolean(),
      tokensTotalLL: Joi.number(),
      tokensTotalUL: Joi.number(),
      tokensPrivateSaleLL: Joi.number(),
      tokensPrivateSaleUL: Joi.number(),
      tokensPreSaleLL: Joi.number(),
      tokensPreSaleUL: Joi.number(),
      tokensCrowdSaleLL: Joi.number(),
      tokensCrowdSaleUL: Joi.number(),
      tokensReferralLL: Joi.number(),
      tokensReferralUL: Joi.number(),
      tokensVoteLL: Joi.number(),
      tokensVoteUL: Joi.number(),
      referTotalLL: Joi.number(),
      referTotalUL: Joi.number(),
      referSuccessLL: Joi.number(),
      referSuccessUL: Joi.number(),
      referCode: Joi.string(),
      refereeId: Joi.string(),
      isVoted: Joi.boolean(),
      email: Joi.string(),
      is2FAEnabled: Joi.boolean(),
      minCreatedAt: Joi.date().iso(),
      maxCreatedAt: Joi.date().iso()
    })
  },
  updateKycStatus: {
    body: Joi.object().keys({
      userId: Joi.string().required(),
      kycStatus: Joi.any().valid('ACCEPTED', 'REJECTED', 'REPORTED','DOCUMENTS'),
      reason: Joi.string(),
      reportIssue: Joi.any()
    })
  },
  updateTokens: {
    params: Joi.object().keys({
      userId: Joi.string().required(),
      tokens: Joi.number().integer().min(0).required()
    })
  },
  sendMail: {
    body: Joi.object().keys({
      email: Joi.string().required(),
      message: Joi.string().required()
    })
  },
  constAddressFile: {
    body: Joi.object().keys({
      ethAddress: Joi.string(),
      btcAddress: Joi.string()
    })
  },
  keyValueFile: {
    body: Joi.object().keys({
      tokenUsd: Joi.number(),
      ethUsd: Joi.number(),
      btcUsd: Joi.number(),
      stage: Joi.string(),
      ethAddress: Joi.string(),
      btcAddress: Joi.string(),
      bonus: Joi.number(),
      //@aj
      // discount: Joi.number(),
      staticDiscount: Joi.number(),
      //----@aj
      minInvest: Joi.number(),
      privateSaleTokenUsd: Joi.number(),
      preSaleTokenUsd: Joi.number(),
      mainSaleTokenUsd: Joi.number(),
      status: Joi.boolean(),
      amountPercent: Joi.number(),
      liveBonus : Joi.number(),
      liveStage : Joi.string(),
      tokenAddress: Joi.string(),
      crowdsaleAddress: Joi.string(),
      staticTokenUsd: Joi.number(),
      staticEthUsd: Joi.number(),
      staticBtcUsd: Joi.number(),
      staticStage: Joi.string(),
      staticEthAddress: Joi.string(),
      staticBtcAddress: Joi.string(),
      staticUSDTAddress:Joi.string(),
      staticBonus: Joi.number(),
      staticMinInvest: Joi.number(),
      staticPrivateSaleTokenUsd: Joi.number(),
      staticPreSaleTokenUsd: Joi.number(),
      staticMainSaleTokenUsd: Joi.number(),
      staticStatus: Joi.boolean(),
      staticAmountPercent: Joi.number(),
      staticLiveBonus : Joi.number(),
      staticLiveStage : Joi.string(),
      staticTokenAddress: Joi.string(),
      staticCrowdsaleAddress: Joi.string(),
      static: Joi.boolean()

    })
  }
};
