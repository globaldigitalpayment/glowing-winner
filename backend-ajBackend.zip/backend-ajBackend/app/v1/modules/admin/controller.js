const userModelFunction = require('../user/doa'),
  moment = require('moment'),
  trxnModelFunction = require('./../transaction/doa'),
  trxnModel = require('./../transaction/model'),
  contractModel = require('../contracts/model'),
  trxnController = require('./../transaction/controller'),
  mailer = require('config/nodemailer'),
  errorHandler = require('utils/errorHandler'),
  mongoose = require('mongoose'),
  fs = require('fs'),
  path = require('path'),
  constants = require('../../../../config/constants.js'),
  logger = require('config/logger'),
  storage = require('node-persist'),
  rpn = require('request-promise-native');

const controller = Object.create(null);
// const filePath = path.join(__dirname, '../../../../keys/keyValueFile.json');
const newFile = path.join(__dirname, '../../../../keyValueFile');
controller.dashboard = async (req, res, next) => {
  const userId = req.user.id;  //is2FAEnabled : userInfo.local['2FA'].isEnabled
  let statResults, adminProfileResult;
  const match = {
    'role': 'USER'
    // ,
    // 'deleted' : false
  };
  const group = {
    _id: '$role',
    referTotal: { $sum: '$refer.totalUsed' },
    referSuccess: { $sum: '$refer.success' },
    tokensTotal: { $sum: '$tokens.total' },
    tokensReferral: { $sum: '$tokens.referral' },
    totalUsers: { $sum: 1 }
  };

  // const params = {
  //   '_id': userId
  // };

  // const selector = {
  //   'local.2FA': 1,
  //   'role': 1,
  //   'permissions': 1
  // };

  let resObj = {
    referralTotal: 0,
    referralSuccess: 0,
    tokensTotal: 0,
    tokensReferral: 0,
    totalUsers: 0
  };

  const P1 = userModelFunction.findById({ id: userId });
  const P2 = userModelFunction.aggregatePipeline({ match, group }); //eslint-disable-line
  const P3 = trxnModel.find({ 'status': 'confirmed' }).distinct('initiatedBy.id');

  Promise.all([P1, P2, P3])
    .then(results => {
      adminProfileResult = results[0];
      statResults = results[1];
      contributedUsers = results[2].length;
      if (statResults) {
        if (!!statResults && statResults.length > 0) {
          resObj = statResults[0];
        }
        resObj.is2FAEnabled = adminProfileResult.local['2FA'].isEnabled ? adminProfileResult.local['2FA'].isEnabled : false;
        resObj.role = adminProfileResult.role;
        resObj.contributedUsers = contributedUsers;
        resObj.permissions = adminProfileResult.permissions;
        return res.status(200).json({ success: true, statResults: resObj });
      } else {
        const { status, message, description } = errorHandler({ errorType: '', message: 'Something went wrong!!', description: '' });
        return res.status(status).json({ success: false, message, description });
      }
    })
    .catch(err => {
      next(err);
    });

};


controller.getCryptoPrices = async (req, res, next) => {

  const mainOptions = {
    json: true // Automatically parses the JSON string in the response
  };

  try {
    const data = {};
    const btcReqOpt = Object.assign({}, mainOptions);
    btcReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=XXBTZUSD';
    const result = await rpn(btcReqOpt);
    //console.log(result.result.XXBTZUSD.a[0], 'cureent result');
    data.btcPrice = result.result.XXBTZUSD.a[0];

    const ethReqOpt = Object.assign({}, mainOptions);
    ethReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=XETHZUSD';
    const result1 = await rpn(ethReqOpt);

    //console.log(result, 'cureent result');
    data.ethPrice = result1.result.XETHZUSD.a[0];

    const usdtReqOpt = Object.assign({}, mainOptions);
    usdtReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=USDTZUSD';
    const result2 = await rpn(usdtReqOpt);

    data.usdtPrice = result2.result.USDTZUSD.a[0];

    return res.status(200).json({
      data: data,
      success: true
    });

  } catch (error) {
    //next(error);
    logger.error('Unable to fetch live price trxn from kraken =>', error);

    const resData = {
      success: true,
      message: 'Live Prices and Addresses received',
      data: {}
    };
    // eslint-disable-next-line no-shadow
    const mainOptions = {
      json: true // Automatically parses the JSON string in the response
    };
    const btcReqOpt = Object.assign({}, mainOptions);
    btcReqOpt.uri = 'https://apiv2.bitcoinaverage.com/convert/global?from=BTC&to=USD';
    const ethReqOpt = Object.assign({}, mainOptions);
    ethReqOpt.uri = 'https://apiv2.bitcoinaverage.com/convert/global?from=ETH&to=USD';

    Promise.all([rpn(btcReqOpt), rpn(ethReqOpt)]).then((results) => {
      if (results[0].success && results[1].success) {
        resData.data.btcPrice = Math.round(results[0].price);
        resData.data.ethPrice = Math.round(results[1].price);
      }
      return res.status(200).json(resData);
    }).catch((err) => {
      logger.error('Unable to fetch live price trxn  from bitcoin average =>', err);
      return next(err);
    });
  }


};

// user filters on type (eth,btc , usd ) and registration date (form and to)
// Requested => all (no filter)
// purchased => confirmed
// admin/userFilter/:userId/:type
// type => "requested" or "purchased"
// controller.userFilterType = async (req, res, next) => {
//   let paramF;
//   const paramF = {
//     role : 'USER'
//   };
//
//   paramF.tokens = { '$gte' : req.body.demMin, '$lte' : req.body.demMax };
//
//
//   // const findUserData = await trxnModelFunction
//   //   .find({
//   //     params:
//   //   })
// };

controller.getAllSubAdmins = async (req, res, next) => {
  const page = req.query.page && req.query.page > 0 ? parseInt(req.query.page) : 1,
    limit = req.query.limit && req.query.limit > 0 ? parseInt(req.query.limit) : 10;

  let sortBy = req.query.sortBy, sortOrder;
  // default descending
  sortOrder = req.query.order ? req.query.order : -1;
  if (sortBy === 'email') {
    sortBy = 'local.email';
  } else if (sortBy === 'createdBy') {
    sortBy = 'createdBy';
  } else {
    sortBy = 'created_at';
    sortOrder = -1;
  }

  const params = {
    role : 'ADMIN'
  };

  if (req.query.email) {
    params['local.email'] = { '$regex' : req.query.email };
  }
  if (req.query.createdBy) {
    params['createdBy'] = req.query.createdBy;
  }

  if(!!req.query.minCreatedAt && !!req.query.maxCreatedAt) {
    if(Date.parse(req.query.maxCreatedAt) < Date.parse(req.query.minCreatedAt)) {
      console.log('min date is greater');
      return res
        .status(400)
        .json({
          success: false,
          message: 'Bad Request: maxCreatedAt must be greater then minCreatedAt'
        });
    }else {
      let minCreatedAt = moment(req.query.minCreatedAt).set({
        'hour': 00,
        'minute': 00,
        'second': 00,
        'millisecond': 000
      });
      let maxCreatedAt = moment(req.query.maxCreatedAt).set({
        'hour': 23,
        'minute': 59,
        'second': 59,
        'millisecond': 999
      });
      params.created_at = {
        $gte: minCreatedAt,
        $lte: maxCreatedAt
      };
    }
  }
  if(!!req.query.minCreatedAt && !req.query.maxCreatedAt){
    let minCreatedAt = moment(req.query.minCreatedAt).set({
      'hour': 00,
      'minute': 00,
      'second': 00,
      'millisecond': 000
    });
    params.created_at = {
      $gte: minCreatedAt
    };
  }

  if(!req.query.minCreatedAt && !!req.query.maxCreatedAt){
    let maxCreatedAt = moment(req.query.maxCreatedAt).set({
      'hour': 23,
      'minute': 59,
      'second': 59,
      'millisecond': 999
    });
    params.created_at = {
      $lte: maxCreatedAt
    };
  }

  const selector = {
    role: 1,
    local: 1,
    email: 1,
    permissions: 1,
    created_at: 1,
    updated_at: 1,
    createdBy: 1
  };

  const sort = {
    [sortBy]: sortOrder
  };
  //params = {'local.email' : 'poil@yopmail.com' };

  const P_totalCount = userModelFunction.count({ params });
  var P_users = userModelFunction.find({ // eslint-disable-line no-var
    params,
    sort,
    selector,
    skip: (page - 1) * limit,
    limit: limit
  });

  Promise.all([P_totalCount, P_users]).then((results) => {
    res.status(200).json({
      success: true,
      totalUsers: results[0],
      users: results[1],
      nextPage: page * limit >= results[0] ? false : true
    });
  }).catch((error) => {
    next(error);
  });

};


controller.getAllUsers = async (req, res, next) => {
  const page = req.query.page && req.query.page > 0 ? parseInt(req.query.page) : 1,
    limit = req.query.limit && req.query.limit > 0 ? parseInt(req.query.limit) : 10;

  let sortBy = req.query.sortBy, sortOrder;
  // default descending
  sortOrder = req.query.order ? req.query.order : -1;
  if (sortBy === 'fullName') {
    sortBy = 'personalDetails.fullName';
  } else if (sortBy === 'created_at') {
    sortBy = 'created_at';
  } else if (sortBy === 'referralTokens') {
    sortBy = 'tokens.referral';
  } else if (sortBy === 'totalTokens') {
    sortBy = 'tokens.total';
  } else {
    sortBy = 'created_at';
    sortOrder = -1;
  }

  const params = {
    role : 'USER'
  };
  if (req.query.userType) {
    params.userState = req.query.userType;
  }
  if (req.query.kycStatus) {
    params.kycStatus = req.query.kycStatus;
  }
  if (req.query.name) {
    params['personalDetails.fullName'] = { '$regex' : req.query.name };
  }
  if (req.query.phone) {
    params['personalDetails.phoneNumber'] = req.query.phone;
  }
  if (req.query.isAccVerified) {
    params['accountVerify.isVerified'] = req.query.isAccVerified;
  }
  if (req.query.tokensTotalLL) {
    params['tokens.total'] = { '$gte' : req.query.tokensTotalLL };
  }
  if (req.query.tokensTotalUL) {
    params['tokens.total'] = { '$lte' : req.query.tokensTotalUL };
  }
  if (req.query.tokensPrivateSaleLL) {
    params['tokens.privateSale'] = { '$gte' : req.query.tokensPrivateSaleLL };
  }
  if (req.query.tokensPrivateSaleUL) {
    params['tokens.privateSale'] = { '$lte' : req.query.tokensPrivateSaleUL };
  }
  if (req.query.tokensPreSaleLL) {
    params['tokens.preSale'] = { '$gte' : req.query.tokensPreSaleLL };
  }
  if (req.query.tokensPreSaleUL) {
    params['tokens.preSale'] = { '$lte' : req.query.tokensPreSaleUL };
  }
  if (req.query.tokensCrowdSaleLL) {
    params['tokens.crowdSale'] = { '$gte' : req.query.tokensCrowdSaleLL };
  }
  if (req.query.tokensCrowdSaleUL) {
    params['tokens.crowdSale'] = { '$lte' : req.query.tokensCrowdSaleUL };
  }
  if (req.query.tokensReferralLL) {
    params['tokens.referral'] = { '$gte' : req.query.tokensReferralLL };
  }
  if (req.query.tokensReferralUL) {
    params['tokens.referral'] = { '$lte' : req.query.tokensReferralUL };
  }
  if (req.query.tokensVoteLL) {
    params['tokens.vote'] = { '$gte' : req.query.tokensVoteLL };
  }
  if (req.query.tokensVoteUL) {
    params['tokens.vote'] = { '$lte' : req.query.tokensVoteUL };
  }
  if (req.query.referTotalLL) {
    params['refer.totalUsed'] =  { '$gte' : req.query.referTotalLL };
  }
  if (req.query.referTotalUL) {
    params['refer.totalUsed'] =  { '$lte' : req.query.referTotalUL };
  }
  if (req.query.referSuccessLL) {
    params['refer.success'] =  { '$gte' : req.query.referSuccessLL };
  }
  if (req.query.referSuccessUL) {
    params['refer.success'] =  { '$lte' : req.query.referSuccessUL };
  }
  if (req.query.referCode) {
    params['refer.code'] = req.query.referCode;
  }
  if (req.query.refereeId) {
    params['refer.referee'] = req.query.refereeId;
  }
  if (req.query.isVoted) {
    params['refer.voted'] = req.query.isVoted;
  }
  if (req.query.email) {
    params['local.email'] = { '$regex' : req.query.email };
  }
  if (req.query.is2FAEnabled) {
    params['local.2FA.isEnabled'] = req.query.is2FAEnabled;
  }
  if(req.query.kycStatus) {
    params.kycStatus = req.query.kycStatus;
  }

  if(!!req.query.minCreatedAt && !!req.query.maxCreatedAt) {
    if(Date.parse(req.query.maxCreatedAt) < Date.parse(req.query.minCreatedAt)) {
      console.log('min date is greater');
      return res
        .status(400)
        .json({
          success: false,
          message: 'Bad Request: maxCreatedAt must be greater then minCreatedAt'
        });
    }else {
      let minCreatedAt = moment(req.query.minCreatedAt).set({
        'hour': 00,
        'minute': 00,
        'second': 00,
        'millisecond': 000
      });
      let maxCreatedAt = moment(req.query.maxCreatedAt).set({
        'hour': 23,
        'minute': 59,
        'second': 59,
        'millisecond': 999
      });
      params.created_at = {
        $gte: minCreatedAt,
        $lte: maxCreatedAt
      };
    }
  }
  if(!!req.query.minCreatedAt && !req.query.maxCreatedAt){
    let minCreatedAt = moment(req.query.minCreatedAt).set({
      'hour': 00,
      'minute': 00,
      'second': 00,
      'millisecond': 000
    });
    params.created_at = {
      $gte: minCreatedAt
    };
  }

  if(!req.query.minCreatedAt && !!req.query.maxCreatedAt){
    let maxCreatedAt = moment(req.query.maxCreatedAt).set({
      'hour': 23,
      'minute': 59,
      'second': 59,
      'millisecond': 999
    });
    params.created_at = {
      $lte: maxCreatedAt
    };
  }

  const selector = {
    personalDetails: 1,
    kycStatus: 1,
    kycDetails: 1,
    userState: 1,
    accountState: 1,
    isBlocked: 1,
    isActive: 1,
    tokens: 1,
    refer: 1,
    email: 1,
    contributionRange: 1,
    created_at: 1,
    updated_at: 1,
    createdBy: 1,
    isWhitelisted: 1,
    accountVerify: 1
  };

  const sort = {
    [sortBy]: sortOrder
  };
  //params = {'local.email' : 'poil@yopmail.com' };

  const P_totalCount = userModelFunction.count({ params });
  var P_users = userModelFunction.find({ // eslint-disable-line no-var
    params,
    sort,
    selector,
    skip: (page - 1) * limit,
    limit: limit
  });

  //@TODO: rohan output in this format
  // var output = {
  //   users: null,
  //   pages: {
  //     current: options.page,
  //     prev: 0,
  //     hasPrev: false,
  //     next: 0,
  //     hasNext: false,
  //     total: 0
  //   },
  //   items: {
  //     begin: ((options.page * options.limit) - options.limit) + 1,
  //     end: options.page * options.limit,
  //     total: 0
  //   }
  // };

  Promise.all([P_totalCount, P_users]).then((results) => {
    res.status(200).json({
      success: true,
      totalUsers: results[0],
      users: results[1],
      nextPage: page * limit >= results[0] ? false : true
    });
  }).catch((error) => {
    next(error);
  });

};


controller.createContract = async (req, res) => {
  await storage.init({
    dir: newFile,

    stringify: JSON.stringify,

    parse: JSON.parse,

    encoding: 'utf8',

    logging: false,  // can also be custom logging function

    ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

    expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

    // in some cases, you (or some other service) might add non-valid storage files to your
    // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
    forgiveParseErrors: false

  });
  contractModel.find({
    'useInDashboard':true,
    'tokenType':req.body.tokenType
  }, async (err, contract) => {

    if(contract.length > 0 && req.body.useInDashboard) {
      res.status(404).json({ success: false, message: `You can not create multiple ${req.body.tokenType} Contracts with status true liveInDashBoard` });
    } else {
      const newContract = {};
      newContract.name = req.body.name;
      newContract.address = req.body.address;
      newContract.network = req.body.network;
      newContract.tokenType = req.body.tokenType;
      newContract.abi = req.body.abi;
      newContract.useInDashboard = req.body.useInDashboard;

      // console.log('use in dashboard ', req.body.useInDashboard);
      // console.log('network',req.body.network);

      if (!!req.body.useInDashboard) {
        if(req.body.tokenType === 'token') {
          await storage.setItem('tokenAddress',req.body.address);
          await storage.setItem('tokenAbi',req.body.abi);
        } else if(req.body.tokenType === 'airdropCentral') {
          await storage.setItem('airdropCentralAddress',req.body.address);
          await storage.setItem('airdropCentralAbi',req.body.abi);
          const getABI = await storage.getItem('airdropCentralAbi')
          console.log('airdropCentralAbi : ', getABI);
          // we need network of crowdsale
          if (!!req.body.network) {
            await storage.setItem('network', req.body.network);
          }
        } else if(req.body.tokenType === 'airdroper') {
            await storage.setItem('airdroperAddress',req.body.address);
            await storage.setItem('airdroperAbi',req.body.abi);
            const getABI = await storage.getItem('airdroperAbi')
            console.log('airdroperAbi : ', getABI);
            // we need network of crowdsale
            if (!!req.body.network) {
              await storage.setItem('network', req.body.network);
            }
          } else if(req.body.tokenType === 'crowdsale') {
          await storage.setItem('crowdsaleAddress',req.body.address);
          await storage.setItem('crowdsaleAbi',req.body.abi);
          const getABI = await storage.getItem('crowdsaleAbi')
          console.log('crowdsaleAbi : ', getABI);
          // we need network of crowdsale
          if (!!req.body.network) {
            await storage.setItem('network', req.body.network);
          }
        }
      }

      new contractModel(newContract)
        .save()
        .then((data)=>{
          res.status(200).json({ success: true, data,message:'Successfully created contract' });
        })
        .catch(err => {
          res.status(404).json({ success: false, message: err });
        });
    }

  }).catch(err => {
    res.status(404).json({ success: false, description:err, msg: 'No Live Contract Exist' });
  });


};

controller.findContract = (req, res) => {

  const selector = {
    timestamps: 0,
    tokenPrice: 0
  };

  contractModel
    .findById(req.params._id, selector)
    .then((data)=>{
      if(!!data) {
        return res.status(200).json({ success: true, data });
      }
      res.status(404).json({ success: false, msg: '_id not found' });
    })
    .catch(err => {
      res.status(404).json({ success: false, msg: err });
    });
};


controller.findLiveContract = (req, res) => {
  contractModel.findOne({
    'useInDashboard':true,
    'tokenType' : req.params.tokenType
  }, (err, contract) => {

    return res.status(200).json({ success: true, data: contract });
  }).catch(err => {
    res.status(404).json({ success: false, description:err, msg: 'No Live Contract Exist' });
  });

};

controller.updateContract = async (req, res) => {
  await storage.init({
    dir: newFile,
    stringify: JSON.stringify,
    parse: JSON.parse,
    encoding: 'utf8',
    logging: false, // can also be custom logging function
    ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS
    expiredInterval: 2 * 60 * 1000,
    // every 2 minutes the process will clean-up the expired cache
    // in some cases, you (or some other service) might add non-valid storage files to your
    // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
    forgiveParseErrors: false
});

  const params = {};
  if(!!req.body.name) {
    params.name = req.body.name;
  }
  if(!!req.body.address) {
    params.address = req.body.address;
  }
  if(!!req.body.network) {
    params.network = req.body.network;
  }
  if(!!req.body.tokenType) {
    params.tokenType = req.body.tokenType;
  }
  if(!!req.body.abi) {
    params.abi = req.body.abi;
  }

  // params.timestamps = {};
  // params.timestamps.updatedAt = new Date();


  params.useInDashboard = req.body.useInDashboard;

  if (!!req.body.useInDashboard) {
    if (req.body.tokenType === 'token') {
      await storage.setItem('tokenAddress', req.body.address);
      await storage.setItem('tokenAbi', req.body.abi);
    } else if (req.body.tokenType === 'airdropCentral') {
      await storage.setItem('airdropCentralAddress', req.body.address);
      await storage.setItem('airdropCentralAbi', req.body.abi);
      // we need network of crowdsale
      if (!!req.body.network) {
        await storage.setItem('network', req.body.network);
      }
    }else if (req.body.tokenType === 'airdroper') {
     await storage.setItem('airdroperAddress', req.body.address);
     await storage.setItem('airdroperAbi', req.body.abi);
     // we need network of crowdsale
     if (!!req.body.network) {
       await storage.setItem('network', req.body.network);
     }
     console.log('airdroperAddress : ', await storage.getItem('airdroperAddress'));
     console.log('airdroperAbi :', await storage.getItem('airdroperAbi'));
   }else if (req.body.tokenType === 'crowdsale') {
      await storage.setItem('crowdsaleAddress', req.body.address);
      await storage.setItem('crowdsaleAbi', req.body.abi);
      // we need network of crowdsale
      if (!!req.body.network) {
        await storage.setItem('network', req.body.network);
      }
    }
  }

  console.log('params : ', params);

  const contractDataFind = await contractModel.find({
    useInDashboard : req.body.useInDashboard,
    tokenType: req.body.tokenType
  });

  console.log('contractDataFind : ', contractDataFind);

  if(contractDataFind.length == 0) {
    contractModel
      .findByIdAndUpdate({ _id: req.params._id }, { $set: params } )
      .then((data)=>{
        if(!!data) {
          return res.status(200).json({ success: true, msg: 'Successfully Updated' });
        }else {
          return res.status(404).json({ success: false, msg: 'No such contract exists' });
        }
      })
      .catch(err => {
        return res.status(404).json({ success: false, msg: 'Invalid ID' });
      });
  } else {
    return res.status(200).json({ success: false, msg: 'A live contract with desired type already exists' });
  }


};

controller.deleteContract = async (req, res) => {
  await storage.init({
    dir: newFile,

    stringify: JSON.stringify,

    parse: JSON.parse,

    encoding: 'utf8',

    logging: false,  // can also be custom logging function

    ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

    expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

    // in some cases, you (or some other service) might add non-valid storage files to your
    // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
    forgiveParseErrors: false

  });
  contractModel
    .findByIdAndRemove({ _id: req.params._id })
    .then((result)=>{
      console.log('result: ', result);
      if(result.tokenType === 'crowdsale') {
        storage.removeItem('crowdsaleAddress');
      } else if(result.tokenType === 'token') {
        storage.removeItem('tokenAddress');
      }
      if(!!result) {
        return res.status(200).json({ success: true, msg: 'Successfully deleted contract' });
      }else {
        return res.status(404).json({ success: false, msg: 'No such contract exists' });
      }

    })
    .catch(err => {
      return res.status(404).json({ success: false, msg: 'Invalid ID' });
    });
};


controller.getAllContract = (req, res) => {

  const selector = {
    timestamps: 0,
    tokenPrice: 0
  };

  contractModel
    .find({}, selector)
    .then((data)=>{
      return res.status(200).json({ success: true, data });
    })
    .catch(err => {
      res.status(404).json({ success: false, msg: err });
    });
};


controller.getUserDetails = async (req, res, next) => {
  const userId = req.params.userId;
  const params = {
    _id: userId,
    role: 'USER'
  };
  if (!mongoose.Types.ObjectId.isValid(userId)) {
    const { status, message, description } = errorHandler({ errorType: '', message: 'User id not valid', description: '' });
    return res.status(status).json({ success: false, message, description });
  }

  //@TODO: check name key , now we have fullName
  const selector = {
    'local.2FA.isEnabled': 1,
    'local.email': 1,
    'personalDetails': 1,
    'facebook': 1,
    'google': 1,
    'userState': 1,
    'accountState': 1,
    'isBlocked': 1,
    'isActive': 1,
    'refer.totalUsed': 1,
    'refer.success': 1,
    'tokens.total': 1,
    'tokens.referral': 1,
    'isWhitelisted': 1,
    'email': 1,
    'accountVerify': 1
  };
  try {
    var user = await userModelFunction.findOne({ // eslint-disable-line no-var
      params,
      selector
    });
  } catch (error) {
    next(error);
  }
  if (user) {
    res.status(200).json({
      success: true,
      user: user
    });
  } else {
    const { status, message, description } = errorHandler({ errorType: '', message: 'User not found', description: '' });
    res.status(status).json({ success: false, message, description });
  }

};

controller.updateKycStatus = async (req, res, next) => {
  const { userId, kycStatus } = req.body;
  const verifiedBy = req.user.local.email;
  const verifiedAt = new Date();
  const query = {
    _id: userId
  };
  let params = {
    $set: {
      kycStatus ,
      ['kycDetails.verifiedBy'] : verifiedBy,
      ['kycDetails.verifiedAt'] : verifiedAt
    }
  };
  if (kycStatus === 'REJECTED') {
    params = {
      $set: {
        kycStatus,
        ['kycDetails.verifiedBy'] : verifiedBy,
        ['kycDetails.verifiedAt'] : verifiedAt

      },
      $push: {
        ['kycDetails.rejectReason'] : req.body.reason
      }
    };
  }

  if (kycStatus === 'REPORTED') {
    params = {
      $set: {
        kycStatus,
        ['kycDetails.verifiedBy'] : verifiedBy,
        ['kycDetails.verifiedAt'] : verifiedAt,
        ['kycDetails.reportIssue']: req.body.reportIssue
      }
    };
  }

  if (kycStatus === 'DOCUMENTS') {
    params = {
      $set: {
        kycStatus,
        ['kycDetails.verifiedBy'] : verifiedBy,
        ['kycDetails.verifiedAt'] : verifiedAt,
        ['kycDetails.documentsRequired']: req.body.reason
      }
    };
  }


  try {
    var result = await userModelFunction.findOneAndUpdate({ // eslint-disable-line no-var
      params,
      query
    });
  } catch (error) {
    next(error);
  }
  if (result) {
    let data = {};

    if (kycStatus === 'REJECTED') {
      data = {
        userName : result.personalDetails.fullName,
        reason : result.kycDetails.rejectReason
      };
    } else if(kycStatus === 'REPORTED') {
      let report = [];
      const reportIssue = result.kycDetails.reportIssue;
      let otherIssue = '';
      for(const key in reportIssue) {
        if(reportIssue.hasOwnProperty(key) && !!reportIssue[key]  && key !== '$init' && key !== 'other') {
          report.push(key);
        }
      }

      if(reportIssue.other) {
        otherIssue = reportIssue.other;
      }
      report = report.join(',');
      data = {
        userName : result.personalDetails.fullName,
        reportIssue : report,
        otherIssue
      };
    } else {
      data = {
        userName : result.personalDetails.fullName
      };
    }
    if(kycStatus !== 'DOCUMENTS') {
      mailer({
        to: result.email.value,
        mailType: `KYC_REQUEST_${kycStatus}`,
        data
      });
    }
  }

  res.status(200).json({
    success: true,
    message: `KYC ${kycStatus}`
  });
};

controller.blockUser = async (req, res, next) => {
  const blockUserId = req.params.userId;
  const updateData = {
    $set: {
      isBlocked: true,
      blockedAt: Date.now()
    }
  };

  try {
    userModelFunction.findByIdAndUpdate({
      id: blockUserId,
      data: updateData
    });
  } catch (error) {
    next(error);
  }

  res.status(200).json({
    success: true,
    message: 'User blocked'
  });

};

controller.unBlockUser = async (req, res, next) => {
  const blockUserId = req.params.userId;
  const updateData = {
    $set: {
      isBlocked: false,
      blockedAt: null
    }
  };

  try {
    userModelFunction.findByIdAndUpdate({
      id: blockUserId,
      data: updateData
    });
  } catch (error) {
    next(error);
  }

  res.status(200).json({
    success: true,
    message: 'User unBlocked'
  });

};

controller.updateTokens = async (req, res, next) => {
  const creatorId = req.user.id,
    creatorEmail = req.user.local.email,
    userId = req.params.userId,
    tokens = req.params.tokens;

  const data = {
    $inc: {
      'tokens.total': tokens
    }
  };

  let updateResult, recordTrxn;
  try {
    updateResult = await userModelFunction.findByIdAndUpdate({ data, id: userId });
    if (updateResult) {
      recordTrxn = await trxnController.addNewTraxn({ userId, tokens, creatorId, creatorEmail });
    }
  } catch (error) {
    next(error);
  }

  if (updateResult) {
    if (!recordTrxn) {
      logger.error('unable to save Traxn record !! ', userId, tokens, creatorId, creatorEmail);
    }
    res.status(200).json({ success: true, message: 'Token update successfull' });
  } else {
    res.status(200).json({ success: false, message: 'User Not found', description: '' });
  }
};

controller.deleteUser = async (req, res, next) => {
  const userId = req.user.id,
    deleteUserId = req.params.userId;
  let deleteResult;
  try {
    deleteResult = await deleteUser_O({ deleteUserId, loggedInUserId: userId }); // eslint-disable-line
  } catch (error) {
    next(error);
  }

  if (deleteResult.success) {
    res.status(200).json({ success: true, message: 'Users and Trxns deleted' });
  } else {
    res.status(200).json({ success: false, message: 'Unable to delete user'  });
  }
};

const deleteUser_O = ({ deleteUserId: userId, loggedInUserId: deletedBy }) => { // eslint-disable-line

  const P_deleteUser = userModelFunction.deleteSoft({ params: { _id: userId }, deletedBy });
  const P_deleteTrnxns = trxnModelFunction.deleteSoft({ params: { userId }, deletedBy });
  return new Promise((resolve, reject) => {
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return reject({ success: false, message: 'Invalid User Id' });
    }
    Promise.all([P_deleteUser, P_deleteTrnxns])
      .then(result => {
        if (result) {
          return resolve({ success: true });
        } else {
          return resolve({ success: false });
        }
      })
      .catch(err => {
        return reject(err);
      });
  });

};

controller.unDeleteUser = ({ userId, loggedInUserId }) => { // eslint-disable-line

  /* const P_deleteUser = userModelFunction.delete({ id:userId } ,loggedInUserId).exec();
  const P_deleteTrnxns = trxnModelFunction.delete({ userId: userId },loggedInUserId).exec();
  return new Promise((resolve, reject)=>{
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      const { status, message, description } = errorHandler({ errorType: '', message: 'Invalid User Id', description: '' });
      return reject({ success: false, message, description });
    }
    Promise.all([P_deleteUser,P_deleteTrnxns])
      .then(()=>{
        resolve({success:true,message:'Users and Trxns deleted'});
      })
      .catch(err=>{
        reject(err);
      });
  }); */

};

controller.deleteTrxn = async (req, res, next) => {
  const userId = req.user.id,
    deleteTrxnId = req.params.trxnId;
  let deleteResult,trxnDetails,userTokenUpdateResult;
  if (!mongoose.Types.ObjectId.isValid(userId)) {
    return res.status(200).json({ success: false, message: 'Invalid User Id' });
  };
  const params = {
    _id: deleteTrxnId
  };

  try {
    trxnDetails = await trxnModelFunction.findOne({ params: { _id:deleteTrxnId } });
    if (!trxnDetails) {
      return res.status(200).json({ success: false, message: 'Transaction not found.' });
    };
    const id = trxnDetails.userId;
    const data = {
      $inc: {
        'tokens.total': -1 * trxnDetails.tokens,
        [`tokens.${trxnDetails.phase}`]: -1 * trxnDetails.tokens
      }
    };
    userTokenUpdateResult = await userModelFunction.findByIdAndUpdate({ id,data });
    if (!userTokenUpdateResult) {
      logger.error('Failed To deduct tokens of deleted trxn - id, data',id,data);
    }
    deleteResult = await trxnModelFunction.deleteSoft({ params, deletedBy: userId });
  } catch (error) {
    next(error);
  }

  if (deleteResult) {
    return res.status(200).json({ success: true, message: 'Trxn Deleted' });
  } else {
    return res.status(200).json({ success: false, message: 'Something wentt wrong' });
  }
};


controller.sendMail = async (req,res,next) => {
  try {
    const email = req.body.email,
      msg = req.body.message;

    mailer({
      to: email,
      mailType: 'MESSAGE',
      data: {
        to:email,
        msg
      }
    });
  } catch (error) {
    next(error);
  }

  res.status(200).json({ success:true, message: 'Mail sent successfully.' });
};

controller.getExcelUsers = async (req, res, next) => {
  let sortBy = req.query.sortBy, sortOrder;
  // default descending
  sortOrder = req.query.order ? req.query.order : -1;
  if (sortBy === 'fullName') {
    sortBy = 'personalDetails.fullName';
  } else if (sortBy === 'created_at') {
    sortBy = 'created_at';
  } else {
    sortBy = 'created_at';
    sortOrder = -1;
  }

  const params = {
    $or : [
      { role : 'USER' }
      // {role : "ADMIN"}
    ]
  };
  if (req.query.userType) {
    params.userState = req.query.userType;
  }
  if (req.query.kycStatus) {
    params.kycStatus = req.query.kycStatus;
  }
  if (req.query.tokensTotalLL) {
    params['tokens.total'] = { '$gte' : req.query.tokensTotalLL };
  }
  if (req.query.tokensTotalUL) {
    params['tokens.total'] = { '$lte' : req.query.tokensTotalUL };
  }
  if (req.query.email) {
    params['local.email'] = { '$regex' : req.query.email };
  }

  const P_totalCount = await userModelFunction.count({ params });

  const page = req.query.page && req.query.page > 0 ? parseInt(req.query.page) : 1,
    limit = req.query.limit && req.query.limit > 0 ? parseInt(req.query.limit) : P_totalCount;

  const selector = {
    personalDetails: 1,
    userState: 1,
    accountState: 1,
    isBlocked: 1,
    isActive: 1,
    tokens: 1,
    refer: 1,
    email: 1,
    contributionRange: 1,
    created_at: 1,
    updated_at: 1,
    kycStatus: 1
  };

  const sort = {
    [sortBy]: sortOrder
  };

  var P_users = userModelFunction.find({ // eslint-disable-line no-var
    params,
    sort,
    selector,
    skip: (page - 1) * limit,
    limit: limit
  });

  //@TODO: rohan output in this format
  // var output = {
  //   users: null,
  //   pages: {
  //     current: options.page,
  //     prev: 0,
  //     hasPrev: false,
  //     next: 0,
  //     hasNext: false,
  //     total: 0
  //   },
  //   items: {
  //     begin: ((options.page * options.limit) - options.limit) + 1,
  //     end: options.page * options.limit,
  //     total: 0
  //   }
  // };

  Promise.all([P_totalCount, P_users]).then((results) => {
    let user;

    const users = [];
    for (user in results[1]) {
      if(!!user) {
        const obj = {};
        obj.name = results[1][user].personalDetails.fullName;
        obj.email = results[1][user].email.value;
        obj.totalReferralUsed = results[1][user].refer.totalUsed;
        obj.referSuccess = results[1][user].refer.success;
        obj.referee = results[1][user].refer.referee;
        obj.voted = results[1][user].refer.voted;
        obj.referralCode= results[1][user].refer.code;
        obj.totalTokens = results[1][user].tokens.total;
        obj.privateSaleTokens = results[1][user].tokens.privateSale;
        obj.preSaleTokens = results[1][user].tokens.preSale;
        obj.crowdSaleTokens = results[1][user].tokensCrowdsale;
        obj.referralTokens = results[1][user].tokens.referral;
        obj.voteTokens= results[1][user].tokens.vote;
        obj.userState =results[1][user].userState;
        obj.accountState = results[1][user].accountState;
        obj.isBlocked = results[1][user].isBlocked;
        obj.isActive = results[1][user].isActive;
        obj._id = results[1][user]._id;
        obj.created_at = results[1][user].created_at;
        obj.updated_at = results[1][user].updated_at;
        obj.kycStatus = results[1][user].kycStatus;

        users.push(obj);
      }
    }


    res.status(200).json({
      success: true,
      totalUsers: results[0],
      users,
      nextPage: page * limit >= results[0] ? false : true
    });
  }).catch((error) => {
    next(error);
  });

};

// controller.readFile = (req, res) => {
//   try {
//     const rawdata = fs.readFileSync(filePath);
//     const data = JSON.parse(rawdata);
//     console.log(data);
//     console.log('read constants : ', constants.ico);
//     res.json({ msg: 'Success', data: data.Data });
//   } catch (err) {
//     res.json({ msg: 'Unable to read' });
//   }
// };

// controller.readConstantsAddressJson = (req, res) => {
//   try {
//     const rawdata = fs.readFileSync(filePath);
//     const data = JSON.parse(rawdata);
//     console.log('Read Data : ', data);
//     console.log('read constants : ', constants.ico);
//     res.json({ msg: 'Success', data: data });
//   } catch (err) {
//     res.json({ msg: 'Unable to read' });
//   }
// };

// controller.updateConstantsAddressJson = (req, res) => {
//   try {
//     let update = false;
//     const rawdata = fs.readFileSync(filePath);
//     const data = JSON.parse(rawdata);
//
//     console.log('constantsAddressJson : ', data);
//     console.log('constants : ', constants.ico);
//
//     if(!!req.body.btcAddress) {
//       data.Data.btcAddress = req.body.btcAddress;
//       update=true;
//       console.log('btcAddress : ', req.body.btcAddress);
//     }
//     if(!!req.body.ethAddress) {
//       data.Data.ethAddress = req.body.ethAddress;
//       update=true;
//       console.log('ethAddress : ', req.body.ethAddress);
//     }
//     if(update) {
//       fs.writeFile(filePath, JSON.stringify(data), 'utf-8', (err) => {
//         if (err) throw err
//         console.log('Done!')
//         if(!!req.body.btcAddress) {
//           constants.ico.btcAddress = req.body.btcAddress;
//         }
//         if(!!req.body.ethAddress) {
//           constants.ico.ethAddress = req.body.ethAddress;
//         }
//         console.log("constants : ", constants.ico);
//       });
//     }
//     if(!update) {
//       res.json({ msg: 'No Data to update' });
//     }
//     res.json({ msg: 'Success', data: data });
//   } catch (err) {
//     res.json({ msg: 'Unable to read' });
//   }
// };


// controller.updateFile = (req, res) => {
//   try {
//     let update = false;
//     const rawdata = fs.readFileSync(filePath);
//     const data = JSON.parse(rawdata);
//     console.log(data);
//     if(!!req.body.tokenUsd) {
//       data.Data.tokenUsd = req.body.tokenUsd;
//       update=true;
//       console.log('tokenUsd : ', data.Data.tokenUsd);
//     }
//     if(!!req.body.ethUsd) {
//       data.Data.ethUsd = req.body.ethUsd;
//       update=true;
//       console.log('ethUsd : ', req.body.ethUsd);
//     }
//     if(!!req.body.ethAddress) {
//       data.Data.ethAddress = req.body.ethAddress;
//       update=true;
//       console.log('ethAddress : ', req.body.ethAddress);
//     }
//     if(!!req.body.stage) {
//       data.Data.stage = req.body.stage;
//       update=true;
//       console.log('stage : ', req.body.stage);
//     }
//     if(!!req.body.btcUsd) {
//       data.Data.btcUsd = req.body.btcUsd;
//       update=true;
//       console.log('btcUsd : ', req.body.btcUsd);
//     }
//     if(!!req.body.btcAddress) {
//       data.Data.btcAddress = req.body.btcAddress;
//       update=true;
//       console.log('btcAddress : ', req.body.btcAddress);
//     }
//     if(!!req.body.bonus) {
//       data.Data.bonus = req.body.bonus;
//       update=true;
//       console.log('bonus : ', req.body.bonus);
//     }
//     if(!!req.body.minInvest) {
//       data.Data.minInvest = req.body.minInvest;
//       update=true;
//       console.log('minInvest : ', req.body.minInvest);
//     }
//     if(!!req.body.privateSaleTokenUsd) {
//       data.Data.privateSaleTokenUsd = req.body.privateSaleTokenUsd;
//       update=true;
//       console.log('privateSaleTokenUsd : ', req.body.privateSaleTokenUsd);
//     }
//     if(!!req.body.preSaleTokenUsd) {
//       data.Data.preSaleTokenUsd = req.body.preSaleTokenUsd;
//       update=true;
//       console.log('preSaleTokenUsd : ', req.body.preSaleTokenUsd);
//     }
//     if(!!req.body.mainSaleTokenUsd) {
//       data.Data.mainSaleTokenUsd = req.body.mainSaleTokenUsd;
//       update=true;
//       console.log('mainSaleTokenUsd : ', req.body.mainSaleTokenUsd);
//     }
//     if(!!req.body.eurUsd) {
//       data.Data.eurUsd = req.body.eurUsd;
//       update=true;
//       console.log('eurUsd : ', req.body.eurUsd);
//     }

//     if(!!req.body.eurUsd) {
//       data.Data.eurUsd = req.body.eurUsd;
//       update=true;
//       console.log('eurUsd : ', req.body.eurUsd);
//     }

//     if(!!req.body.eurUsd) {
//       data.Data.eurUsd = req.body.eurUsd;
//       update=true;
//       console.log('eurUsd : ', req.body.eurUsd);
//     }

//     if(req.body.status !== undefined) {
//       data.Data.refer.status = req.body.status;
//       update=true;
//       console.log('status : ', req.body.status);
//     }

//     if(!!req.body.amountPercent) {
//       data.Data.refer.amountPercent = req.body.amountPercent;
//       update=true;
//       console.log('amountPercent : ', req.body.amountPercent);
//     }

//     if(update) {
//       fs.writeFile(filePath, JSON.stringify(data), 'utf-8', (err) => {
//         if (err) throw err
//         console.log('Done!')
//         if(!!req.body.btcAddress) {
//           constants.ico.btcAddress = req.body.btcAddress;
//         }
//         if(!!req.body.ethAddress) {
//           constants.ico.ethAddress = req.body.ethAddress;
//         }
//         console.log("constants : ", constants.ico);
//       });
//     }
//     if(!update) {
//       res.json({ msg: 'No Data to update' });
//     }
//     res.json({ msg: 'Success', data: data.Data });
//   } catch (err) {
//     res.json({ msg: 'Unable to read' });
//   }
// };


controller.updateNewFile = async (req,res,next) => {
  try {
    await storage.init({
      dir: newFile,

      stringify: JSON.stringify,

      parse: JSON.parse,

      encoding: 'utf8',

      logging: false,  // can also be custom logging function

      ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

      expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

      // in some cases, you (or some other service) might add non-valid storage files to your
      // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
      forgiveParseErrors: false

    });
    console.log(req.body);

    if(!!req.body.staticBonus && !!req.body.staticDiscount) {
      // If we update both staticBonus and staticDiscount at the same time
      res.json({
        success: false,
        message: 'Cannot update staticBonus and staticDiscount at same time'
      }).status(200);
    }else {
      if(!!req.body.static) {
        await storage.setItem('static',req.body.static);
      }
      else {
        await storage.setItem('static', false);
      }

      // eslint-disable-next-line eqeqeq
      if(!!req.body.staticEthAddress) {
        await storage.setItem('staticEthAddress',req.body.staticEthAddress);
      }
      if(!!req.body.staticUSDTAddress) {
        await storage.setItem('staticUSDTAddress',req.body.staticUSDTAddress);
      }
      if(!!req.body.staticTokenAddress) {
        await storage.setItem('staticTokenAddress',req.body.staticTokenAddress);
      }

      if(!!req.body.staticCrowdsaleAddress) {
        await storage.setItem('staticCrowdsaleAddress',req.body.staticCrowdsaleAddress);
      }
      if(!!req.body.btcAddress) {
        await storage.setItem('btcAddress',req.body.btcAddress);
      }
      if (!!req.body.staticTokenUsd) {
        await storage.setItem('staticTokenUsd',req.body.staticTokenUsd);
      }
      if (!!req.body.staticEthUsd) {
        await storage.setItem('staticEthUsd',req.body.staticEthUsd);
      }
      if (!!req.body.staticStage) {
        await storage.setItem('staticStage',req.body.staticStage);
      }
      if (!!req.body.staticBtcUsd) {
        await storage.setItem('staticBtcUsd',req.body.staticBtcUsd);
      }

      if (req.body.staticMinInvest >= 0) {
        await storage.setItem('staticMinInvest',req.body.staticMinInvest);
      }
      if (req.body.staticBonus >= 0 && !req.body.staticDiscount) {
        // If latest updated value is staticBonus, then
        // isBonusDiscount value will be "staticBonus"
        await storage.setItem('staticBonus',req.body.staticBonus);
        await storage.setItem('isBonusOrDiscount', 'staticBonus');
        // We'll also set the value of staticDiscount to 0
        await storage.setItem('staticDiscount', 0);
      }
      // staticDiscount @aj
      if (req.body.staticDiscount >= 0 && !req.body.staticBonus) {
        // If latest updated value is of staticDiscount, then
        // isBonusDiscount value will be "staticDiscount"
        await storage.setItem('staticDiscount',req.body.staticDiscount);
        await storage.setItem('isBonusOrDiscount', 'staticDiscount');
        // We'll also set the value of staticBonus to 0
        await storage.setItem('staticBonus', 0);
      }

      // --------staticDiscount @aj
      if (!!req.body.staticPrivateSaleTokenUsd) {
        await storage.setItem('staticPrivateSaleTokenUsd',req.body.staticPrivateSaleTokenUsd);
      }
      if (!!req.body.staticPreSaleTokenUsd) {
        await storage.setItem('staticPreSaleTokenUsd',req.body.staticPreSaleTokenUsd);
      }
      if (!!req.body.staticMainSaleTokenUsd) {
        await storage.setItem('staticMainSaleTokenUsd',req.body.staticMainSaleTokenUsd);
      }

      if (!!req.body.staticStatus) {
        await storage.setItem('staticStatus',req.body.staticStatus);
      }
      if (!!req.body.staticAmountPercent) {
        await storage.setItem('staticAmountPercent',req.body.staticAmountPercent);
      }

      // eslint-disable-next-line eqeqeq
      if (!!req.body.ethAddress) {
        await storage.setItem('ethAddress',req.body.ethAddress);
      }
      if (!!req.body.tokenAddress) {
        await storage.setItem('tokenAddress',req.body.tokenAddress);
      }

      if (!!req.body.crowdsaleAddress) {
        await storage.setItem('crowdsaleAddress',req.body.crowdsaleAddress);
      }

      if (!!req.body.tokenUsd) {
        await storage.setItem('tokenUsd',req.body.tokenUsd);
      }
      if (!!req.body.ethUsd) {
        await storage.setItem('ethUsd',req.body.ethUsd);
      }
      if (!!req.body.stage) {
        await storage.setItem('stage',req.body.stage);
      }
      if (!!req.body.btcUsd) {
        await storage.setItem('btcUsd',req.body.btcUsd);
      }

      if (!!req.body.minInvest) {
        await storage.setItem('minInvest',req.body.minInvest);
      }
      if (!!req.body.bonus) {
        await storage.setItem('bonus',req.body.bonus);
      }
      // discount Added
      // if (!!req.body.discount) {
      //   await storage.setItem('discount',req.body.discount);
      // }
      // ------ discount @aj
      if (!!req.body.privateSaleTokenUsd) {
        await storage.setItem('privateSaleTokenUsd',req.body.privateSaleTokenUsd);
      }
      if (!!req.body.preSaleTokenUsd) {
        await storage.setItem('preSaleTokenUsd',req.body.preSaleTokenUsd);
      }
      if (!!req.body.mainSaleTokenUsd) {
        await storage.setItem('mainSaleTokenUsd',req.body.mainSaleTokenUsd);
      }

      if (!!req.body.status) {
        await storage.setItem('status',req.body.status);
      }
      if (!!req.body.amountPercent) {
        await storage.setItem('amountPercent',req.body.amountPercent);
      }


      res.json({
        success: true,
        message: 'Data updated succesfully'
      }).status(200);
    }

  }
  catch (error) {
    res.json({
      success: false,
      message: 'Data updated Failed'
    }).status(200);
  }
};

controller.getNewFile = async (req,res) =>{
  try {
    await storage.init({
      dir: newFile,

      stringify: JSON.stringify,

      parse: JSON.parse,

      encoding: 'utf8',

      logging: false,  // can also be custom logging function

      ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

      expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

      // in some cases, you (or some other service) might add non-valid storage files to your
      // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
      forgiveParseErrors: false

    });
    const data = {};
    data.ethAddress = await storage.getItem('ethAddress');
    data.btcAddress = await storage.getItem('btcAddress');
    data.stage = await storage.getItem('stage');
    data.tokenUsd = await storage.getItem('tokenUsd');
    data.ethUsd = await storage.getItem('ethUsd');
    data.btcUsd = await storage.getItem('btcUsd');
    data.minInvest = await storage.getItem('minInvest');
    data.privateSaleTokenUsd = await storage.getItem('privateSaleTokenUsd');
    data.bonus = await storage.getItem('bonus');
    // @aj
    // data.discount = await storage.getItem('discount');
    data.staticDiscount = await storage.getItem('staticDiscount');
    data.isBonusOrDiscount = await storage.getItem('isBonusOrDiscount');
    // -----------@aj
    data.preSaleTokenUsd = await storage.getItem('preSaleTokenUsd');
    data.mainSaleTokenUsd = await storage.getItem('mainSaleTokenUsd');
    data.status = await storage.getItem('status');
    data.amountPercent = await storage.getItem('amountPercent');
    data.liveBonus = await storage.getItem('liveBonus');
    data.liveStage = await storage.getItem('liveStage');
    data.tokenAddress = await storage.getItem('tokenAddress');
    data.crowdsaleAddress = await storage.getItem('crowdsaleAddress');
    //static data
    data.staticEthAddress = await storage.getItem('staticEthAddress');
    data.staticBtcAddress = await storage.getItem('staticBtcAddress');
    data.staticUSDTAddress = await storage.getItem('staticUSDTAddress');
    data.staticTokenUsd = await storage.getItem('staticTokenUsd');
    data.staticEthUsd = await storage.getItem('staticEthUsd');
    data.staticStage = await storage.getItem('staticStage');
    data.staticBtcUsd = await storage.getItem('staticBtcUsd');
    data.staticMinInvest = await storage.getItem('staticMinInvest');
    data.staticPrivateSaleTokenUsd = await storage.getItem('staticPrivateSaleTokenUsd');
    data.staticBonus = await storage.getItem('staticBonus');
    data.staticPreSaleTokenUsd = await storage.getItem('staticPreSaleTokenUsd');
    data.staticMainSaleTokenUsd = await storage.getItem('staticMainSaleTokenUsd');
    data.staticEurUsd = await storage.getItem('staticEurUsd');
    data.staticStatus = await storage.getItem('staticStatus');
    data.staticAmountPercent = await storage.getItem('staticAmountPercent');
    data.staticLiveBonus = await storage.getItem('staticLiveBonus');
    data.staticLiveStage = await storage.getItem('staticLiveStage');
    data.staticTokenAddress = await storage.getItem('staticTokenAddress');
    data.staticCrowdsaleAddress = await storage.getItem('staticCrowdsaleAddress');
    data.static = await storage.getItem('static');

    res.json({
      success: true,
      data
    }).status(200);

  } catch (error) {
    res.json({
      success: false,
      message: 'Failed to get data'
    }).status(200);
  }
};

controller.blockVerifyUser = async (req, res, next) => {

  let dataF, successF, fieldUpdated;
  dataF = {
    _id: req.params._id
  };

  try{
    const resultUserFind = await userModelFunction.findById({ id: dataF });
    if(!!resultUserFind) {
      successF = true;
      // console.log('successF : ', successF);
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'No such _id exists'
        });
    }
  }catch(err) {
    successF = false;
    next(err);
  }

  if(!!successF) {
    if(!( req.body.blocked === true || req.body.blocked === false ) && !( req.body.verify === true || req.body.verify === false )) {
      //console.log('Send some data');
      return res
        .status(400)
        .json({
          success: false,
          message: 'BAD REQUEST'
        });
    }else {
      let dataU;
      //console.log('dataF : ', dataF);
      if(req.body.blocked === true || req.body.blocked === false) {
        let date, dateISO;
        date = new Date();

        if(!!req.body.blocked) {
          dateISO = date.toISOString();
        }else {
          dateISO = null;
        }
        fieldUpdated = 'isBlocked';
        dataU = {
          $set: {
            isBlocked: req.body.blocked,
            blockedAt: dateISO
          }
        };
      }

      if(req.body.verify === true || req.body.verify === false) {
        fieldUpdated = 'isVerified';
        dataU = {
          $set: {
            'accountVerify.isVerified': req.body.verify
          }
        };
      }

      console.log('dataU : ', dataU);
      try {
        const resultUserUpdate = await userModelFunction.findByIdAndUpdate({
          id: dataF,
          data: dataU
        });

        if(!!resultUserUpdate) {
          return res
            .status(200)
            .json({
              success: true,
              fieldUpdated,
              message: 'Successfully updated'
            });
        }
      }catch(err) {
        next(err);
      }
    }

  }

}

controller.tokenTransfer = async (req, res, next) => {
  const transferData = req.body;
  return res
    .status(200)
    .json({
      success: true,
      message: 'Data successfully retrieved',
      data: transferData
    });
};

// controller.mnemonicCall = async (req, res, next) => {
//   try {
//     // mnemonic phrase
//
//   } catch(err) {
//     next(err);
//   }
// };

module.exports = controller;
