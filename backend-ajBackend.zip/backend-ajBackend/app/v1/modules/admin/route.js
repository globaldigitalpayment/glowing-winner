const multer = require('multer'),
  { celebrate } = require('celebrate'),
  controller = require('./controller'),
  {
    removeQueryFalsy
  } = require('utils/helper'),
  fs = require('fs'); // eslint-disable-line no-unused-vars

const authenticate = require('./../../config/authenticate');

const validateSchema = require('./schema');

const formDecode = multer().none();

const checkIfAdmin = (req, res, next) => {
  if (req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({ success: false, message: 'Invalid Access', description: '' });
  }
};

const checkIfAdminOrSuperAdmin = (req, res, next) => {
//   console.log(req.user);
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};

const checkPermissions = (permission) => {
  return function(req, res, next) {
    if(req.user.permissions[permission] || req.user.role === 'SUPER_ADMIN') {
      next();
    }else{
      res.status(200).json({
        success: false,
        message: 'You are not allowed to perform this operation'
      });
    }
  };
};


module.exports = function (router) {

  // create Contracts
  /**
	 * @swagger
	 *   /admin/createContract:
	 *   post:
	 *     description: save a contract in database
	 *     tags:
	 *       - Contract
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: x-auth-token
	 *         in: header
	 *         type: string
	 *         required: true
	 *         description: Token obtained on login
	 *       - name: name
	 *         description: name of contract
	 *         in: body
	 *         type: string
	 *       - name: address
	 *         description: ethereum address of contract
	 *         in: body
	 *         type: string
	 *       - name: network
	 *         description: type of ethereum network (mainnet , ropsten, rinkeby)
	 *         in: body
	 *         type: string
	 *       - name: tokenType
	 *         description: token type (token or crowdsale)
	 *         in: body
	 *         type: string
	 *       - name: abi
	 *         description: contract ABI
	 *         in: body
	 *         type: string
	 *       - name: useInDashboard
	 *         description: to use this contract in live dashboard ?
	 *         in: body
	 *         type: boolean
	 *
	 *     responses:
	 *       200:
	 *        	description: Successfully created contract'
	 */
  router
    .post(
      '/admin/createContract',
      authenticate,
      checkIfAdminOrSuperAdmin,
	    checkPermissions('manageSmartContract'),
      celebrate(validateSchema.contractData),
      controller.createContract
    );

  /**
	 * @swagger
	 *   /admin/findContract/:_id :
	 *   get:
	 *     description: find a contract using _id
	 *     tags:
	 *       - Contract
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: x-auth-token
	 *         in: header
	 *         type: string
	 *         required: true
	 *         description: Token obtained on login
	 *       - name: _id
	 *         description: _id of contract
	 *         in: params
	 *         required: true
	 *
	 *     responses:
	 *       200:
	 *        	description: Successfully found the contract'
	 */
  router
    .get(
      '/admin/findContract/:_id',
      authenticate,
      checkIfAdminOrSuperAdmin,
	    checkPermissions('manageSmartContract'),
      controller.findContract
    );

  /**
     * @swagger
     *   /admin/updateContract/:_id :
     *   put:
     *     description: update a contract in database
     *     tags:
     *       - Contract
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: x-auth-token
     *         in: header
     *         type: string
     *         required: true
     *         description: Token obtained on login
     *       - name: name
     *         description: name of contract
     *         in: body
     *         type: string
     *       - name: address
     *         description: ethereum address of contract
     *         in: body
     *         type: string
     *       - name: network
     *         description: type of ethereum network (mainnet , ropsten, rinkbey)
     *         in: body
     *         type: string
     *       - name: tokenType
     *         description: token type (token or crowdsale)
     *         in: body
     *         type: string
     *       - name: abi
     *         description: contract ABI
     *         in: body
     *         type: string
     *       - name: useInDashboard
     *         description: to use this contract in live dashboard ?
     *         in: body
     *         type: boolean
     *       - name: _id
     *         description: _id of token to updated
     *         in: params
     *         required: true
     *
     *     responses:
     *       200:
     *        	description: Successfully updated contract'
     */
  router
    .put(
      '/admin/updateContract/:_id',
      celebrate(validateSchema.updateContractData),
      authenticate,
      checkIfAdminOrSuperAdmin,
	    checkPermissions('manageSmartContract'),
      controller.updateContract
    );

  /**
     * @swagger
     *   /admin/deleteContract/:_id:
     *   delete:
     *     description: deletes a contract from database
     *     tags:
     *       - Contract
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: x-auth-token
     *         in: header
     *         type: string
     *         required: true
     *         description: Token obtained on login
     *       - name: _id
     *         description: _id of the contract to be deleted
     *         in: params
     *         required: true
     *
     *     responses:
     *       200:
     *        	description: Successfully deleted a contract'
     */
  router
    .delete(
      '/admin/deleteContract/:_id',
      authenticate,
      checkIfAdminOrSuperAdmin,
	    checkPermissions('manageSmartContract'),
      controller.deleteContract
    );


  /**
     * @swagger
     *   /admin/getallContract:
     *   get:
     *     description: gets all contracts in database
     *     tags:
     *       - Contract
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: x-auth-token
     *         in: header
     *         type: string
     *         required: true
     *         description: Token obtained on login
     *
     *     responses:
     *       200:
     *        	description: Successfully get all contracts'
     */
  router
    .get(
      '/admin/getAllContract',
	    authenticate,
      checkIfAdminOrSuperAdmin,
      checkPermissions('manageSmartContract'),
      controller.getAllContract
    );

  /**
   * @swagger
   *   /admin/getFile:
   *   get:
   *     description: read the contents from a json file
   *     tags:
   *       - Config_Static_File
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: x-auth-token
   *         in: header
   *         type: string
   *         required: true
   *         description: Token obtained on login
   *
   *     responses:
   *       200:
   *        	description: Successfully read the contents from a json file'
   */
  router.get('/admin/getFile', authenticate, checkIfAdminOrSuperAdmin, controller.getNewFile);

  /**
   * @swagger
   *   /admin/updateNewFile:
   *   put:
   *     description: update the contents of a json file
   *     tags:
   *       - Admin
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: x-auth-token
   *         in: header
   *         type: string
   *         required: true
   *         description: Token obtained on login
   *       - name: tokenUsd
   *         in: body
   *         type: number
   *         description: static token price in usd , when crowd sale smart contracts are not live
   *       - name: ethUsd
   *         in: body
   *         type: number
   *         description: static ether price in usd
   *       - name: btcUsd
   *         in: body
   *         type: number
   *         description: static bitcoin price in usd
   *       - name: stage
   *         in: body
   *         type: string
   *         description: static current stage of ico
   *       - name: ethAddress
   *         in: body
   *         type: string
   *         description: static ether address to accept eth , when crowdsale address is not in use
   *       - name: btcAddress
   *         in: body
   *         type: string
   *         description: bitcoin address to accept payment in btc
   *       - name: bonus
   *         in: body
   *         type: number
   *         description: static bonus to give , when crowdsale is not live
   *       - name: discount
   *         in: body
   *         type: number
   *         description: static discount to give , when crowdsale is not live
   *       - name: minInvest
   *         in: body
   *         type: number
   *         description: static minInvest without crowdsale smart contract live
   *       - name: privateSaleTokenUsd
   *         in: body
   *         type: number
   *         description: static privateSaleTokenUsd without crowdsale smart contract live
   *       - name: preSaleTokenUsd
   *         in: body
   *         type: number
   *         description: static preSaleTokenUsd without crowdsale smart contract live
   *       - name: mainSaleTokenUsd
   *         in: body
   *         type: number
   *         description: mainSaleTokenUsd without crowdsale smart contract live
   *       - name: status
   *         in: body
   *         type: boolean
   *         description: refer program status
   *       - name: amountPercent
   *         in: body
   *         type: number
   *         description: refer program tokens bonus
   *       - name: liveBonus
   *         in: body
   *         type: number
   *         description: live bonus/discount price from smart contract
   *       - name: liveStage
   *         in: body
   *         type: number
   *         description: live stage from smart contract
   *       - name: tokenAddress
   *         in: body
   *         type: string
   *         description: smart contract token address
   *       - name: crowdsaleAddress
   *         in: body
   *         type: string
   *         description: smart contract crowd sale address
   *       - name: staticTokenUsd
   *         in: body
   *         type: number
   *         description: static token price in usd , when crowd sale smart contracts are not live
   *       - name: staticEthUsd
   *         in: body
   *         type: number
   *         description: static ether price in usd
   *       - name: staticBtcUsd
   *         in: body
   *         type: number
   *         description: static bitcoin price in usd
   *       - name: staticStage
   *         in: body
   *         type: string
   *         description: static current stage of ico
   *       - name: staticEthAddress
   *         in: body
   *         type: string
   *         description: static ether address to accept eth , when crowdsale address is not in use
   *       - name: staticBtcAddress
   *         in: body
   *         type: string
   *         description: bitcoin address to accept payment in btc
   *       - name: staticBonus
   *         in: body
   *         type: number
   *         description: static bonus to give , when crowdsale is not live
   *       - name: staticDiscount
   *         in: body
   *         type: number
   *         description: static discount to give , when crowdsale is not live
   *       - name: staticMinInvest
   *         in: body
   *         type: number
   *         description: static minInvest without crowdsale smart contract live
   *       - name: staticPrivateSaleTokenUsd
   *         in: body
   *         type: number
   *         description: static privateSaleTokenUsd without crowdsale smart contract live
   *       - name: staticPreSaleTokenUsd
   *         in: body
   *         type: number
   *         description: static preSaleTokenUsd without crowdsale smart contract live
   *       - name: staticMainSaleTokenUsd
   *         in: body
   *         type: number
   *         description: mainSaleTokenUsd without crowdsale smart contract live
   *       - name: staticStatus
   *         in: body
   *         type: boolean
   *         description: refer program status
   *       - name: staticAmountPercent
   *         in: body
   *         type: number
   *         description: refer program tokens bonus
   *       - name: staticLiveBonus
   *         in: body
   *         type: number
   *         description: live bonus/discount price from smart contract
   *       - name: staticLiveStage
   *         in: body
   *         type: number
   *         description: live stage from smart contract
   *       - name: staticTokenAddress
   *         in: body
   *         type: string
   *         description: smart contract token address
   *       - name: staticCrowdsaleAddress
   *         in: body
   *         type: string
   *         description: smart contract crowd sale address
   *       - name: static
   *         in: body
   *         type: boolean
   *         description: to set the static sale data
   *
   *     responses:
   *       200:
   *        	description: Successfully updated the contents of a json file'
   */


   // staticDiscount added : static
  router.put('/admin/updateNewFile', celebrate(validateSchema.keyValueFile), authenticate, checkIfAdminOrSuperAdmin, checkPermissions('updateReferalProgram'), controller.updateNewFile);


  /**
	   * @swagger
	   * /admin/dashboard:
	   *  get:
	   *   description: Get amdin dashboard
	   *   tags:
	   *    - Admin
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: Token obtained on login
	   *   responses:
	   *    200:
	   *     description:
	   */
  router.get('/admin/dashboard', authenticate, checkIfAdminOrSuperAdmin, controller.dashboard);

  /**
	   * @swagger
	   * /admin/users:
	   *  get:
	   *   description: Get users list
	   *   tags:
	   *    - Admin
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: userState
	   *      in: query
	   *      schema:
	   *       type: string
	   *      required: false
	   *      description: enum USER,SUBSCRIBER
	   *    - name: kycStatus
	   *      in: query
	   *      schema:
	   *       type: string
	   *      required: false
	   *      description: enum ACCEPTED,REJECTED,SUBMITTED,PENDING,REPORTED
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: Token obtained on login
	   *    - name: page
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: page number
       *    - name: limit
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: number of records req on each page
	   *    - name: sortBy
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: fullName or created_at
	   *    - name: order
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: from 1 or -1 asc or desc
	   *    - name: name
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: phone
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: isAccVerified
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: from true or false
       *    - name: tokensTotalLL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensTotalUL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensPrivateSaleLL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensPrivateSaleUL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensPreSaleLL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensPreSaleUL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensCrowdSaleLL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensCrowdSaleUL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensReferralLL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensReferralUL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensVoteLL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: tokensVoteUL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: referTotalLL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: referTotalUL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: referSuccessLL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
       *    - name: referSuccessUL
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
     *    - name: referCode
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
     *    - name: refereeId
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
     *    - name: isVoted
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
     *    - name: email
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: string . .
     *    - name: is2FAEnabled
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: true or false
     *    - name: minCreatedAt
     *      in: query
     *      schema:
     *        type: string
     *      required: false
     *      description: date
     *    - name: maxCreatedAt
     *      in: query
     *      schema:
     *        type: string
     *      required: false
     *      description: date
	   *   responses:
	   *    200:
	   *     description:
	   */
  router.get('/admin/users', removeQueryFalsy, celebrate(validateSchema.listUsers), authenticate, checkIfAdminOrSuperAdmin, controller.getAllUsers);

  /**
     * @swagger
     * /admin/subAdmins:
     *  get:
     *   description: List of subadmins
     *   tags:
     *    - Admin
     *   produces:
     *    - application/json
     *   parameters:
     *    - name: x-auth-token
     *      in: header
     *      schema:
     *       type: string
     *      required: true
     *      description: Token obtained on login
     *    - name: minCreatedAt
     *      in: query
     *      schema:
     *       type: string
     *      required: false
     *      description: minCreatedAt
     *    - name: maxCreatedAt
     *      in: query
     *      schema:
     *       type: string
     *      required: false
     *      description: maxCreatedAt
     *    - name: email
     *      in: query
     *      schema:
     *       type: string
     *      required: false
     *      description: email
     *    - name: createdBy
     *      in: query
     *      schema:
     *       type: string
     *      required: false
     *      description: createdBy
     *    - name: page
     *      in: query
     *      schema:
     *       type: string
     *      required: false
     *      description: page
     *    - name: sortBy
     *      in: query
     *      schema:
     *       type: string
     *      required: false
     *      description: sortBy valid are email, createdBy, createdAt
     *    - name: limit
     *      in: query
     *      schema:
     *       type: number
     *      required: false
     *      description: limit
     *    - name: order
     *      in: query
     *      schema:
     *       type: number
     *      required: false
     *      description: oreder 1 or -1
     *   responses:
     *    200:
     *     description:
     */
  router.get(
    '/admin/subAdmins',
    removeQueryFalsy,
    celebrate(validateSchema.listSubAdmins),
    authenticate,
    checkIfAdminOrSuperAdmin,
    controller.getAllSubAdmins
   );

  /**
	   * @swagger
	   * /admin/user/{userId}:
	   *  get:
	   *   description: Get single users details
	   *   tags:
	   *    - Admin
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: userId
	   *      in: path
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: user Id
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: Token obtained on login
	   *   responses:
	   *    200:
	   *     description:
	   */
  router.get('/admin/user/:userId', removeQueryFalsy, authenticate, checkIfAdminOrSuperAdmin, controller.getUserDetails);


  /**
	   * @swagger
	   * /admin/update-kyc-status:
	   *  put:
	   *   description: Update kyc verification request
	   *   tags:
	   *    - Admin
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: userId
	   *      in: body
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: Id of user to be updated
	   *    - name: kycStatus
	   *      in: body
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: enum ACCEPTED,REJECTED
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: Token obtained on login
	   *   responses:
	   *    200:
	   *     description:
	   */
  router.put('/admin/update-kyc-status',
    removeQueryFalsy,
    celebrate(validateSchema.updateKycStatus),
    authenticate,
    checkIfAdminOrSuperAdmin,
    checkPermissions('verifyKyc'),
    controller.updateKycStatus);


  /**
	   * @swagger
	   * /user/block/{userId}:
	   *  put:
	   *   description: Block a user
	   *   tags:
	   *    - Admin
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: userId
	   *      in: path
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: Id of user to be blocked
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: Token obtained on login by admin
	   *   responses:
	   *    200:
	   *     description: success message
	   */
  router.put('/user/block/:userId', authenticate, checkIfAdmin,  controller.blockUser);


  /**
	   * @swagger
	   * /user/unblock/{userId}:
	   *  put:
	   *   description: Block a user
	   *   tags:
	   *    - Admin
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: userId
	   *      in: path
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: Id of user to be unblocked
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: Token obtained on login by admin
	   *   responses:
	   *    200:
	   *     description: success message
	   */
  router.put('/user/unblock/:userId', authenticate, checkIfAdmin, controller.unBlockUser);


  /**
	  * @swagger
	  * /tokens/{userId}/{tokens}:
	  *  put:
	  *   description: Add tokens to a user
	  *   tags:
	  *    - Admin
	  *   produces:
	  *    - application/json
	  *   parameters:
	  *    - name: userId
	  *      in: path
	  *      schema:
	  *       type: string
	  *      required: true
	  *      description: Id of user in to be operated on
	  *    - name: tokens
	  *      in: path
	  *      schema:
	  *       type: string
	  *      required: true
	  *      description: Number of tokens to be added
	  *    - name: x-auth-token
	  *      in: header
	  *      schema:
	  *       type: string
	  *      required: true
	  *      description: Token obtained on login by admin
	  *   responses:
	  *    200:
	  *     description: success message
	  */
  router.put('/tokens/:userId/:tokens',
	  celebrate(validateSchema.updateTokens),
    authenticate,
    checkIfAdminOrSuperAdmin,
    controller.updateTokens
  );


  /**
  * @swagger
  * /user/:userId:
  *  delete:
  *   description: Delete user and all his trxns
  *   tags:
  *    - Admin
  *   produces:
  *    - application/json
  *   parameters:
  *    - name: userId
  *      in: path
  *      schema:
  *       type: string
  *      required: true
  *      description: Id of user to be deleted
  *    - name: x-auth-token
  *      in: header
  *      schema:
  *       type: string
  *      required: true
  *      description: Token obtained on login by admin
  *   responses:
  *    200:
  *     description: success message
  */

  router.delete('/user/:userId',
    authenticate,
    checkIfAdminOrSuperAdmin,
    checkPermissions('deleteUser')
    ,controller.deleteUser);


  /**
  * @swagger
  * /transaction/:trxnId:
  *  delete:
  *   description: Delete single trxns
  *   tags:
  *    - Admin
  *   produces:
  *    - application/json
  *   parameters:
  *    - name: trxnId
  *      in: path
  *      schema:
  *       type: string
  *      required: true
  *      description: Id of trxn to be deleted
  *    - name: x-auth-token
  *      in: header
  *      schema:
  *       type: string
  *      required: true
  *      description: Token obtained on login by admin
  *   responses:
  *    200:
  *     description: success message
  */

  router.delete('/transaction/:trxnId', authenticate, checkIfAdminOrSuperAdmin, checkPermissions('deleteTransaction'),
    controller.deleteTrxn);


  /**
	   * @swagger
	   * /admin/excel/users:
	   *  get:
	   *   description: Export users in excel
	   *   tags:
	   *    - Admin
	   *   produces:
	   *    - application/json
	   *   parameters:
	   *    - name: userState
	   *      in: query
	   *      schema:
	   *       type: string
	   *      required: false
	   *      description: enum USER,SUBSCRIBER,ADMIN
	   *    - name: kycStatus
	   *      in: query
	   *      schema:
	   *       type: string
	   *      required: false
	   *      description: enum ACCEPTED,REJECTED,SUBMITTED,PENDING,REPORTED
	   *    - name: x-auth-token
	   *      in: header
	   *      schema:
	   *       type: string
	   *      required: true
	   *      description: Token obtained on login
	   *    - name: sortBy
	   *      in: query
	   *      schema:
	   *        type: string
	   *      required: false
	   *      description: fullName or created_at or referralTokens or totalTokens
       *    - name: tokensTotalLL
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: number . .
       *    - name: tokensTotalUL
	   *      in: query
	   *      schema:
	   *        type: number
	   *      required: false
	   *      description: number . .
	   *   responses:
	   *    200:
	   *     description:
	   */

  router.get('/admin/excel/users',
    removeQueryFalsy,
    celebrate(validateSchema.listUsers),
	 authenticate,
	 checkIfAdminOrSuperAdmin,
    checkPermissions('exportUsersExcel'),
		  controller.getExcelUsers);

  /**
	  * @swagger
	  * /admin/mail:
	  *  post:
	  *   description: Send mail to user
	  *   tags:
	  *    - Admin
	  *   produces:
	  *    - application/json
	  *   parameters:
	  *    - name: x-auth-token
	  *      in: header
	  *      schema:
	  *       type: string
	  *      required: true
	  *      description: Token obtained on login by admin
	  *    - name: email
	  *      in: body
	  *      schema:
	  *       type: string
	  *      required: true
	  *      description: email
	  *    - name: message
	  *      in: body
	  *      schema:
	  *       type: string
	  *      required: true
	  *      description: Mail content
	  *   responses:
	  *    200:
	  *     description: success message and vote counnt
	  */

  router.post('/admin/mail',
    removeQueryFalsy,
    celebrate(validateSchema.sendMail),
	 authenticate,
    checkIfAdminOrSuperAdmin,
		 checkPermissions('sendMail'),
    controller.sendMail);
  //router.get('/admin/findLiveContract/:tokenType' ,  controller.findLiveContract);


  router.get('/admin/liveprice/crypto',
    removeQueryFalsy,
    authenticate,
    checkIfAdminOrSuperAdmin,
    controller.getCryptoPrices);

/**
      * @swagger
      * /admin/blockVerify/:_id:
      *  put:
      *   description: Block, UnBlock, Verify, UnVerify a user
      *   tags:
      *    - Admin
      *   produces:
      *    - application/json
      *   parameters:
      *    - name: x-auth-token
      *      in: header
      *      schema:
      *       type: string
      *      required: true
      *      description: Token obtained on login by admin
      *    - name: _id
      *      in: params
      *      schema:
      *       type: string
      *      required: true
      *      description: user _id
      *   responses:
      *    200:
      *     description: success message
      */

  router.
    put(
      '/admin/blockVerify/:_id',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.blockVerify),
      controller.blockVerifyUser
    );

  // user filters on type (eth,btc , usd ) and registration date (form and to)
  // type => "requested" or "purchased"
  // router
  //   .get(
  //     'admin/userFilter/:userId/:type',
  //     authenticate,
  //     checkIfAdminOrSuperAdmin,
  //     controller.userFilterType
  //   );

  // router
  //   .post(
  //     '/admin/tokenTransfer',
  //     authenticate,
  //     checkIfAdminOrSuperAdmin,
  //     celebrate(validateSchema.tokenTransfer),
  //     controller.tokenTransfer
  //   );

  // router
  //   .post(
  //     '/admin/mnemonics',
  //     authenticate,
  //     checkIfAdminOrSuperAdmin,
  //     celebrate(validateSchema.mnemonicCall),
  //     controller.mnemonicCall
  //   );
};
