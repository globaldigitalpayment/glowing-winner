const { Joi } = require('celebrate');

module.exports = {
  createAnnouncements: {
    body: Joi.object().keys({
      title: Joi.string().required(),
      subject: Joi.string().required()
    })
  },
  editAnnouncements: {
    body: Joi.object().keys({
      title: Joi.string().required(),
      subject: Joi.string().required()
    }),
    params: Joi.object().keys({
      _id: Joi.string().required()
    })
  },
  deleteAnnouncement: {
    params: Joi.object().keys({
      _id: Joi.string().required()
    })
  }
};
