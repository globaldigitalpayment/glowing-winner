const { celebrate } = require('celebrate'),
  controller = require('./controller'),
  { removeQueryFalsy } = require('utils/helper');

const authenticate = require('./../../config/authenticate');
const validateSchema = require('./schema');

const checkIfAdmin = (req, res, next) => {
  if (req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({ success: false, message: 'Invalid Access', description: '' });
  }
};

const checkIfAdminOrSuperAdmin = (req, res, next) => {
//   console.log(req.user);
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};


module.exports = function (router) {
    /**
       * @swagger
       *   /user/announcements :
       *   get:
       *     description: get all announcements
       *     tags:
       *       - News
       *     produces:
       *       - application/json
       *
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .get(
      '/user/announcements',
      controller.getAllAnnouncements
    );

    /**
       * @swagger
       *   /admin/announcement/:_id :
       *   get:
       *     description: delete a news
       *     tags:
       *       - Announcements
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: x-auth-token
       *         in: header
       *         schema:
       *         type: string
       *         required: true
       *       - name: _id
       *         description: _id.
       *         in: params
       *         type: string
       *         required: true
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .delete(
      '/admin/announcement/:_id',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.deleteAnnouncement),
      controller.deleteAnnouncement
    );

    /**
       * @swagger
       *   /admin/announcement :
       *   post:
       *     description: CREATE an Announcement
       *     tags:
       *       - Announcements
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: x-auth-token
       *         in: header
       *         schema:
       *         type: string
       *         required: true
       *       - name: title
       *         description: title
       *         in: body
       *         type: string
       *         required: true
       *       - name: subject
       *         description: subject
       *         in: body
       *         type: string
       *         required: true
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .post(
      '/admin/announcement',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.createAnnouncements),
      controller.createAnnouncements
    );

    /**
       * @swagger
       *   /admin/announcement/:_id :
       *   put:
       *     description: edit an Announcement
       *     tags:
       *       - Announcements
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: x-auth-token
       *         in: header
       *         schema:
       *         type: string
       *         required: true
       *       - name: title
       *         description: title
       *         in: body
       *         type: string
       *         required: true
       *       - name: subject
       *         description: subject.
       *         in: body
       *         type: string
       *         required: true
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .put(
      '/admin/announcement/:_id',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.editAnnouncements),
      controller.editAnnouncements
    );
};
