const faqModel = require('../Announcements/model');
const modelFunction = require('./doa');
const controller = Object.create(null);

controller.createAnnouncements = async (req, res, next) => {
  const params = {
    title: req.body.title,
    subject: req.body.subject
  };
  let createData;
  try {
    createData = await modelFunction.create({ obj: params })
  }catch(err) {
    next(err);
  }

  return res
    .status(200)
    .json({
      success: true,
      data: createData,
      message: 'Announcement Successfully Submitted'
    });
};

controller.editAnnouncements = async(req, res, next) => {
  const id = {
    _id: req.params._id
  };
  const data = {
    title: req.body.title,
    subject: req.body.subject
  };
  const options = {
    new: true
  };

  let findAndUpdate;
  try {
    findAndUpdate = await modelFunction.findByIdAndUpdate({
      id,
      data,
      options
    });
  }catch(err) {
    next(err);
  }

  if(!!findAndUpdate) {
    return res
      .status(200)
      .json({
        success: true,
        data: findAndUpdate,
        message: 'Successfully edited'
      });
  }else {
    return res
      .status(200)
      .json({
        success: false,
        message: 'No such Announcement exists'
      });
  }

};

controller.deleteAnnouncement = async (req, res, next) => {
  const userId = req.params._id;

  let result;
  try{
    // its just parameter name its deleting news
    result = await modelFunction.deleteUser(userId)
  }catch(err) {
    next(err);
  }
  if(result) {
    return res
      .status(200)
      .json({
        success: true,
        message: 'Successfully deleted'
      });
  }else {
    return res
      .status(200)
      .json({
        success: false,
        message: 'Invalid Id'
      });
  }

};

controller.getAllAnnouncements = async (req, res, next) => {
  const params = {};
  let result;
  try{
    result = await modelFunction.find({ params: params })
  }catch(err) {
    next(err);
  }
  if(result.length > 0) {
    return res
      .status(200)
      .json({
        success: true,
        result: result,
        message: 'Successfully got all announcements'
      });
  }else {
    return res
      .status(200)
      .json({
        success: true,
        result: [],
        message: 'No Announcements'
      });
  }
};

module.exports = controller;
