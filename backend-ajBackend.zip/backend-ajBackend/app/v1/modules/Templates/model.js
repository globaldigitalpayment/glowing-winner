const mongoose = require('mongoose');

const templateSchema = new mongoose.Schema({
  'name': {
    type: String,
    required: true
  },
  'templateData' : {
    type : String,
    required: true
  },
  'userList': {
    type: [String],
    required: true
  }
});

const Template = mongoose.model('Template', templateSchema);
module.exports = Template;
