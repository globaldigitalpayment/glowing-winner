const { Joi } = require('celebrate');

module.exports = {
  createTemplate: {
    body: Joi.object().keys({
      name: Joi.string().required(),
      templateData: Joi.string().required()
    })
  },
  addUserList: {
    body: Joi.object().keys({
      templateName: Joi.string().required(),
      userList: Joi.array().items(Joi.string()).required()
    })
  },
  sendMail: {
    params: Joi.object().keys({
      templateName: Joi.string().required()
    })
  }
};
