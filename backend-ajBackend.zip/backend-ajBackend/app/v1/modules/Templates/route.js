const { celebrate } = require('celebrate');
const controller = require('./controller');

const authenticate = require('./../../config/authenticate');
const validateSchema = require('./schema');

const checkIfAdminOrSuperAdmin = (req, res, next) => {
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};

module.exports = function (router) {
  /**
	* @swagger
	* /user/createTemplate:
	*  post:
	*   description: create a mail template
	*   tags:
	*    - Template
	*   produces:
	*    - application/json
	*   parameters:
	*    - name: x-auth-token
	*      in: header
	*      schema:
	*       type: string
	*      required: true
	*      description: Token obtained on login by admin
	*    - name: name
	*      in: body
	*      schema:
	*       type: string
	*      required: true
  *      description: template name
  *    - name: templateData
  *      in: body
  *      schema:
  *       type: string
  *      required: true
	*      description: data that we need to insert in template
	*   responses:
	*    200:
	*     description: Success message
	*/
  router
    .post(
      '/admin/createTemplate',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.createTemplate),
      controller.createTemplate
    );

  /**
	* @swagger
	* /admin/addUserList:
	*  post:
	*   description: adding userList to a template
	*   tags:
	*    - Template
	*   produces:
	*    - application/json
	*   parameters:
	*    - name: x-auth-token
	*      in: header
	*      schema:
	*       type: string
	*      required: true
	*      description: Token obtained on login by admin
	*    - name: templateName
	*      in: body
	*      schema:
	*       type: string
	*      required: true
  *      description: template name
  *    - name: userList
  *      in: body
  *      schema:
  *       type: string
  *      required: true
	*      description: userList
	*   responses:
	*    200:
	*     description: Success message
	*/
  router
    .put(
      '/admin/addUserList',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.addUserList),
      controller.addUserList
    );

    /**
  	* @swagger
  	* /admin/sendMail/:templateName:
  	*  post:
  	*   description: sending a mail template to users
  	*   tags:
  	*    - Template
  	*   produces:
  	*    - application/json
  	*   parameters:
  	*    - name: x-auth-token
  	*      in: header
  	*      schema:
  	*       type: string
  	*      required: true
  	*      description: Token obtained on login by admin
  	*    - name: templateName
  	*      in: params
  	*      schema:
  	*       type: string
  	*      required: true
    *      description: template name
  	*   responses:
  	*    200:
  	*     description: Success message
  	*/
  router
    .post(
      '/admin/sendMail/:templateName',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.sendMail),
      controller.sendMail
    );

};
