const templateModelFunction = require('./doa'),
  mailer = require('config/nodemailer');

const controller = Object.create(null);

controller.createTemplate = async (req, res, next) => {
  try {
    const paramF = {
      name: req.body.name
    };
    const resultFind = await templateModelFunction.findOne({ params: paramF });
    if(!!resultFind) {
      // A template with this name already exists
      return res
        .status(200)
        .json({
          success: false,
          message: 'A template with this name already exists'
        });
    }else {
      // Creating a new template
      const dataF = {
        name: req.body.name,
        templateData: req.body.templateData
      };
      const dataC = await templateModelFunction.create({ obj: dataF });

      return res
        .status(200)
        .json({
          success: true,
          message: `A template with name ${req.body.name} is successfully created`
        });
    }
  }catch(err) {
    next(err);
  }
};

controller.addUserList = async (req, res, next) => {
  try {
    const paramsF = {
      name: req.body.templateName
    };
    const resultF = await templateModelFunction.findOne({ params: paramsF });
    if(!!resultF) {
      // Template exists now adding users to userList
      const paramU = {
        $addToSet: { userList: req.body.userList }
      };
      const updateTemplate = await templateModelFunction.findOneAndUpdate({
        query: paramsF,
        params: paramU
      });
      if(!!updateTemplate) {
        //console.log('updateTemplate : ', updateTemplate);
        return res
          .status(200)
          .json({
            success: true,
            message: `users added to existing userList of ${req.body.templateName} template`
          });
      }
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: `${req.body.templateName} template does not exist`
        });
    }
  }catch(err) {
    next(err);
  }
};

controller.sendMail = async (req, res, next) => {
  try{
    const paramsF = {
      name: req.params.templateName
    };
    const resultF = await templateModelFunction.findOne({ params: paramsF });
    if(!!resultF) {
      // template available now checking userList
      if(resultF.userList.length > 0) {
        // Sending mails to users in userList
        mailer({ mailType: 'CUSTOM_TEMPLATE', to: resultF.userList, data: { templateData: resultF.templateData } });
        return res
          .status(200)
          .json({
            success: true,
            message: 'Successfully sent mail to userList'
          });
      }else {
        return res
          .status(200)
          .json({
            success: false,
            message: `${req.params.templateName} template does not have any user associated with it`
          });
      }
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: `${req.params.templateName} template does not exist`
        });
    }
  }catch(err) {
    next(err);
  }
};

module.exports = controller;
