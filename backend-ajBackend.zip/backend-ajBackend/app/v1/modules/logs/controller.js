const doa = require('./doa');
const controller = Object.create(null);

controller.addLoginLog = ({ ip, userId }) => {
  const newLog = {
    type: 'LOGIN_SUPER_ADMIN',
    logDetail: {
      ip,
      userId
    }
  };

  return doa.create({  obj:newLog  });
};

// done
controller.addTrxnStatusLog = ({ trxnId:transactionId,userId:updatedBy,status, ip }) => {
  const newLog = {
    type: 'TRXN_STATUS_UPDATE',
    logDetail: {
      transactionId,
      updatedBy,
      status,
      ip
    }
  };

  return doa.create({ obj:newLog });
};

// done
controller.addTrxnTokensTransferredLog = ({ trxnId:transactionId,userId:updatedBy,tokensTransferred, ip }) => {
  const newLog = {
    type: 'TRXN_TOKENSTRANSFERRED_UPDATE',
    logDetail: {
      transactionId,
      updatedBy,
      tokensTransferred,
      ip
    }
  };

  return doa.create({ obj:newLog });
};

// done
controller.addSignInLog = ( { _id, email, loginAt, ip } ) => {
  const newLog = {
    userActionType: 'SIGN_IN',
    user: _id,
    userLogDetail: {
      email,
      loginAt,
      ip
    }
  };

  return doa.create( { obj: newLog } );
};

// controller.addSubscribeLog = ( { _id, email, SubscribeAt } ) => {
//   const newLog = {
//     userActionType: 'SUBSCRIBE',
//     user: _id,
//     userLogDetail: {
//       email,
//       SubscribeAt
//     }
//   };
//
//   return doa.create( { obj: newLog } );
// };

// done
controller.addUpdateProfileLog = ( { _id, email, updatedAt, ip } ) => {
  const newLog = {
    userActionType: 'UPDATE_PROFILE',
    user: _id,
    userLogDetail: {
      email,
      updatedAt,
      ip
    }
  };

  return doa.create( { obj: newLog } );
};
// done
controller.addUploadImageLog = ( { _id, email, imageUri, uploadedAt, ip } ) => {
  const newLog = {
    userActionType: 'UPLOAD_IMAGE',
    user: _id,
    userLogDetail: {
      email,
      imageUri,
      uploadedAt,
      ip
    }
  };

  return doa.create( { obj: newLog } );
};

// done
controller.addUploadSaftLog = ( { _id, email, imageUri, uploadedAt, ip } ) => {
  const newLog = {
    userActionType: 'UPLOAD_SAFT_IMAGE',
    user: _id,
    userLogDetail: {
      email,
      imageUri,
      uploadedAt,
      ip
    }
  };

  return doa.create( { obj: newLog } );
};

// done
controller.addResetPasswordLog = ( { _id, email, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'RESET_PASSWORD',
    user: _id,
    userLogDetail: {
      email,
      submittedAt,
      ip
    }
  };

  return doa.create( { obj: newLog } );
};

// done
controller.addDepositTransactionLog = ( { _id, email, transactionId, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'DEPOSIT_TRANSACTION',
    user: _id,
    userLogDetail: {
      email,
      transactionId,
      submittedAt,
      ip
    }
  };

  return doa.create( { obj: newLog } );
};

// done
controller.addTransactionHashLog = ( { _id, email, transactionId, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'ADD_TRANSACTION_HASH',
    user: _id,
    userLogDetail: {
      email,
      transactionId,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// controller.addUserDepositLog = ( { _id, email, data, submittedAt } ) => {
//   const newLog = {
//     userActionType: 'USER_DEPOSIT',
//     user: _id,
//     userLogDetail: {
//       email,
//       data,
//       submittedAt
//     }
//   };
//   return doa.create( { obj: newLog } );
// };

// done
controller.addSendSupportMailLog = ( { _id, email, topic, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'SUPPORT_MAIL',
    user: _id,
    userLogDetail: {
      email,
      topic,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// controller.addGetUserRefersLog = ( { _id, email, data, submittedAt } ) => {
//   const newLog = {
//     userActionType: 'GET_USER_REFERS',
//     user: _id,
//     userLogDetail: {
//       email,
//       data,
//       submittedAt
//     }
//   };
//   return doa.create( { obj: newLog } );
// };

// done
controller.addSubmitKycDetailsLog = ( { _id, email, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'SUBMIT_KYC_DETAILS',
    user: _id,
    userLogDetail: {
      email,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// done
controller.addUploadKycDocLog = ( { _id, email, imageUri, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'UPLOAD_KYC_DOC',
    user: _id,
    userLogDetail: {
      email,
      imageUri,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// done
controller.addCreateTicketLog = ( { _id, email, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'CREATE_TICKET',
    user: _id,
    userLogDetail: {
      email,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// controller.addGetUserTicketsLog = ( { _id, email, userTickets, submittedAt } ) => {
//   const newLog = {
//     userActionType: 'GET_USERS_TICKET',
//     user: _id,
//     userLogDetail: {
//       email,
//       userTickets,
//       submittedAt
//     }
//   };
//   return doa.create( { obj: newLog } );
// };

// done
controller.addSendMessageLog = ( { _id, email, ticketId, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'SEND_MESSAGE',
    user: _id,
    userLogDetail: {
      email,
      ticketId,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// controller.addGetMessagesLog = ( { _id, email, ticketId, messages, submittedAt } ) => {
//   const newLog = {
//     userActionType: 'GET_MESSAGES',
//     user: _id,
//     userLogDetail: {
//       email,
//       ticketId,
//       messages,
//       submittedAt
//     }
//   };
//   return doa.create( { obj: newLog } );
// };

// done
controller.addCloseTicketLog = ( { _id, email, ticketId, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'CLOSE_TICKET',
    user: _id,
    userLogDetail: {
      email,
      ticketId,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// done
controller.addSubmitVoteLog = ( { _id, email, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'SUBMIT_VOTE',
    user: _id,
    userLogDetail: {
      email,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// done
controller.add2FAEnableLog = ( { _id, email, qrCode, secretCode, submittedAt, ip } ) => {
  const newLog = {
    userActionType: '2FA_ENABLE',
    user: _id,
    userLogDetail: {
      email,
      qrCode,
      secretCode,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// done
controller.add2FADisableLog = ( { _id, email, responseMessage, submittedAt, ip } ) => {
  const newLog = {
    userActionType: '2FA_DISABLE',
    user: _id,
    userLogDetail: {
      email,
      responseMessage,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// done (need to check in ui)
controller.add2FAVerifyLog = ( { _id, email, submittedAt, ip } ) => {
  const newLog = {
    userActionType: '2FA_VERIFY',
    user: _id,
    userLogDetail: {
      email,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

// done
controller.addReferByEmailLog = ( { _id, email, submittedAt, ip } ) => {
  const newLog = {
    userActionType: 'REFER_BY_EMAIL',
    user: _id,
    userLogDetail: {
      email,
      submittedAt,
      ip
    }
  };
  return doa.create( { obj: newLog } );
};

controller.getAllUserLogs = ({ _id }) => {

  const data = {
    user: _id
  };

  return doa.find({ params: data });

};

module.exports = controller;
