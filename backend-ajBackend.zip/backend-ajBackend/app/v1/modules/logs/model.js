const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const logSchema = new mongoose.Schema({
  type: {
    type: String,
    enum:['LOGIN_SUPER_ADMIN','TRXN_STATUS_UPDATE','TRXN_TOKENSTRANSFERRED_UPDATE']
  },
  logDetail : { type : Object },

  user: {
    type: Schema.Types.ObjectId,
    ref: "Users"
  },

  userActionType: {
    type: String,
    enum: [
      'SIGN_IN',
      // 'SUBSCRIBE',
      'UPDATE_PROFILE',
      'UPLOAD_IMAGE',
      'UPLOAD_SAFT_IMAGE',
      'RESET_PASSWORD',
      'DEPOSIT_TRANSACTION',
      'ADD_TRANSACTION_HASH',
      // 'USER_DEPOSIT',
      'SUPPORT_MAIL',
      // 'GET_USER_REFERS',
      'SUBMIT_KYC_DETAILS',
      'UPLOAD_KYC_DOC',
      'CREATE_TICKET',
      // 'GET_USERS_TICKET',
      'SEND_MESSAGE',
      // 'GET_MESSAGES',
      'CLOSE_TICKET',
      'SUBMIT_VOTE',
      '2FA_ENABLE',
      '2FA_DISABLE',
      '2FA_VERIFY',
      'REFER_BY_EMAIL'
    ]
  },
  userLogDetail: {
    type: Object
  }
},
{
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at'
  }
});

const Log = mongoose.model('Log', logSchema);
module.exports = Log;
