const multer = require('multer'),
  passport = require('passport'),
  request = require('request'),
  { celebrate } = require('celebrate'),
  { check2FA } = require('../2FA/controller'),
  controller = require('./controller'),
  { addLoginLog } = require('./../logs/controller'),
  helper = require('utils/helper'),
  logger = require('config/logger'),
  validateSchema = require('./schema'),
  constants = require('config/constants');

const formDecode = multer().none();
const authenticate = require('./../../config/authenticate');

const checkIfSuperAdmin = (req, res, next) => {
  if (req.user.role === 'SUPER_ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};

const checkIfAdminOrSuperAdmin = (req, res, next) => {
  //   console.log(req.user);
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};

let checkCaptcha = (req, res, next) => { // eslint-disable-line
  // if (req.app.get('env') === 'development') {
  //   return next();
  // }

  const isIpad = !!req.headers['user-agent'].match(/iPad/);
  const isAndroid = !!req.headers['user-agent'].match(/Android/);
  const isWindows = !!req.headers['user-agent'].match(/Windows/);
  const isIphone = !!req.headers['user-agent'].match(/Iphone/);
  const isMac = !!req.headers['user-agent'].match(/Macintosh/);
  let message;
  if(isWindows) {
    message = 'Please verify that you are not a robot. If you are unable to reCaptcha, please press Ctrl+R';
  }
  else if(isAndroid) {
    message = 'Please verify that you are not a robot. If you are unable to see reCaptcha, please reload the site';
  }
  else if(isIpad) {
    message = 'Please verify that you are not a robot. If you are unable to see reCaptcha, please reload the site';
  }
  else if(isMac) {
    message = 'Please verify that you are not a robot. If you are unable to see reCaptcha, please press Command+R';
  }
  else if(isIphone) {
    message = 'Please verify that you are not a robot. If you are unable to see reCaptcha, please reload the site';
  }
  else {
    message = 'Please verify that you are not a robot. If you are unable to see reCaptcha, please reload the site';
  }


  request.post({
    url: constants.gCaptcha.url,
    form: {
      secret: constants.gCaptcha.secret,
      response: !!req.body.data ? req.body.data.captcha : req.body.captcha,
      remoteip: req.ip
    }
  },
  (err, httpResponse, body) => { /* ... */
    if (err) {
      logger.info(err);
      console.log(req.headers['user-agent']);
      return res.status(200).json({
        success: false,
        message: message
      });
      //return next(boom.badImplementation(err));
    }
    else {
      const resData = JSON.parse(body);
      logger.info(resData);
      if (resData.success) {
      	return next();
      } else {
      	return res.status(200).json({
      		success: false,
      		message: message
      	});
      }
    }

  });

};

module.exports = function (router) {

  /**
	 * @swagger
	 * /superadmin/login:
	 *   post:
	 *     description: Super Admin local login
	 *     tags:
	 *       - Super_Admin
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: email
	 *         description: user's email.
	 *         in: body
	 *         required: true
	 *         type: string
	 *       - name: password
	 *         description: user's password.
	 *         in: body
	 *         required: true
	 *         type: string
	 *       - name: otpToken
	 *         description: user's authenticator app otp.
	 *         in: body
	 *         required: false
	 *         type: string
	 *     responses:
	 *       200:
	 *        	description: login success
	 */
  router.post('/superadmin/login', helper.removeFalsy, checkCaptcha, formDecode, celebrate(validateSchema.login), passport.authenticate('superAdmin-local-login', {
    session: false
  }), (req, res, next) => {
    if (req.user.isError) {
      logger.debug(req.user.message);
      return res.status(200).json({ success: false, message: req.user.message });
    } else {
      next();
    }
  }, check2FA, async (req, res, next) => {
    //console.log(req.token, 'in login local');
    if (!req.is2FA_enabled) {
      try {
        if (!await addLoginLog({ ip: req.ip, userId: req.user.id })) {
          logger.error('unable to record login log', req.ip, req.user.id);
        }
      } catch (error) {
        return next(error);
      }
      res.status(200).json({
        success: true,
        is2FA_enabled: false,
        authToken: req.token
      });
    } else if (req.is2FA_provided) {
      if (req.is2FA_valid) {
        try {
          if (!await addLoginLog({ ip: req.ip, userId: req.user.id })) {
            logger.error('unable to record login log', req.ip, req.user.id);
          }
        } catch (error) {
          return next(error);
        }
        res.status(200).json({
          success: true,
          message: constants.responseMsgs.LOGIN.EMPTY_2FA,
          is2FA_enabled: true,
          is2FA_valid: true,
          authToken: req.token
        });
      } else {
        res.status(200).json({
          success: false,
          message: 'Your 2FA is not correct',
          is2FA_enabled: true,
          is2FA_valid: false,
          authToken: ''
        });
      }
      //res.status(200).json({ success: true, is2fa ,authToken: '' });
    } else {
      res.status(200).json({
        success: false,
        is2FA_enabled: true,
        authToken: ''
      });
    }

  });

  /**
	 * @swagger
	 * /admin:
	 *  post:
	 *   description: Create admin
	 *   tags:
	 *    - Super_Admin
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: email
	 *      in: body
	 *      type : string
	 *      required: true
	 *      description: new unique email
	 *    - name: password
	 *      in: body
	 *      type : string
	 *      required: false
	 *      description: new unique password in case of new user
   *    - name: verifyKyc
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: verifyKyc permission
   *    - name: sendMail
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: sendmail permission
   *    - name: approveTransaction
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: approveTransaction permission
   *    - name: deleteTransaction
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: deleteTransaction permission
   *    - name: transferTokens
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: transferTokens permission
   *    - name: exportTransactionsExcel
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: exportTransactionsExcel permissions
   *    - name: exportUsersExcel
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: exportUsersExcel permission
   *    - name: manageSmartContract
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: manageSmartContract
   *    - name: manageBounty
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: manageBounty
   *    - name: manageAirdrop
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: manageAirdrop
   *    - name: updateReferalProgram
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: updateReferalProgram
   *    - name: inviteInvestor
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: inviteInvestor
	 *    - name: x-auth-token
	 *      in: header
	 *      type: string
	 *      required: true
	 *      description: Token obtained on login
	 *   responses:
	 *    200:
	 *     description:
	 */
  router.post('/admin', authenticate, checkIfSuperAdmin, formDecode, controller.createAdmin);

	  /**
	 * @swagger
	 * /adminToUser:
	 *  post:
	 *   description: Change Admin To User
	 *   tags:
	 *    - Super_Admin
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: email
	 *      in: body
	 *      type : string
	 *      required: true
	 *      description: email
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *       type: string
	 *      required: true
	 *      description: Token obtained on login
	 *   responses:
	 *    200:
	 *     description:
	 */

  router.post('/adminToUser', authenticate, checkIfSuperAdmin, formDecode, controller.changeAccess);

  /**
	 * @swagger
	 * /admin:
	 *  post:
	 *   description: Create admin
	 *   tags:
	 *    - Super_Admin
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: userId
	 *      in: body
	 *      type : string
	 *      required: true
	 *      description: user userId
   *    - name: verifyKyc
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: verifyKyc permission
   *    - name: sendMail
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: sendmail permission
   *    - name: approveTransaction
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: approveTransaction permission
   *    - name: deleteTransaction
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: deleteTransaction permission
   *    - name: transferTokens
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: transferTokens permission
   *    - name: exportTransactionsExcel
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: exportTransactionsExcel permissions
   *    - name: exportUsersExcel
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: exportUsersExcel permission
   *    - name: manageSmartContract
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: manageSmartContract
   *    - name: manageBounty
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: manageBounty
   *    - name: manageAirdrop
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: manageAirdrop
   *    - name: updateReferalProgram
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: updateReferalProgram
   *    - name: inviteInvestor
	 *      in: body
	 *      type : boolean
	 *      required: false
	 *      description: inviteInvestor
	 *    - name: x-auth-token
	 *      in: header
	 *      type: string
	 *      required: true
	 *      description: Token obtained on login
	 *   responses:
	 *    200:
	 *     description:
	 */


  router.put('/admin/permissions', authenticate, checkIfSuperAdmin, formDecode, celebrate(validateSchema.updatePermissions), controller.updatePermissions);

  /**
	 * @swagger
	 * /admin:
	 *  get:
	 *   description: Get admins list
	 *   tags:
	 *    - Super_Admin
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *       type: string
	 *      required: true
	 *      description: Token obtained on login
	 *   responses:
	 *    200:
	 *     description:
	 */
  router.get('/admin', authenticate, checkIfSuperAdmin, controller.getAdminList);

  /**
	 * @swagger
	 * /admin/logs:
	 *  get:
	 *   description: Get admins list
	 *   tags:
	 *    - Super_Admin
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *       type: string
	 *      required: true
	 *      description: Token obtained on login
	 *    - name: logdate
	 *      in: query
	 *      schema:
	 *       type: string
	 *      required: false
	 *      description: log date in YYYY-MM-D format. by default gives todays log
	 *   responses:
	 *    200:
	 *     description:
	 */
  router.get('/admin/logs', authenticate, checkIfSuperAdmin, controller.getlogs);


  /**
	 * @swagger
	 * /logs:
	 *  get:
	 *   description: Get admins list
	 *   tags:
	 *    - Super_Admin
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *       type: string
	 *      required: true
	 *      description: Token obtained on login
	 *    - name: logdate
	 *      in: query
	 *      schema:
	 *       type: string
	 *      required: false
	 *      description: log date in YYYY-MM-D format. by default gives todays log
	 *   responses:
	 *    200:
	 *     description:
	 */
  //router.get('/logs', authenticate, checkIfSuperAdmin, controller.getTransactions);

  /**
	 * @swagger
	 * /admin/monitor/heapdump:
	 *  put:
	 *   description: Node.js Process HeapDump
	 *   tags:
	 *    - Admin
	 *   produces:
	 *    - application/json
	 *   responses:
	 *    200:
	 *     description: success message
	 */

  // router.get('/admin/monitor/heapdump', authenticate, checkIfAdmin,function(req, res) {
  // 	const heapdump = require('heapdump');

  // 	heapdump.writeSnapshot(function (err, filename) {
  // 		console.log('creating snapshot', filename);
  // 		fs.readFile(filename, "utf-8", function (err, data) {
  // 			// body
  // 			res.end(data);
  // 		})
  // 	});
  // });

  router.get('/admin/user-trx-stats', authenticate, checkIfSuperAdmin, controller.userTrxnStats);

	  /**
 * @swagger
 * admin/signup/investor:
 *   post:
 *     description: investor local signup
 *     tags:
 *       - Super_Admin
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: email
 *         description: user's email.
 *         in: body
 *         required: true
 *         type: string
 *       - name: fullName
 *         description: user's full name.
 *         in: body
 *         required: true
 *         type: string
 *       - name: sendVerificationMail
 *         description: sendVerificationMail check default false
 *         in: body
 *         required: false
 *         type: boolean
 *       - name: phase
 *         description: phase can be any of these values 'privateSale','preSale','crowdSale'
 *         in: body
 *         required: false
 *         type: string
 *       - name: type
 *         description: type can be any of these values 'Ethereum', 'Bitcoin', 'vote', 'refer'
 *         in: body
 *         required: true
 *         type: string
 *       - name: saftDoc
 *         description: saft document
 *         in: body
 *         required: false
 *         type: string
 *       - name: transactionHash
 *         description: blockchain transactionHash
 *         in: body
 *         required: false
 *         type: string
 *       - name: amountInvested
 *         description: amount of btc,eth and usd invested
 *         in: body
 *         required: true
 *         type: nymber
 *       - name: tokens
 *         description: number of tokens
 *         in: body
 *         required: false
 *         type: number
 *       - name: tokensTransferred
 *         description: is investor got the tokens
 *         in: body
 *         required: false
 *         type: boolean
 *       - name: bonus
 *         description: bonus percentage
 *         in: body
 *         required: false
 *         type: number
 *       - name : tokenPrice
 *         description : current tokenPrice
 *         in : body
 *         required : false
 *         type : number
 *
 *     responses:
 *       200:
 *        	description: Investor Signup success message
 */

  router.post(
    '/admin/signup/investor',
    helper.removeFalsy,
    celebrate(validateSchema.addInvestor),
    authenticate,
    checkIfAdminOrSuperAdmin,
    passport.authenticate('investor-signup', { session: false }),
    controller.updateInvestorsContribution,
    (req, res, next) => {

      if(req.user.isError) {
        console.log(req.user.message);
        return res.status(200).json({ success:false, message: req.user.message });
      } else {
        logger.debug('here in signup');
        res.status(200).json({ success: true, message: 'signup/transaction addition done' });
      }
    }
  );


};
