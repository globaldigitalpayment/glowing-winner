const Path = require('path'),
  fs = require('fs'),
  moment = require('moment'),
  helper = require('utils/helper'),
  modelFunction = require('../user/doa'),
  logger = require('config/logger'),
  mailer = require('config/nodemailer'),
  { sendSignupVerificationMailWillPassword } = require('../user/controller'),
  trxnModelFunction = require('./../transaction/doa'),
  User = require('../user/model'),
  userDoa = require('./../user/doa'),
  errorHandler = require('utils/errorHandler'),
  path = require('path'),
  
  storage = require('node-persist'),
  { addNewTraxn, updateTrxnHash } = require('./../transaction/controller'),
  constants = require('config/constants'),
  rpn = require('request-promise-native');
const controller = Object.create(null);
const newFile = path.join(__dirname, '../../../../keyValueFile');
controller.updateInvestorsContribution = async (req, res, next) => {
  await storage.init({
    dir: newFile,

    stringify: JSON.stringify,

    parse: JSON.parse,

    encoding: 'utf8',

    logging: false,  // can also be custom logging function

    ttl: false, // ttl* [NEW], can be true for 24h default or a number in MILLISECONDS

    expiredInterval: 2 * 60 * 1000, // every 2 minutes the process will clean-up the expired cache

    // in some cases, you (or some other service) might add non-valid storage files to your
    // storage dir, i.e. Google Drive, make this true if you'd like to ignore these files and not throw an error
    forgiveParseErrors: false

  });
  if (req.user.isError) {
    return res.status(200).json({ success:false, message: req.user.message });
  } else {
    if(!!req.user.exist) {
      if (!!req.user.transactionHash || !!req.user.amount || !!req.user.tokens) {
        const userId = req.user.id,
          userEmail = req.user.email;

        let trxnRecord = false;

        try {
          const mainOptions = {
            json: true // Automatically parses the JSON string in the response
          };
          let price;
          if(req.user.type === 'Bitcoin') {
            const btcReqOpt = Object.assign({}, mainOptions);
            btcReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=XXBTZUSD';
            const result = await rpn(btcReqOpt);
            console.log(result.result.XXBTZUSD.a[0],'cureent result');
            price = result.result.XXBTZUSD.a[0];
          } else if(req.user.type === 'Ethereum') {
            const btcReqOpt = Object.assign({}, mainOptions);
            btcReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=XETHZUSD';
            const result = await rpn(btcReqOpt);

            console.log(result,'cureent result');
            price = result.result.XETHZUSD.a[0];
          }  else if(req.user.type === 'USDT') {
            const usdtReqOpt = Object.assign({}, mainOptions);
            usdtReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=USDTZUSD';
            const result = await rpn(usdtReqOpt);

            console.log(result,'cureent result');
            price = result.result.USDTZUSD.a[0];
          }


          trxnRecord = await addNewTraxn({
            userId: req.user.id,
            creatorId: req.user.id,
            creatorEmail: req.user.email,
            tokens: req.user.tokens, // tokens after bonus
            type: req.user.type, //vote/refer or btc/eth
            // fromAddress: req.body.fromAddress, // btc/eth address
            // toAddress: req.body.toAddress, // private sale address
            tokenReceivingAddress: req.body.tokenReceivingAddress,
            usdAmount: req.user.type === 'USD' ? req.user.amount : price * req.user.amount,
            amount: req.user.amount,
            rate: req.user.type === 'USD' ? 0 : price,
            phase: req.user.phase,
            transactionHash :req.user.transactionHash,
            tokensTransferred : req.user.tokensTransferred,
            status :req.user.status,
            bonus: req.user.bonus,
            // Add discount and isBonusDiscount *****
            isBonusOrDiscount: req.body.isBonusDiscount,
            discount: req.body.discount,
            tokenPrice: req.user.tokenPrice,
            referBonus: await storage.getItem('amountPercent')
          });

          //const referTokens = (trxnFindResult.referBonus / 100) * (trxnFindResult.tokens * 100 / (trxnFindResult.bonus + 100)); //eslint-disable-line

          if (!!req.user.refereeId && !!req.user.updateRefer ) {
            let data = { // eslint-disable-line
              $inc: {
                'tokens.referral': (await storage.getItem('amountPercent') / 100) * (req.user.tokens * 100 / (req.user.bonus + 100)), //eslint-disable-line
                'tokens.total': (await storage.getItem('amountPercent') / 100) * (req.user.tokens * 100 / (req.user.bonus + 100)) //eslint-disable-line
              }
            };

            const insertResult = await userDoa.findByIdAndUpdate({ id: req.user.refereeId,data }); // eslint-disable-line
          }
        } catch (error) {
          next(error);
        }

        if (!trxnRecord) {
          logger.error('Unable to record trxn =>', { userId, tokens: 0, creatorId: userId, creatorEmail: userEmail });
          return next(new Error('please try again'));
        }
        next();
      }
    }
    else {
      if (!!req.user.transactionHash || !!req.user.amount || !!req.user.tokens) {
        const userId = req.user.id,
          userEmail = req.user.email;

        let trxnRecord = false;
        try {

          const mainOptions = {
            json: true // Automatically parses the JSON string in the response
          };

          let price;
          if (req.user.type === 'Bitcoin') {
            const btcReqOpt = Object.assign({}, mainOptions);
            btcReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=XXBTZUSD';
            const result = await rpn(btcReqOpt);
            console.log(result.result.XXBTZUSD.a[0], 'cureent result');
            price = result.result.XXBTZUSD.a[0];
          } else if (req.user.type === 'Ethereum') {
            const btcReqOpt = Object.assign({}, mainOptions);
            btcReqOpt.uri = 'https://api.kraken.com/0/public/Ticker?pair=XETHZUSD';
            const result = await rpn(btcReqOpt);

            console.log(result, 'cureent result');
            price = result.result.XETHZUSD.a[0];
          }

          trxnRecord = await addNewTraxn({
            userId: req.user.id,
            creatorId: req.user.id,
            creatorEmail: req.user.email,
            tokens: req.user.tokens, // tokens after bonus
            type: req.user.type, //vote/refer or btc/eth
            // fromAddress: req.body.fromAddress, // btc/eth address
            // toAddress: req.body.toAddress, // private sale address
            tokenReceivingAddress: req.body.tokenReceivingAddress,
            // usdAmount: req.body.usdAmount,
            amount: req.user.amount,
            phase: req.user.phase,
            transactionHash :req.user.transactionHash,
            tokensTransferred : req.user.tokensTransferred,
            status : req.user.status,
            bonus: req.user.bonus,
            // Add discount and isBonusDiscount *****
            isBonusOrDiscount: req.body.isBonusDiscount,
            discount: req.body.discount,
            tokenPrice: req.user.tokenPrice,
            rate: req.user.type === 'USD' ? 0 : price,
            referBonus: await storage.getItem('amountPercent')
          });
        } catch (error) {
          next(error);
        }

        if (!trxnRecord) {
          logger.error('Unable to record trxn =>', { userId, tokens: 0, creatorId: userId, creatorEmail: userEmail });
          return next(new Error('please try again'));
        }
        next();
      }
    }
  }
};
controller.changeAccess = (req, res, next) => {
  let email = req.body.email,
    createdBy = req.user.local.email;

  User.findOne({
    $or: [{
      'local.email': email
    }, {
      'email.value': email
    }]
  }, (err, user) => {
    // if there are any errors, return the error
    if (err) {
      return next(err);
    }

    if (user.local.email === email) {

      const userName = user.personalDetails.fullName;

      user.role = 'USER';
      user.createdBy = createdBy;

      user.save((err) => {
        if (err) {
          throw err;
        }

        mailer({
          mailType: 'AFTER_CHANGE_ACCESS',
          to: req.body.email,
          data: {
            to: req.body.email,
            userName
          }
        });

        return res.status(200).json({
          success: true,
          message: 'Access control changed to User successfully'
        });
      });
    }
  });
};

controller.createAdmin = (req, res, next) => {
  let email = req.body.email,
    password = req.body.password,
    permissions = {
      verifyKyc : req.body.verifyKyc,
      sendMail : req.body.sendMail,
      deleteUser : req.body.deleteUser,
      approveTransaction : req.body.approveTransaction,
      deleteTransaction : req.body.deleteTransaction,
      transferTokens : req.body.transferTokens,
      exportTransactionsExcel : req.body.exportTransactionsExcel,
      exportUsersExcel : req.body.exportUsersExcel,
      manageSmartContract : req.body.manageSmartContract,
      manageBounty : req.body.manageBounty,
      manageAirdrop : req.body.manageAirdrop,
      updateReferalProgram: req.body.updateReferal,
      inviteInvestor: req.body.inviteInvestor
    };

  User.findOne({
    $or: [{
      'local.email': email
    }, {
      'email.value': email
    }]
  }, (err, user) => {
    // if there are any errors, return the error
    if (err) {
      return next(err);
    }

    if (user) {
      if (user.local.email === email) {

        const userName = user.personalDetails.fullName;

        if (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN') {
          user.role = 'ADMIN';
          user.createdBy = req.user.local.email;
          user.permissions = permissions;
          // save the user
          user.save((err) => { // eslint-disable-line no-shadow
            if (err) {
              throw err;
            }

            mailer({
              mailType: 'AFTER_ADMIN_UPGRADATION',
              to: email,
              data: {
                userName,
                to : email
              }
            });

            return res.status(200).json({
              success: true,
              message: 'User account has been upgraded to admin successfully'
            });

          });

        }else {
          return res.status(200).json({
            success: true,
            message: 'User is already admin'
          });
        }

      }else if (user.subscribe.email === email) {
        // subscriber found. convert to user
        user.local.email = email;
        user.local.password = user.generateHash(password);
        user.accountVerify.verificationHash = helper.getRandomToken();
        user.accountVerify.expiresAt = constants.emailVerifyExpiry; // 1d
        user.userState = 'USER';
        user.accountState = 'e';
        user.role = 'ADMIN';
        user.createdBy = req.user.local.email;
        user.permissions = permissions;
        user.isInfoActive = true;
        // save the user
        user.save((err) => { // eslint-disable-line no-shadow
          if (err) {
            throw err;
          }
          // sendSignupVerificationMail({
          //   email: email,
          //   token: user.accountVerify.verificationHash,
          //   fullName : ''
          // });

          sendSignupVerificationMailWillPassword({
            email: email,
            token: user.accountVerify.verificationHash,
            password: password,
            fullName: ''
          });


          return res.status(200).json({
            success: true,
            message: 'Admin created successfuly'
          });
        });
      } else {
        const {
          status,
          message,
          description
        } = errorHandler({
          errorType: '',
          message: 'User already exists with unknown existing attribute',
          description: ''
        });

        res.status(status).json({
          success: false,
          message,
          description
        });
      }
    } else if (password.trim().length < 6) {
      res.status(200).json({
        success: false,
        message: 'Password cannot be less than six characters'
      });
    }
    else {

      // if there is no user with that email
      // create the user
      const newUser = new User();

      if (req.cookies.pcode) {
        newUser.temp = req.cookies.pcode;
      }

      // set the user's local credentials
      newUser.local.email = email;
      newUser.email.value = email;
      newUser.local.isPrimary = true;
      newUser.local.password = newUser.generateHash(password);
      newUser.accountVerify.verificationHash = helper.getRandomToken();
      newUser.accountVerify.expiresAt = constants.emailVerifyExpiry; // Date.now() + (3600000*24); // 1d
      newUser.userState = 'USER';
      newUser.accountState = 'e';
      newUser.role = 'ADMIN';
      newUser.permissions = permissions;
      newUser.isInfoActive = true;
      newUser.createdBy = req.user.local.email;
      // save the user
      newUser.save((err) => { // eslint-disable-line no-shadow
        if (err) {
          throw err;
        }
        // sendSignupVerificationMail({
        //   email: email,
        //   token: newUser.accountVerify.verificationHash,
        //   fullName : ''
        // });

        sendSignupVerificationMailWillPassword({
          email: email,
          token: newUser.accountVerify.verificationHash,
          password: password,
          fullName: ''
        });

        return res.status(200).json({
          success: true,
          message: 'Admin created successfully'
        });
      });
    }

  });
};


controller.getAdminList = async (req, res, next) => {
  const params = {
    role: 'ADMIN'
  };
  const selector = {
    local: 1,
    createdBy: 1,
    role: 'ADMIN',
    permissions: 1
  };
  try {
    var results = await modelFunction.find({ // eslint-disable-line
      params,
      selector
    });
  } catch (error) {
    next(error);
  }

  res.status(200).json({
    success: true,
    users: results
  });
};


controller.getlogs = async (req, res, next) => {
  let logDate = req.query.logdate;
  const dateObj = new Date();
  const tempdate = dateObj.getDate() < 10 ? `0${dateObj.getDate()}` : dateObj.getDate();
  const tempmonth = dateObj.getMonth() + 1 < 10 ? `0${dateObj.getMonth() + 1}` : dateObj.getMonth() + 1;

  const currentDate = `${dateObj.getFullYear()}-${tempmonth}-${tempdate}`;
  if (!logDate) {
    logDate = currentDate;
  }
  const logsPath = Path.join(req.app.get('rootPath'), 'log', `-results-${logDate}.log`);

  try {
    fs.accessSync(logsPath);
    res.download(logsPath);
  } catch (error) {
    res.status(200).json({
      success: false,
      message: 'Error fetching Log.',
      description: ''
    });
  }
};

controller.updatePermissions = async (req, res, next) => {
  const query = {
    _id : req.body.userId
  };

  const params = {
    $set : {
      ['permissions.verifyKyc']: req.body.verifyKyc || false,
      ['permissions.sendMail']: req.body.sendMail || false,
      ['permissions.deleteUser'] : req.body.deleteUser || false,
      ['permissions.approveTransaction']: req.body.approveTransaction || false,
      ['permissions.deleteTransaction']: req.body.deleteTransaction || false,
      ['permissions.transferTokens']: req.body.transferTokens || false,
      ['permissions.exportTransactionsExcel']: req.body.exportTransactionsExcel || false,
      ['permissions.exportUsersExcel']: req.body.exportUsersExcel || false,
      ['permissions.manageSmartContract']: req.body.manageSmartContract || false,
      ['permissions.manageBounty']: req.body.manageBounty || false,
      ['permissions.manageAirdrop']: req.body.manageAirdrop || false,
      ['permissions.updateReferalProgram']: req.body.updateReferalProgram || false,
      ['permissions.inviteInvestor']: req.body.inviteInvestor || false
    }
  };

  try {
    var result = await modelFunction.findOneAndUpdate({ //eslint-disable-line
      params,
      query
    });
  } catch (error) {
    next(error);
  }
  res.status(200).send({
    success: true,
    message: 'Permissions Updated!'
  });
};

controller.userTrxnStats = async (req,res,next)=>{
  let statsType = req.query.statsFor;

  const startDate = req.query.startDate ? moment(req.query.startDate).format('YYYY-MM-DD[ 00:00:00]') : moment().subtract(6, 'days').format('YYYY-MM-DD[ 00:00:00]'),
    endDate = req.query.endDate ? moment(req.query.endDate).add(1,'days').format('YYYY-MM-DD[ 00:00:00]') : moment().add(1,'days').format('YYYY-MM-DD[ 00:00:00]');

  const page = req.query.page && req.query.page > 0 ? parseInt(req.query.page) : 1,
    limit = req.query.limit && req.query.limit > 0 ? parseInt(req.query.limit) : 10;
  let params = {},sort = {};

  if (!statsType || statsType !== 'register') {
    statsType = 'login';
    params = {
      'role' : 'USER',
      'loginAt' : {
        '$gte' : new Date(startDate),
        '$lt' : new Date(endDate)
      }
    };
    sort = {
      loginAt: 1
    };
  } else {
    params = {
      'role' : 'USER',
      'created_at' : {
        '$gte' : new Date(startDate),
        '$lt' : new Date(endDate)
      }
    };
    sort = {
      created_at: 1
    };
  }

  const users = await modelFunction.find({ params, sort });
  if (!users.length) {
    return res.status(200).json({ success: true, inActiveUsers : [], count: 0, nextPage : false });
  }
  const userIds = [];
  users.forEach(user => {
    userIds.push(user._id);
  });
  const match  = {
    userId : { $in : userIds },
    status : 'confirmed',
    tokensTransferred : 'yes',
    created_at : {
      '$gte' : new Date(startDate),
      '$lt' : new Date(endDate)
    }
  };
  const group = {
    _id: '$userId'
  };

  const trxnsArr = await trxnModelFunction.aggregatePipeline({ match, group });
  const inActiveUsers = [];
  let count;
  users.forEach(user => {
    let trxnFound = false;
    for (let index = 0; index < trxnsArr.length; index++) {
      const trxn = trxnsArr[index];
      if (trxn._id.equals(user._id)) {
        trxnFound = true;
        break;
      }
    }
    if (!trxnFound) {
      inActiveUsers.push(user);
    }
    count = inActiveUsers.length;
  });

  return res.status(200).json({ success: true, inActiveUsers : inActiveUsers, count, nextPage : false });
};

module.exports = controller;
