const { Joi } = require('celebrate'),
  constants = require('config/constants');

module.exports = {
  login: {
    body: Joi.object().keys({
      email: Joi.string().required(),
      password: Joi.string().required(),
      otpToken: Joi.number(),
      rememberMe : Joi.boolean(),
      captcha: Joi.string().required()
    })
  },
  updatePermissions: {
    body: Joi.object().keys({
      userId: Joi.string().required(),
      verifyKyc: Joi.boolean().required(),
      sendMail: Joi.boolean().required(),
      approveTransaction: Joi.boolean().required(),
      deleteUser :  Joi.boolean().required(),
      deleteTransaction: Joi.boolean().required(),
      transferTokens: Joi.boolean().required(),
      exportTransactionsExcel: Joi.boolean().required(),
      exportUsersExcel: Joi.boolean().required(),
      manageSmartContract : Joi.boolean(),
      manageBounty: Joi.boolean().required(),
      manageAirdrop: Joi.boolean(),
      updateReferalProgram: Joi.boolean(),
      inviteInvestor: Joi.boolean()
    })
  },
  addInvestor: {
      body: Joi.object().keys({
      email: Joi.string().email().required(),
      fullName: Joi.string().min(2).max(100).required(),
      amountInvested: Joi.number().required(),
      phase: Joi.string(),
      saftDoc: Joi.string(),
      type : Joi.any().valid(['Ethereum','Bitcoin', 'USD', 'USDT', 'Other']),
      transactionHash: Joi.string(),
      // phoneNumber: Joi.string(),
      sendVerificationMail: Joi.boolean(),
      tokens : Joi.number(),
      bonus : Joi.number(),
      discount: Joi.number(),
      isBonusDiscount: Joi.string().valid('bonus', 'discount'),
      tokensTransferred : Joi.boolean(),
      tokenReceivingAddress : Joi.string(),
      tokenPrice: Joi.number()
    })
  }
};
