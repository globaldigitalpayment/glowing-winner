const userModelFunction = require('../user/doa'),
  { addReferByEmailLog } = require('./../logs/controller'),
  mailer = require('config/nodemailer');

module.exports.getReferralurl =async (req, res, next) => {
  let userId = req.user.id;
  const params = { _id : userId };
  const selector = 'refer';
  try {
    var result = await userModelFunction.findOne({ params,selector }); // eslint-disable-line no-var
  } catch (error) {
    next(error);
  }
  //let url = `localhost:4031/api/sgnup?pcode=${result.refer.code}`
  res.status(200).json({ referalToken : result.refer.code, success:true });
};

module.exports.getReferedUsers = async (req,res,next)=>{
  const userId = req.user.id;
  const params = { 'refer.referee':userId };
  const selector = 'name local gmail facebook refer';
  try {
    var users = await userModelFunction.find({ params, selector }); // eslint-disable-line no-var
  } catch (error) {
    next(error);
  }
  return res.status(200).json({ success:true,count:users.length,users : users });
};

module.exports.referByEmail = async (req,res,next)=>{
  const userId = req.user.id; // eslint-disable-line
  const email = req.body.email;
  const referrer = req.user.personalDetails.fullName ? req.user.personalDetails.fullName : req.user.local.email;
  const params = {
    'local.email': req.body.email
  };
  let findResult;
  try {
    findResult = await userModelFunction.find({ params, selector : 'local refer' });
  } catch (error) {
    next(error);
  }
  if (!!findResult.length) {
    // Already a user
    return res
      .status(200)
      .json({
        success: false,
        message: 'Already a user'
      });
  }else {
    try{
      mailer({ mailType:'REFER_INVITE', to:email, data : { user : referrer, token:req.user.refer.code } });
      if(!!req.user.saveActivityLogs) {
        var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
          req.connection.remoteAddress ||
          req.socket.remoteAddress ||
          req.connection.socket.remoteAddress;
        let date = new Date();
        date = date.toISOString();
        addReferByEmailLog({ _id: req.user._id, email: req.user.email.value, uploadedAt: date, ip: ip })
          .then(data => {
            console.log('Successfully store log', data);
          })
          .catch(err => {
            logger.error('addReferByEmailLog is unable to store log');
          });
      }
      return res
        .status(200)
        .json({
          success: true,
          message: 'Email sent'
        });
    }catch(err) {
      next(err);
    }
  }
};

function findNonExistentEmail (emailArr,users) {

  users.forEach(element => {
    emailArr.splice(emailArr.indexOf(element.local.email),1);
  });
  return emailArr;
};
