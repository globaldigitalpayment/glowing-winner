const controller = require('./controller'),
  { celebrate } = require('celebrate'),
  validateSchema = require('./schema');

//const validateSchema = require('./schema');

let authenticate = require('./../../config/authenticate');

let checkIfUser = (req, res, next) => {
  if (req.user.role === 'USER') {
    next();
  } else {
    res.status(401).json({ success:false,message:'Invalid Access',description:'' });
    //next(Boom.unauthorized('Invalid Access'))
  }
};

module.exports = function (router) {

  /**
	 * @swagger
	 * /user/my-referral-url:
	 *   get:
	 *     description: get a user's referal link
	 *     tags:
	 *       - Refer
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: x-auth-token
	 *         in: header
	 *         schema:
	 *           type: string
	 *         required: true
	 *         description: Token obtained on login
	 *     responses:
	 *       200:
	 *         description:
	 */
  router.get('/user/my-referral-url', authenticate,checkIfUser,controller.getReferralurl);

  /**
	 * @swagger
	 * /user/my-referrals:
	 *  get:
	 *   description: Get count and list of referrals by a user
	 *   tags:
	 *    - Refer
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *       type: string
	 *      required: true
	 *      description: Token obtained on login
	 *   responses:
	 *    200:
	 *     description:
	 */
  router.get('/user/my-referrals', authenticate,checkIfUser, controller.getReferedUsers);


  /**
	 * @swagger
	 * /refer/invite:
	 *   get:
	 *     description: invite and refer
	 *     tags:
	 *       - Refer
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: x-auth-token
	 *         in: header
	 *         schema:
	 *           type: string
	 *         required: true
	 *         description: Token obtained on login
	 *       - name: email
	 *         in: body
	 *         schema:
	 *           type: string
	 *         required: true
	 *         decription:  email
	 *     responses:
	 *       200:
	 *         description:
	 */
   router.put(
     '/refer/invite',
     authenticate,
     celebrate(validateSchema.emailReq),
     checkIfUser,
     controller.referByEmail);

};
