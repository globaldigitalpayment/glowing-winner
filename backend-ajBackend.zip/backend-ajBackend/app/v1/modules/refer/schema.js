const { Joi } = require('celebrate');

module.exports = {
  emailReq: {
    body: Joi.object().keys({
      email: Joi.string().required()
    })
  }
};
