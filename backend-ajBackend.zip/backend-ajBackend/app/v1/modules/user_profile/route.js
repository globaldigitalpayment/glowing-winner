const dashBoardController = require('./controller');

const authenticate = require('./../../config/authenticate');

module.exports = function(router) {
  /**
	 * @swagger
	 * /user/profile:
	 *   get:
	 *     description: get logged in user's profile
	 *     tags:
	 *       - Users
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: x-auth-token
	 *         in: header
	 *         schema:
	 *           type: string
	 *         required: true
	 *         description: Token obtained on login
	 *     responses:
	 *       200:
	 *        	description: User's profile
	 */

  router.get('/user/profile', authenticate, dashBoardController.getUserProfile);
}
;
