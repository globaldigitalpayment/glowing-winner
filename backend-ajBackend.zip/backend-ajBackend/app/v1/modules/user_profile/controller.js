const userModelFunction = require('./../user/doa'),
  storage = require('node-persist'),
  path = require('path'),
  Boom = require('boom');

const profileController = Object.create(null);
const newFile = path.join(__dirname, '../../../../keyValueFile');

profileController.getUserProfile = async (req, res, next) => {
  await storage.init({
    dir: newFile,
    stringify: JSON.stringify,
    parse: JSON.parse,
    encoding: 'utf8',
    logging: false,
    ttl: false,
    expiredInterval: 2 * 60 * 1000,
    forgiveParseErrors: false
  });

  // hard-coding the value , this value will be comming from live api in future
  // await storage.setItem('status', true);
  // await storage.removeItem('status');
  // await storage.removeItem('amountPercent');
  const status =  await storage.getItem('status');
  //await storage.setItem('amountPercent', 20)
  const amountPercent =  await storage.getItem('amountPercent');

  // await storage.getItem('btcAddress')
  //   .then((value) => console.log("btcAddress : ", value))
  //   .catch((err) => console.log("Error : ", err));

  const userId = req.user.id;
  try {
    var userInfo = await userModelFunction.findById({ id: userId, projection: 'personalDetails local.email local.2FA.isEnabled refer tokens kycStatus kycDetails accountVerify isBlocked isWhitelisted saveActivityLogs isInfoActive' }); //eslint-disable-line

  } catch (error) {
    next(Boom.badImplementation(error));
  }
  if (!userInfo) {
    res.status(200).json({ success: false, message: 'User Not found in system' });
  }
  console.log('userInfo : ', userInfo);
  const resObj = {
    email : userInfo.local.email ? userInfo.local.email : '',
    fullName: userInfo.personalDetails.fullName ? userInfo.personalDetails.fullName : '',
    phone: userInfo.personalDetails.phoneNumber ? userInfo.personalDetails.phoneNumber : '',
    ethAddress: userInfo.personalDetails.ethAddress ? userInfo.personalDetails.ethAddress : '',
    dob: userInfo.personalDetails.dob ? userInfo.personalDetails.dob : '',
    gender: userInfo.personalDetails.gender ? userInfo.personalDetails.gender : '',
    telegram: userInfo.personalDetails.telegram ? userInfo.personalDetails.telegram : '',
    twitter: userInfo.personalDetails.twitter ? userInfo.personalDetails.twitter : '',
    creative: userInfo.personalDetails.creative ? userInfo.personalDetails.creative : '',
    youtube: userInfo.personalDetails.youtube ? userInfo.personalDetails.youtube : '',
    facebook: userInfo.personalDetails.facebook ? userInfo.personalDetails.facebook : '',
    reddit: userInfo.personalDetails.reddit ? userInfo.personalDetails.reddit : '',
    linkedIn: userInfo.personalDetails.linkedIn ? userInfo.personalDetails.linkedIn : '',
    notifyMe: userInfo.personalDetails.notifyMe ? userInfo.personalDetails.notifyMe : false,
    translation: userInfo.personalDetails.translation ? userInfo.personalDetails.translation : '',
    signature: userInfo.personalDetails.signature ? userInfo.personalDetails.signature : '',
    loginAlert: userInfo.personalDetails.loginAlert ? userInfo.personalDetails.loginAlert : '',
    imageProfile: userInfo.personalDetails.imageProfile ? userInfo.personalDetails.imageProfile : '',
    tokens: userInfo.tokens,
    status: !!status ? status : '',
    amountPercent: !!amountPercent ? amountPercent : 0,
    referral: {
      code : userInfo.refer.code,
      success: userInfo.refer.success,
      pending: userInfo.refer.totalUsed - userInfo.refer.success
    },
    // isVoted : userInfo.refer.voted,
    kycStatus : userInfo.kycStatus,
    is2FAEnabled : userInfo.local['2FA'].isEnabled,
    kycDetails : userInfo.kycDetails,
    isBlocked: userInfo.isBlocked,
    isWhitelisted: userInfo.isWhitelisted,
    accountVerify: userInfo.accountVerify,
    saveActivityLogs: userInfo.saveActivityLogs,
    isInfoActive: userInfo.isInfoActive
  };
  res.status(200).json({ success:true,useInfo : resObj });
};


let getTokenCount = (userId) => { // eslint-disable-line

};

module.exports = profileController;
