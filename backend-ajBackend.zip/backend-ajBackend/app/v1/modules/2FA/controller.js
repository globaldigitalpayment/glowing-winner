const speakeasy = require('speakeasy'),
  userModelFunction = require('../user/doa'),
  QRCode = require('qrcode'),
  { add2FAEnableLog, add2FADisableLog, add2FAVerifyLog } = require('./../logs/controller'),
  constants = require('config/constants');

const responseMsgs = constants.responseMsgs;

function getSecretKey(userId) { // eslint-disable-line no-unused-vars
  const secret = speakeasy.generateSecret({
    name: 'bytus.io'
  });

  // store in temp user

  return secret;
}

function genQrCodeDataImageData(data) {
  return new Promise((resolve, reject) => { // eslint-disable-line no-unused-vars
    QRCode.toDataURL(data, (err, data_url) => {
      //console.log(data_url);
      resolve(data_url);
      //write('<img src="' + data_url + '">');
    });
  });
}

function verifyToken({
  userToken,
  base32secret
}) {
  return speakeasy.totp.verify({
    secret: base32secret,
    encoding: 'base32',
    token: userToken,
    window: 2
  });
}


let controller = Object.create(null);

controller.disble2fa =async (req,res,next)=>{
  let userId = req.user.id;
  let query = { _id:userId },
    params = { 'local.2FA.secretKey':'','local.2FA.isEnabled':false };
  try {
    let result = await userModelFunction.findOneAndUpdate({ query,params }); // eslint-disable-line no-unused-vars
  } catch (error) {
    next(error);
  }
  if(!!req.user.saveActivityLogs) {
    var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
      req.connection.remoteAddress ||
      req.socket.remoteAddress ||
      req.connection.socket.remoteAddress;
    let date = new Date();
    date = date.toISOString();
    add2FADisableLog({ _id: req.user._id, email: req.user.email.value, responseMessage: responseMsgs['2FA'].SUCCESS_DISABLE, submittedAt: date, ip: ip })
      .then(data => {
        console.log('Successfully store log', data);
      })
      .catch(err => {
        logger.error('add2FADisableLog is unable to store log');
      });
  }
  res.status(200).json({ success:true,message : responseMsgs['2FA'].SUCCESS_DISABLE });

};

controller.init2FA = async (req,res,next)=>{
  let userId = req.user.id;
  //var secret = speakeasy.generateSecret();
  let secret = getSecretKey(userId);
  try {
    var qrCodeImageData = await genQrCodeDataImageData(secret.otpauth_url); // eslint-disable-line no-var
    let query = { _id:userId },
      params = { 'local.2FA.secretKey':secret.base32,'local.2FA.isEnabled':false };
    let result = await userModelFunction.findOneAndUpdate({ query,params }); // eslint-disable-line no-unused-vars
  } catch (error) {
    next(error);
  }
  if(!!req.user.saveActivityLogs) {
    var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
       req.connection.remoteAddress ||
       req.socket.remoteAddress ||
       req.connection.socket.remoteAddress;
    let date = new Date();
    date = date.toISOString();
    add2FAEnableLog({ _id: req.user._id, email: req.user.email.value, qrCode:qrCodeImageData, secretCode:secret.otpauth_url, submittedAt: date, ip: ip })
      .then(data => {
        console.log('Successfully store log', data);
      })
      .catch(err => {
        logger.error('add2FAEnableLog is unable to store log');
      });
  }
  res.status(200).json({ success:true,qrCode:qrCodeImageData, secretCode:secret.otpauth_url });
};

controller.verifySetupCode =async (req,res,next)=>{

  let userId = req.user.id;
  let base32secret = req.user.local['2FA'].secretKey;
  let userToken = req.body['2faToken'];
  if(verifyToken({ userToken,base32secret })) {
    // Let it go !
    //return res.status(200).json({success:true,message:'2FA set-up successfull'});
  } else {
    return res.status(200).json({ success:false,message:responseMsgs['2FA'].INVALID_VER_CODE });
  }
  try {
    let query = { _id:userId },
      params = { 'local.2FA.isEnabled':true };
    let result = await userModelFunction.findOneAndUpdate({ query,params }); // eslint-disable-line no-unused-vars
  } catch (error) {
    next(error);
  }
  if(!!req.user.saveActivityLogs) {
    var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
      req.connection.remoteAddress ||
      req.socket.remoteAddress ||
      req.connection.socket.remoteAddress;
    let date = new Date();
    date = date.toISOString();
    add2FAVerifyLog({ _id: req.user._id, email: req.user.email.value, submittedAt: date, ip: ip })
      .then(data => {
        console.log('Successfully store log', data);
      })
      .catch(err => {
        logger.error('add2FAVerifyLog is unable to store log');
      });
  }
  return res.status(200).json({ success:true,message:responseMsgs['2FA'].SUCCESS_ENABLE });
};

controller.check2FA = (req,res,next)=>{
  let userId = req.user.id; // eslint-disable-line no-unused-vars

  if (req.user.local['2FA'].isEnabled) {
    req.is2FA_enabled = true;
    req.is2FA_valid = false;
    let userToken = req.body.otpToken;
    let base32secret = req.user.local['2FA'].secretKey;

    if (!userToken || userToken === '') {
      req.is2FA_provided = false;
      next();
    } else {
      req.is2FA_provided = true;
      if(verifyToken({ userToken,base32secret })) {
        req.is2FA_valid = true;
        next();
      } else {
        req.is2FA_valid = false;
        next();
      }
    }
  } else {
    req.is2FA_enabled = false;
    next();
  }

};

module.exports = controller;
