const { Joi } = require('celebrate');

module.exports = {
  setup: {
    body: Joi.object().keys({
      '2faToken': Joi.number().required()
    })
  }
};
