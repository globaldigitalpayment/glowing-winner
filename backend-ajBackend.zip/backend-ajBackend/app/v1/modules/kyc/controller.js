const Boom = require('boom'),
  { addSubmitKycDetailsLog, addUploadKycDocLog } = require('./../logs/controller'),
  userModelFunction = require('app/v1/modules/user/doa');

const controller = Object.create(null);

controller.checkStatus = async (req, res, next) => {
  const userId = req.user.id;
  let query = { _id : req.user.id };
  try {
    let userInfo = await userModelFunction.findById({ id: userId, projection: 'kycStatus' });
    if (!userInfo) {
      res.status(200).json({ success: false, message: 'User Not found in system' });
    }
    else if(userInfo.kycStatus === 'SUBMITTED') {
      res.status(200).json({ success: false, message: 'You have already submitted your details for approval.' });
    }
    else if(userInfo.kycStatus === 'ACCEPTED') {
      res.status(200).json({ success: false, message: 'Your details are already approved.' });
    }
    else{
      next();
    }
  } catch (error) {
    next(Boom.badImplementation(error));
  }
};

controller.submitKycDetails = async (req, res, next) => {
  const user = req.user;
  let query = { _id : user.id };

  let params = {
    $set: {
      'personalDetails.fullName' : req.body.fullName,
      'personalDetails.gender' : req.body.gender,
      'personalDetails.dob' : req.body.dob,
      'personalDetails.phoneNumber' : req.body.phoneNumber,
      'personalDetails.ethAddress' : req.body.ethAddress,
      'kycDetails.citizenship' : req.body.citizenship,
      'kycDetails.country' : req.body.country,
      'kycDetails.state' : req.body.state,
      'kycDetails.city' : req.body.city,
      'kycDetails.address' : req.body.address,
      'kycDetails.address2' : req.body.address2,
      'kycDetails.documentType' : req.body.documentType,
      'kycDetails.documentNumber' : req.body.documentNumber,
      'kycStatus' : 'SUBMITTED'
    },
    $inc: {
      'kycDetails.kycAttempt' : 1
    }
  };
  try {
    const result = await userModelFunction.findOneAndUpdate({ params, query });
    if(result) {
      if(!!req.user.saveActivityLogs) {
        var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
         req.connection.remoteAddress ||
         req.socket.remoteAddress ||
         req.connection.socket.remoteAddress;
        let date = new Date();
        date = date.toISOString();
        addSubmitKycDetailsLog({ _id: req.user._id, email: req.user.email.value, submittedAt: date, ip: ip })
          .then(data => {
            console.log('Successfully store log', data);
          })
          .catch(err => {
            logger.error('addSubmitKycDetailsLog is unable to store log');
          });
      }
      res.status(200).json({ success : true, message: 'KYC Details sent for Approval.' });
    }
  }
  catch(err) {
    next(Boom.badImplementation(err));
  }
};

controller.uploadKycDoc = async(req, res, next) => {
  const user = req.user;
  let query = { _id : user.id };

  let image = req.files[0];
  //console.log(image);

  let key = 'kycDetails.extraDocs';
  let imageKey = `kycDetails.${image.fieldname}`;
  let statusKey = 'kycStatus';
  let params;
  if(image.fieldname === 'extraDoc') {
    params = {
      $push: {
        [key] : image.location
      },
      $set:{
        [statusKey]: 'SUBMITTED'
      }
    };
  } else{
    params = {
      $set: {
        [imageKey] : image.location
      }
    };
  }
  try {
    let result = await userModelFunction.findOneAndUpdate({ params, query });
    if(!result.kycDetails.imageFront || !result.kycDetails.selfie || !result.kycDetails.residentProof) {
      if(!!req.user.saveActivityLogs) {
        var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
          req.connection.remoteAddress ||
          req.socket.remoteAddress ||
          req.connection.socket.remoteAddress;
        let date = new Date();
        date = date.toISOString();
        addUploadKycDocLog({ _id: req.user._id, email: req.user.email.value, imageUri: image.location, submittedAt: date, ip })
          .then(data => {
            console.log('Successfully store log', data);
          })
          .catch(err => {
            logger.error('addUploadKycDocLog is unable to store log');
          });
      }
      res.status(200).json({ success : true , allUploaded : false, image: image.fieldname, imageUrl: image.location });
    }else{
      if(!!req.user.saveActivityLogs) {
        var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
          req.connection.remoteAddress ||
          req.socket.remoteAddress ||
          req.connection.socket.remoteAddress;
        let date = new Date();
        date = date.toISOString();
        addUploadKycDocLog({ _id: req.user._id, email: req.user.email.value, imageUri: image.location, submittedAt: date, ip: ip })
          .then(data => {
            console.log('Successfully store log', data);
          })
          .catch(err => {
            logger.error('addUploadKycDocLog is unable to store log');
          });
      }
      res.status(200).json({ success : true , allUploaded : true, image: image.fieldname, imageUrl: image.location });
    }
  } catch(err) {
    next(Boom.badImplementation(err));
  }
};

// controller.uploadKycDocs = async (req, res, next) => {
//     var user = req.user;
//     let query = { _id : user.id };

//     let imageFront = helper.findElementWithProp({array : req.files, prop: 'fieldname', value : 'imageFront'})
//     let imageBack = helper.findElementWithProp({array : req.files, prop: 'fieldname', value : 'imageBack'})
//     let imageSelfie = helper.findElementWithProp({array : req.files, prop: 'fieldname', value : 'imageSelfie'})

//     if(!imageFront){
//         res.status(200).json({success: false, message: 'Please upload front image of proof document.'})
//     }
//     if(!imageBack){
//         res.status(200).json({success: false, message: 'Please upload back image of proof document.'})
//     }
//     if(!imageSelfie){
//         res.status(200).json({success: false, message: 'Please upload selfie with your proof document.'})
//     }

//     let kycDocuments = {
//         imageFront : imageFront.location,
//         imageBack : imageBack.location,
//         imageSelfie : imageSelfie.location
//     }

//     let params = {
//         $push: {
//             'kycDetails.documents' : kycDocuments
//         }
//     }
//     try {
//         var result = await userModelFunction.findOneAndUpdate({ params, query });
//     }
//     catch(err){
//         next(Boom.badImplementation(error))
//     }
//     res.status(200).json({ success : true, message: "KYC Documents sent for Approval." })

// }

module.exports = controller;
