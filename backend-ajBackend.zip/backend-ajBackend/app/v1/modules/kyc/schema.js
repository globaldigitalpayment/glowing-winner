const { Joi } = require('celebrate');

module.exports = {
  submitKycDetails: {
    body : Joi.object().keys({   
      fullName: Joi.string().required(),
      dob: Joi.string().required(),
      gender: Joi.any().valid('MALE', 'FEMALE', 'DECLINE TO STATE').required(),
      phoneNumber: Joi.string(),
      ethAddress: Joi.string().regex(/^0x[a-fA-F0-9]{40}$/).allow(''),
      citizenship : Joi.string().required(),
      country : Joi.string().required(),
      state : Joi.string().required(),
      city : Joi.string().required(),
      address : Joi.string().required(),
      address2 : Joi.string().allow(''),
      documentType : Joi.string().required(),
      documentNumber : Joi.string().required()
    })
  },
  submitKycDocs: {
    body: Joi.object().keys({
      imageFront: Joi.any(),
      imageBack: Joi.any(),
      residentProof: Joi.any(),
      selfie: Joi.any(),
      extraDoc: Joi.any()
    })
  }

};
