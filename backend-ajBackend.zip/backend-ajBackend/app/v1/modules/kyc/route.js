const multer = require('multer'),
  multerS3 = require('multer-s3'),
  s3 = require('app/v1/config/s3'),
  passport = require('passport'),
  { celebrate } = require('celebrate'),
  controller = require('./controller');

const validateSchema = require('./schema');

const kycMulter = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'zineum-ico-kyc',
    acl: 'public-read',
    metadata: function (req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function (req, file, cb) {
      const originalName = file.originalname.split('.');
      const ext = `.${originalName[originalName.length - 1]}`;
      cb(null,originalName + Date.now().toString() + ext);
    }
  })
});

const kycUpload = kycMulter.any();

module.exports = function (router) {
/**
	* @swagger
	* /user/kycDetails:
	*  patch:
	*   description: Submit kyc details of user
	*   tags:
	*    - Kyc
	*   produces:
	*    - application/json
	*   parameters:
	*    - name: x-auth-token
	*      in: header
	*      schema:
	*       type: string
	*      required: true
	*      description: Token obtained on login by admin
	*    - name: fullName
	*      in: body
	*      schema:
	*       type: string
	*      required: true
	*      description: full Name
	*    - name: dob
	*      in: body
	*      schema:
	*       type: string
	*      required: true
	*      description: date of birth
	*    - name: phoneNumber
	*      in: body
	*      schema:
	*       type: string
	*      required: true
	*      description: phone number
	*    - name: citizenship
	*      in: body
	*      schema:
	*       type: string
	*      required: true
	*      description: citizenship
	*    - name: country
	*      in: body
	*      schema:
	*       type: string
	*      required: true
	*      description: country
	*    - name: state
	*      in: body
	*      schema:
	*       type: string
	*      required: true
	*      description: state
	*    - name: city
	*      in: body
	*      schema:
	*       type: string
	*      required: true
	*      description: city
	*    - name: address
	*      in: body
	*      schema:
	*       type: string
	*      required: true
	*      description: address
	*    - name: address2
	*      in: body
	*      schema:
	*       type: string
	*      required: false
	*      description: address line 2
	*    - name: documentType
	*      in: body
	*      schema:
	*       type: string
	*      required: true
	*      description: Document Type
	*    - name: documentNumber
	*      in: body
	*      schema:
	*       type: string
	*      required: true
	*      description: document number
	*   responses:
	*    200:
	*     description: success message
	*/
  router.patch('/user/kycDetails', celebrate(validateSchema.submitKycDetails), passport.authenticate('jwt', {
  	session: false
  }), controller.checkStatus, controller.submitKycDetails);

  // router.patch('/user/kycUpload', passport.authenticate('jwt', { session: false }), kycUpload, celebrate(validateSchema.submitKycDocs), controller.checkStatus, controller.uploadKycDocs);

  /**
	* @swagger
	* /user/kycDocs:
	*  patch:
	*   description: Upload kyc documents
	*   tags:
	*    - Kyc
	*   produces:
	*    - application/json
	*   parameters:
	*    - name: x-auth-token
	*      in: header
	*      schema:
	*       type: string
	*      required: true
	*      description: Token obtained on login by admin
	*    - name: imageFront or imageBack or imageSelfie
	*      in: formData
	*      schema:
	*       type: image
	*      required: true
	*      description: KYC document for uploading
	*   responses:
	*    200:
	*     description: success message and allUploaded check
	*/

  router.patch('/user/kycDocs', passport.authenticate('jwt', { session: false }), kycUpload, controller.uploadKycDoc);
};
