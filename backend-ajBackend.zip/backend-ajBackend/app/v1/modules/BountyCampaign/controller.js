const modelFunction = require('./doa'),
  participationBCModelFunction = require('../BountyParticipants/doa'),
  userModelFunction = require('../user/doa'),
  mongoose = require('mongoose'),
  // BountyModel = require('./model'),
  bountyCampaignController = Object.create(null);

bountyCampaignController.getBountiesAdmin = async (req, res, next) => {
  try{
    const dataFind = {};
    const bountyFind = await modelFunction.find({
      params: dataFind,
      query: ['bountyParticipations']
    });
    if(bountyFind.length === 0) {
      return res
        .status(200)
        .json({
          success: true,
          data: [],
          message: 'No bounty exists'
        });
    }else {
      return res
        .status(200)
        .json({
          success: true,
          data: bountyFind,
          message: 'Successfully retrieved all bounty campaigns'
        });
    }
  }catch(err) {
    next(err);
  }
}

bountyCampaignController.createBounty = async (req, res, next) => {
  const dataF = {
    'basicInfo.campaignType': req.body.campaignType
  };
  try {
    const bountyFind = await modelFunction.findOne({
      params: dataF
    });
    if(!!bountyFind) {
      // Bounty with this name already exists
      return res
        .status(200)
        .json({
          success: false,
          message: `Bounty with campaign type ${req.body.campaignType} already exists`
        });
    }else {
      //Creating a new bounty
      const dataAdd = {
        basicInfo: {
          username: req.body.username,
          name: req.body.name,
          desc: req.body.desc,
          campaignType: req.body.campaignType,
          rules: req.body.rules
        },
        rewardBounty: req.body.rewardBounty,
        maxUsersAllowed: req.body.maxUsersAllowed,
        submitProof: req.body.submitProof,
        active: req.body.active,
        startDate: req.body.startDate,
        endDate: req.body.endDate
      };
      console.log('dataAdd : ', dataAdd);
      const bountyResult = await modelFunction.create({
        obj: dataAdd
      });
      return res
        .status(200)
        .json({
          success: true,
          message: 'Bounty Campaign successfully created',
          data: dataAdd
        });
    }
  }catch(err) {
    next(err);
  }
};

bountyCampaignController.getBounties = async (req, res, next) => {
  try{
    const dataF = {};
    const bountyFind = await modelFunction.find({ params: dataF });
    if(bountyFind.length === 0) {
      // No bounty exists
      return res
        .status(200)
        .json({
          success: true,
          data: [],
          message: 'No bounty exists'
        });
    }else {
      // Bounty exists
      return res
        .status(200)
        .json({
          success: true,
          data: bountyFind,
          message: 'Successfully retrieved all bounty campaigns'
        });
    }
  }catch(err) {
    next(err);
  }
};

bountyCampaignController.getBounty = async (req, res, next) => {
  try{
    const dataF = {
      _id: req.params._id
    };
    const bountyFind = await modelFunction.find({ params: dataF });
    if(bountyFind.length === 0) {
      // No bounty exists
      return res
        .status(200)
        .json({
          success: false,
          message: 'No bounty campaign exists'
        });
    }else {
      // Bounty exists
      return res
        .status(200)
        .json({
          success: true,
          data: bountyFind,
          message: 'Successfully retrieved bounty campaign'
        });
    }
  }catch(err) {
    next(err);
  }
};

bountyCampaignController.editBounty = async (req, res, next) => {
  try {

    const bountyDataFindById = await modelFunction.findById({
      id: req.params.campaignId
    });

    if(!!bountyDataFindById) {
      // console.log('bountyDataFindById : ', bountyDataFindById);

      const bountyDataFindByCampaignType = await modelFunction.findOne({
        params: {
          'basicInfo.campaignType': req.body.campaignType
        }
      });


      if(!!bountyDataFindByCampaignType && !(bountyDataFindByCampaignType._id.equals(bountyDataFindById._id))) {
        // console.log('bountyDataFindByCampaignType : ', bountyDataFindByCampaignType);
        console.log('Find Id : ', bountyDataFindById._id);
        console.log('typeof : ', typeof(bountyDataFindById._id));
        console.log('Find campaignType : ', bountyDataFindByCampaignType._id);
        console.log('typeof : ', typeof (bountyDataFindByCampaignType._id));
        console.log(bountyDataFindByCampaignType._id.equals(bountyDataFindById._id), ' true ???????');
        console.log('already exists');
        return res
          .status(200)
          .json({
            success: false,
            message: `campaign type ${req.body.campaignType} already exists`
          });
      } else {
        console.log('Change');
        const dataUpdate = {
          basicInfo: {
            username: req.body.username,
            name: req.body.name,
            desc: req.body.desc,
            campaignType: req.body.campaignType,
            rules: req.body.rules
          },
          rewardBounty: req.body.rewardBounty,
          maxUsersAllowed: req.body.maxUsersAllowed,
          submitProof: req.body.submitProof,
          active: req.body.active,
          startDate: req.body.startDate,
          endDate: req.body.endDate
        };

        const bountyUpdateData = await modelFunction.findByIdAndUpdate({
          id: req.params.campaignId,
          data: dataUpdate
        });
        if(!!bountyUpdateData) {
          // Bounty exists
          return res
            .status(200)
            .json({
              success: true,
              message: 'Successfully updated bounty campaign data'
            });
        }
      }
    } else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'Invalid data'
        });
    }
  } catch(err) {
    next(err);
  }
};

// delete bounty along with all participation
bountyCampaignController.deleteBounty = async (req, res, next) => {
  try{
    const bountyDelete = await modelFunction.deleteCampaign({
      _id: req.params.campaignId
    });
    console.log('bountyDelete : ', bountyDelete);
    if(!!bountyDelete) {
      // Bounty deleted
      //Deleting participation data
      const participtionDelete = await participationBCModelFunction.deleteSoft({
        params: { bountyCampaignId: req.params.campaignId }
      });
      console.log('participtionDelete : ', participtionDelete);
      return res
        .status(200)
        .json({
          success: true,
          message: 'Successfully deleted bounty campaign data'
        });
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'No such bounty campaign exists'
        });
    }
  }catch(err) {
    next(err);
  }
};

// delete only those bounty with no participation
// bountyCampaignController.deleteBounty = async (req, res, next) => {
//   try{
//     const findAnyBountyParticipation = await participationBCModelFunction.find({
//       params: { bountyCampaignId: req.params.campaignId }
//     });
//
//     if(findAnyBountyParticipation.length > 0) {
//       // User have participated in this bounty campaign
//       return res
//         .status(200)
//         .json({
//           success: false,
//           message: 'Users have participated in this bounty campaign'
//         });
//     }else {
//       const bountyDelete = await modelFunction.deleteCampaign({
//         _id: req.params.campaignId
//       });
//       console.log('bountyDelete : ', bountyDelete);
//       if(!!bountyDelete) {
//         return res
//           .status(200)
//           .json({
//             success: true,
//             message: 'Successfully deleted bounty campaign data'
//           });
//       }else {
//         return res
//           .status(200)
//           .json({
//             success: false,
//             message: 'No such bounty campaign exists'
//           });
//       }
//     }
//   }catch(err) {
//     next(err);
//   }
// };

module.exports = bountyCampaignController;
