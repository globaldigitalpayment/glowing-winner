const { Joi } = require('celebrate');

module.exports = {
  createBounty: {
    body: Joi.object().keys({
      username: Joi.string().required(),
      name: Joi.string().required(),
      desc: Joi.string().required(),
      campaignType: Joi.string().valid('facebook', 'twitter', 'creative', 'youtube', 'translation', 'reddit', 'telegram', 'signature', 'linkedIn', 'medium', 'steemit').required(),
      rules: Joi.string().required(),
      startDate: Joi.date().required(),
      endDate: Joi.date().required(),
      rewardBounty: Joi.number().required(),
      maxUsersAllowed: Joi.number().required(),
      active: Joi.boolean().required(),
      submitProof: Joi.string().valid('imageUri', 'url').required(),
    })
  },
  editBounty: {
    body: Joi.object().keys({
      username: Joi.string().required(),
      name: Joi.string().required(),
      desc: Joi.string().required(),
      campaignType: Joi.string().valid('facebook', 'twitter', 'creative', 'youtube', 'translation', 'reddit', 'telegram', 'signature', 'linkedIn', 'medium', 'steemit').required(),
      rules: Joi.string().required(),
      startDate: Joi.date().required(),
      endDate: Joi.date().required(),
      rewardBounty: Joi.number().required(),
      maxUsersAllowed: Joi.number().required(),
      active: Joi.boolean().required(),
      submitProof: Joi.string().valid('imageUri', 'url').required(),
    })
  },
  getBounty: {
    params: Joi.object().keys({
      _id: Joi.string().required()
    })
  }
};
