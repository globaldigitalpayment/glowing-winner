const mongoose = require('mongoose');

const bountyCampaignSchema = new mongoose.Schema({
  basicInfo: {
    username: {
      type: String,
      required: true
    },
    name: {
      type: String,
      required: true
    },
    desc: {
      type: String,
      required: true
    },
    rules: {
      type: String,
      required: true
    },
    campaignType: {
      type: String,
      enum: ['facebook', 'twitter', 'creative', 'youtube', 'translation', 'reddit', 'telegram', 'signature', 'linkedIn', 'medium', 'steemit'],
      required: true
    }
  },
  rewardBounty: {
    type: Number,
    required: true
  },
  maxUsersAllowed: {
    type: Number,
    required: true
  },
  submitProof: {
    type: String,
    enum: ['imageUri', 'url'],
    required: true
  },
  active: {
    type: Boolean,
    required: true
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  bountyParticipations: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'BountyParticipants'
    }
  ]

});

const BountyCampaign = mongoose.model('BountyCampaign', bountyCampaignSchema);


module.exports = BountyCampaign;
