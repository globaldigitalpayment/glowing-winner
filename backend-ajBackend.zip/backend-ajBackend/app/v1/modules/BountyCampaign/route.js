const controller = require('./controller'),
  { celebrate } = require('celebrate'),
  moment = require('moment'),
  modelFunction = require('./doa');

const authenticate = require('./../../config/authenticate');
const validateSchema = require('./schema');

const checkIfAdminOrSuperAdmin = (req, res, next) => {
//   console.log(req.user);
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};


module.exports = function (router) {

  /**
  * @swagger
  * /admin/bountyCampaign:
  *   post:
  *     description: contact us
  *     tags:
  *       - Bounty
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: x-auth-token
  *         in: header
  *         schema:
  *           type: string
  *         required: true
  *         description: Token obtained on login
  *       - name: username
  *         in: body
  *         schema:
  *           type: string
  *         required: true
  *         description: username
  *       - name: name
  *         in: body
  *         schema:
  *           type: string
  *         required: true
  *         description: name
  *       - name: desc
  *         in: body
  *         schema:
  *           type: string
  *         required: true
  *         description: description
  *       - name: campaignType
  *         in: body
  *         schema:
  *           type: string
  *         required: true
  *         description: campaign type, valid facebook, twitter, creative, youtube, translation, reddit, telegram, signature, linkedIn, medium, steemit
  *       - name: rules
  *         in: body
  *         schema:
  *           type: string
  *         required: true
  *         description: rules
  *       - name: startDate
  *         in: body
  *         schema:
  *           type: date
  *         required: true
  *         description: start date
  *       - name: endDate
  *         in: body
  *         schema:
  *           type: date
  *         required: true
  *         description: end date
  *       - name: rewardBounty
  *         in: body
  *         schema:
  *           type: number
  *         required: true
  *         description: reward Bounty given to users
  *       - name: maxUsersAllowed
  *         in: body
  *         schema:
  *           type: number
  *         required: true
  *         description: max users allowed to participate in bounty
  *       - name: active
  *         in: body
  *         schema:
  *           type: boolean
  *         required: true
  *         description: bounty active or not
  *       - name: submitProof
  *         in: body
  *         schema:
  *           type: string
  *         required: true
  *         description: submit proof, valid imageUri or url
  *     responses:
  *       200:
  *        	description: Success message
  */
  router
    .post(
      '/admin/bountyCampaign',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.createBounty),
      controller.createBounty
    );

    /**
    * @swagger
    * /bountyCampaigns:
    *   get:
    *     description: get all bounties
    *     tags:
    *       - Bounty
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/bountyCampaigns',
      // authenticate,
      controller.getBounties
    );

    /**
    * @swagger
    * /admin/bountyCampaigns:
    *   get:
    *     description: get all bounties admin specific
    *     tags:
    *       - Bounty
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: header
    *         schema:
    *           type: string
    *         required: true
    *         description: Token obtained on login
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/admin/bountyCampaigns',
      authenticate,
      checkIfAdminOrSuperAdmin,
      controller.getBountiesAdmin
    );

    /**
    * @swagger
    * /bountyCampaign/:_id:
    *   get:
    *     description: get a specific bounties
    *     tags:
    *       - Bounty
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: _id
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: bounty id
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/bountyCampaign/:_id',
      // authenticate,
      celebrate(validateSchema.getBounty),
      controller.getBounty
    );

    /**
    * @swagger
    * /admin/bountyCampaign/:campaignId:
    *   put:
    *     description: update a specific bounty
    *     tags:
    *       - Bounty
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: header
    *         schema:
    *           type: string
    *         required: true
    *         description: Token obtained on login
    *       - name: campaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: campaignId of the bounty to update
    *       - name: username
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: username
    *       - name: name
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: name
    *       - name: desc
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: description
    *       - name: campaignType
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: campaign type, valid facebook, twitter, creative, youtube, translation, reddit, telegram, signature, linkedIn, medium, steemit
    *       - name: rules
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: rules
    *       - name: startDate
    *         in: body
    *         schema:
    *           type: date
    *         required: true
    *         description: start date
    *       - name: endDate
    *         in: body
    *         schema:
    *           type: date
    *         required: true
    *         description: end date
    *       - name: rewardBounty
    *         in: body
    *         schema:
    *           type: number
    *         required: true
    *         description: reward Bounty given to users
    *       - name: maxUsersAllowed
    *         in: body
    *         schema:
    *           type: number
    *         required: true
    *         description: max users allowed to participate in bounty
    *       - name: active
    *         in: body
    *         schema:
    *           type: boolean
    *         required: true
    *         description: bounty active or not
    *       - name: submitProof
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: submit proof, valid imageUri or url
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .put(
      '/admin/bountyCampaign/:campaignId',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.editBounty),
      controller.editBounty
    );

    /**
    * @swagger
    * /bountyCampaign/:campaignId:
    *   delete:
    *     description: delete a specific bounty
    *     tags:
    *       - Bounty
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: header
    *         schema:
    *           type: string
    *         required: true
    *         description: Token obtained on login
    *       - name: campaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: campaignId of the bounty to delete
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .delete(
      '/bountyCampaign/:campaignId',
      authenticate,
      checkIfAdminOrSuperAdmin,
      controller.deleteBounty
    );

};
