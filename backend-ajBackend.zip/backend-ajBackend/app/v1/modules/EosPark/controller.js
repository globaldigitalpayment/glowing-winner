const modelFunction = require('./doa'),
  mailer = require('config/nodemailer'),
  mongoose = require('mongoose');

const crypto = require('crypto');
const publicKey = 'MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAL9VY0l1HslYotp4hgXvSuZIzQFSi7w47K0LZPlCtI4Q2EL8L1rL9nhGlbizDhkjtjY7UE1tuNWgG7YhuvcM3Z8CAwEAAQ=='
// const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
//   modulusLength: 2048,
// });

// const sign = crypto.createSign('SHA256');
// sign.update('some data to sign');
// sign.end();
// const signature = sign.sign(privateKey);
// console.log('signature : ', signature);


const controller = Object.create(null);

controller.pushToVendor = async (req, res, next) => {
  console.log('req : ', req.body);

  try {
    
    const pushToVendorParams = {};

    pushToVendorParams.random = req.body.random;
    pushToVendorParams.sign = req.body.sign;


    // const verify = crypto.createVerify('SHA256');
    // verify.update(random);
    // verify.end();
    // console.log(verify.verify(publicKey, sign));

    pushToVendorParams.audit_id = req.body.audit_id;

    pushToVendorParams.contract = [];
    pushToVendorParams.contract[0] = {};

    pushToVendorParams.contract[0].contract_name = req.body.contract[0].contract_name;
    pushToVendorParams.contract[0].developer_email = req.body.contract[0].developer_email;
    if(!! req.body.developer_name) {
      pushToVendorParams.contract[0].developer_name = req.body.contract[0].developer_name;
    }
    if(!! req.body.developer_phone) {
      pushToVendorParams.contract[0].developer_phone = req.body.contract[0].developer_phone;
    }
    pushToVendorParams.contract[0].contract_hash = req.body.contract[0].contract_hash;
    pushToVendorParams.contract[0].compiler_version = req.body.contract[0].compiler_version;
    pushToVendorParams.contract[0].compile_os = req.body.contract[0].compile_os;
    pushToVendorParams.contract[0].chain_name = req.body.contract[0].chain_name;
    pushToVendorParams.contract[0].network_type = req.body.contract[0].network_type;
    pushToVendorParams.contract[0].contract_zip = req.body.contract[0].contract_zip;

    console.log('pushToVendor params : ', pushToVendorParams);

    // const verify = crypto.createVerify('SHA256');
    // verify.update(req.body.random);
    // verify.end();
    // const isValid = verify.verify(publicKey, req.body.sign);
    //@TODO: replace later
    if(!! true) {
      const dataAdd = await modelFunction.create({
        obj: {
          pushToVendor: pushToVendorParams
        }
      });
      mailer({ mailType: 'PUSH_TO_VENDOR', to: 'hello@quillhash.com', data: { pushToVendorParams: pushToVendorParams } });

      return res
        .status(200)
        .json({
          ret: 0,
          success: true,
          message: 'Stored in database and send to hello@quillhash.com'
        });
    } else {
      return res
        .status(401)
        .json({
          ret: 0,
          success: false,
          message: 'Verification false'
        });
    }

  }catch(err) {
    next(err);
  }
}

module.exports = controller;
