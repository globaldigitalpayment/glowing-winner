const crypto = require('crypto');
const publicKey = 'MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAL9VY0l1HslYotp4hgXvSuZIzQFSi7w47K0LZPlCtI4Q2EL8L1rL9nhGlbizDhkjtjY7UE1tuNWgG7YhuvcM3Z8CAwEAAQ=='
const random = '5d41402abc4b2a76b9719d911017c592'
const sign = 'RW5RlEYCpkimJMFcNq4La+ZXn0KpDpVPSkM2gbp7DcfKKsu++XlDWw26WY2g2sJDT81nYPeCGW3iqS1ivYUa3w=='
const verify = crypto.createVerify('SHA256');
    verify.update(random);
    verify.end();
    console.log(verify.verify(publicKey, sign));
