const controller = require('./controller'),
  { celebrate } = require('celebrate');

const authenticate = require('./../../config/authenticate');
const validateSchema = require('./schema');

const checkIfAdminOrSuperAdmin = (req, res, next) => {
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};

module.exports = function (router) {

  // Push contract audit task to vendor
  router
    .post(
      '/audit/toVendors',
      celebrate(validateSchema.pushToVendor),
      controller.pushToVendor
    );

};
