const { Joi } = require('celebrate');

module.exports = {
  pushToVendor: {
    body: Joi.object().keys({
      random: Joi.string().trim().required(),
      sign: Joi.string().trim().required(),
      audit_id: Joi.string().required(),
      contract : Joi.array().items(
        Joi.object().keys({
          contract_name: Joi.string().required(),
          developer_email: Joi.string().email().required(),
          developer_name: Joi.string().allow("",'',null).optional(),
          developer_phone: Joi.string().allow("",'',null).optional(),
          contract_hash: Joi.string().required(),
          compiler_version: Joi.string().required(),
          compile_os: Joi.string().valid('Ubuntu','ubuntu', 'Darwin', 'darwin','Fedora','fedora','centos','CentOs','docker','Docker').required(),
          chain_name: Joi.string().valid('eos', 'eth').required(),
          network_type: Joi.string().valid('MainNet', 'Jungle').required(),
          contract_zip: Joi.string().required()
        })  
      ).required(),
      
    })
  }
};
