const mongoose = require('mongoose');

const eosParkSchema = new mongoose.Schema({
  pushToVendor: {
    random: {
      type: String,
      required: true
    },
    sign: {
      type: String,
      required: true
    },
    audit_id: {
      type: String,
      required: true
    },
    contract: [
      {
        contract_name: {
          type: String,
          required: true
        },
        developer_email: {
          type: String,
          required: true
        },
        developer_name: {
          type: String
        },
        developer_phone: {
          type: String
        },
        contract_hash: {
          type: String,
          required: true
        },
        compiler_version: {
          type: String,
          required: true
        },
        compile_os: {
          type: String,
          enum: ['Ubuntu','ubuntu', 'Darwin', 'darwin','Fedora','fedora','centos','CentOs','docker','Docker'],
          required: true
        },
        chain_name: {
          type: String,
          enum: ['eos', 'eth'],
          required: true
        },
        network_type: {
          type: String,
          enum: ['MainNet', 'Jungle'],
          required: true
        },
        contract_zip: {
          type: String,
          required: true
        }
      }
    ]
  }
});

const EosPark = mongoose.model('EosPark', eosParkSchema);


module.exports = EosPark;
