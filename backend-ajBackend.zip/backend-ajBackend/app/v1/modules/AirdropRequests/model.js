const mongoose = require('mongoose');

const airdropRequestSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  tokenAddress: {
    type: String,
    required: true
  },
  publicKey: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['Accepted', 'Rejected', 'Pending'],
    default: 'Pending'
  }
});

const AirdropRequest = mongoose.model('AirdropRequest', airdropRequestSchema);


module.exports = AirdropRequest;
