const { Joi } = require('celebrate');

module.exports = {
  requestAirdrop: {
    body: Joi.object().required().keys({
      tokenAddress: Joi.string().required(),
      publicKey: Joi.string().required()
    })
  },
  approveSubmission: {
    body: Joi.object().required().keys({
      tokenAddress: Joi.string().required()
    })
  },
  revokeSubmission: {
    body: Joi.object().required().keys({
      tokenAddress: Joi.string().required(),
      publicKey: Joi.string().required()
    })
  }
};
