const controller = require('./controller'),
  { celebrate } = require('celebrate'),
  modelFunction = require('./doa');

const authenticate = require('./../../config/authenticate');
const validateSchema = require('./schema');

const checkIfAdminOrSuperAdmin = (req, res, next) => {
//   console.log(req.user);
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};


module.exports = function (router) {

  /**
	 * @swagger
	 *   /admin/requestAirdrop:
	 *   post:
	 *     description: airdrop request
	 *     tags:
	 *       - Airdrop
	 *     produces:
	 *       - application/json
	 *     parameters:
	 *       - name: x-auth-token
	 *         in: header
	 *         type: string
	 *         required: true
	 *         description: Token obtained on login
	 *       - name: tokenAddress
	 *         description: token Address
	 *         in: body
	 *         type: string
	 *       - name: public key
	 *         description: public key
	 *         in: body
	 *         type: string
	 *
	 *     responses:
	 *       200:
	 *        	description: Successfully created contract'
	 */
  router
    .post(
      '/admin/requestAirdrop',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.requestAirdrop),
      controller.requestAirdrop
    );

    /**
     * @swagger
     *   /admin/requestAirdropList:
     *   get:
     *     description: requestAirdropList
     *     tags:
     *       - Airdrop
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: x-auth-token
     *         in: header
     *         type: string
     *         required: true
     *         description: Token obtained on login
     *     responses:
     *       200:
     *        	description: Successfully created contract'
     */
  router
    .get(
      '/admin/requestAirdropList',
      authenticate,
      checkIfAdminOrSuperAdmin,
      controller.requestAirdropList
    );

    /**
     * @swagger
     *  /admin/approveSubmission:
     *   post:
     *     description: approve Submission
     *     tags:
     *       - Airdrop
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: x-auth-token
     *         in: header
     *         type: string
     *         required: true
     *         description: Token obtained on login
     *       - name: tokenAddress
     *         in: body
     *         type: string
     *         required: true
     *         description: Token address
     *     responses:
     *       200:
     *        	description: Successfully created contract'
     */
  router
    .post(
      '/admin/approveSubmission',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.approveSubmission),
      controller.approveSubmission
    )

};
