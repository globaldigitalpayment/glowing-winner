const modelFunction = require('./doa'),
  contractModelFunction = require('./doaContracts'),
  mongoose = require('mongoose'),

  controller = Object.create(null);

const ethers = require('ethers');
const storage = require('node-persist');
const path = require('path');
const newFile = path.join(__dirname, '../../../../keyValueFile');
let Web3 = require('web3');

controller.approveSubmission = async (req, res, next) => {

  try {
    console.log('calling');

    const liveAirdropCentral = await contractModelFunction.findOne({
      params: {
        tokenType: 'airdropCentral',
        useInDashboard: 'true'
      }
    });

    console.log('liveAirdropCentral : ', liveAirdropCentral);

    const abiString = liveAirdropCentral.abi;
    

    // let abiArray, abiString;
    // fs.readFile(abiCentralFile, 'utf-8', async (err, buf) => {
    //   // console.log(buf.toString());
    //   abiString = buf.toString()
    //   abiArray = JSON.parse(abiString);
    //   console.log('abiArray : ', abiArray);
    //   console.log('abiArray isArray : ', Array.isArray(abiArray));
    //   let provider = ethers.getDefaultProvider('rinkeby');
    //   const privateKey = '461A28034CB63A30577326918B7DB0ACC52BF3748B5704BA5963E7F02E61CA9D';
    //   wallet = new ethers.Wallet(privateKey, provider);
    //   const tokenAddressCentral = '0x8597f9b78fb07d2d0a74ac5f9e4adbdcd9f700d2';
    //   console.log('tokenAddressCentral : ', tokenAddressCentral);
    //   const tokenAddress = req.body.tokenAddress;
    //   console.log('tokenAddress : ', tokenAddress);
    //   const crowdsaleContract = new ethers.Contract(tokenAddressCentral, abiArray, wallet);
    //   const airdropper = req.body.publicKey;
    //   console.log('airdropper : ', airdropper);
    //   try {
    //     const airdropApproval = await crowdsaleContract
    //       .deployNewAirDropContract(
    //         airdropper,
    //         tokenAddress
    //       );
    //     console.log('airdropApproval hash : => ', airdropApproval.hash);
    //
    //     const updateAirdropReqData = await modelFunction.findOneAndUpdate({
    //       query: {
    //         tokenAddress: tokenAddress,
    //         publicKey: airdropper
    //       },
    //       params: {
    //         $set: {
    //           status: 'Accepted'
    //         }
    //       }
    //     });
    //     console.log('updateAirdropReqData : ', updateAirdropReqData);
    //     if(!!updateAirdropReqData) {
    //       console.log('updateAirdropReqData : ', updateAirdropReqData);
    //       return res
    //         .status(200)
    //         .json({
    //           success: true,
    //           message: 'Updated'
    //         })
    //     } else {
    //       return res
    //         .status(200)
    //         .json({
    //           success: false,
    //           message: 'Invalid details'
    //         })
    //     }
    //
    //   } catch (err) {
    //     console.log('ERROR : ****** :', err);
    //     return res
    //       .status(200)
    //       .json({
    //         success: false,
    //         message: 'Invalid details'
    //       });
    //   }
    // });

  } catch(err) {
    next(err);
  }

}

controller.requestAirdrop = async (req, res, next) => {
  try{
    const dataAirDropReq = {};
    dataAirDropReq.tokenAddress = req.body.tokenAddress;
    dataAirDropReq.publicKey = req.body.publicKey;
    dataAirDropReq.userId = req.user._id;
    const createAirDropReq = await modelFunction.create({
      obj: dataAirDropReq
    });

    if(!! createAirDropReq) {
      return res
        .status(200)
        .json({
          success: true,
          message: 'Successfully received',
          data: dataAirDropReq
        });
    } else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'Unsuccessfully attempt'
        });
    }
  }catch(err) {
    next(err);
  }
}

controller.requestAirdropList = async (req, res, next) => {
  try {
    console.log('user data : ', req.user);
    const _id = req.user._id;
    const role = req.user.role;
    let getAirdropRequestData;
    if(role === 'SUPER_ADMIN') {
      getAirdropRequestData = await modelFunction.find({
        params: {}
      });
    } else {
      getAirdropRequestData = await modelFunction.find({
        params: { userId: req.user._id}
      });
    }
    if(!!getAirdropRequestData) {
      return res
        .status(200)
        .json({
          success: true,
          data: getAirdropRequestData,
          role: role
        });
    }
  }catch(err) {
    next(err);
  }
}

module.exports = controller;
