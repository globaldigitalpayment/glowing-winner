const mongoose = require('mongoose');

const airDropSchema = new mongoose.Schema({
  tokenAddress: {
    type: String,
    required: true
  },
  decimals: {
    type: Number,
    required: true
  },
  jsonData : {
    type: Object,
    required: true
  },
  privateKey: {
    type: String,
    required: true
  },
  transferredAt: {
    type: Date,
    default: new Date()
  }
});

const AirDrop = mongoose.model('AirDrop', airDropSchema);


module.exports = AirDrop;
