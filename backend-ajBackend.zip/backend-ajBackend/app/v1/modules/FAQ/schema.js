const { Joi } = require('celebrate');

module.exports = {
  faqImage: {
    body: Joi.object().keys({
      imageUri: Joi.any()
    })
  },
  createFaq: {
    body: Joi.object().keys({
      question: Joi.string().required(),
      answer: Joi.string().required(),
      imageUri: Joi.string()
    })
  },
  editFaq: {
    body: Joi.object().keys({
      answer: Joi.string().required(),
      question: Joi.string().required(),
      imageUri: Joi.string().required()
    }),
    params: Joi.object().keys({
      _id: Joi.string().required()
    })
  },
  deleteFaq: {
    params: Joi.object().keys({
      _id: Joi.string().required()
    })
  }
};
