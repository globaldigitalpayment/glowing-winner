const { celebrate } = require('celebrate'),
  controller = require('./controller'),
  multer = require('multer'),
  multerS3 = require('multer-s3'),
  s3 = require('app/v1/config/s3'),
  { removeQueryFalsy } = require('utils/helper');

const authenticate = require('./../../config/authenticate');
const validateSchema = require('./schema');

const imageMulter = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'zineum-ico-kyc',
    acl: 'public-read',
    metadata: function (req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function (req, file, cb) {
      const originalName = file.originalname.split('.');
      const ext = `.${originalName[originalName.length - 1]}`;
      cb(null,originalName + Date.now().toString() + ext);
    }
  })
});

const checkIfAdmin = (req, res, next) => {
  if (req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({ success: false, message: 'Invalid Access', description: '' });
  }
};

const checkIfAdminOrSuperAdmin = (req, res, next) => {
//   console.log(req.user);
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};


module.exports = function (router) {
    /**
       * @swagger
       *   /user/faq :
       *   get:
       *     description: get all faq
       *     tags:
       *       - FAQ
       *     produces:
       *       - application/json
       *
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .get(
      '/user/faq',
      controller.getAllFaq
    );

    /**
       * @swagger
       *   /admin/faq/:_id :
       *   get:
       *     description: delete a faq
       *     tags:
       *       - FAQ
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: x-auth-token
       *         in: header
       *         schema:
       *         type: string
       *         required: true
       *       - name: _id
       *         description: _id.
       *         in: params
       *         type: string
       *         required: true
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .delete(
      '/admin/faq/:_id',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.deleteFaq),
      controller.deleteFaq
    );

    /**
       * @swagger
       *   /admin/faq :
       *   post:
       *     description: CREATE FAQ
       *     tags:
       *       - FAQ
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: x-auth-token
       *         in: header
       *         schema:
       *         type: string
       *         required: true
       *       - name: imageUri
       *         description: imageUri.
       *         in: body
       *         type: string
       *         required: true
       *       - name: question
       *         description: question.
       *         in: body
       *         type: string
       *         required: true
       *       - name: answer
       *         description: answer.
       *         in: body
       *         type: string
       *         required: true
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .post(
      '/admin/faq',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.createFaq),
      controller.createFaq
    );


    router
      .patch(
        '/admin/faq/image',
        authenticate,
        checkIfAdminOrSuperAdmin,
        celebrate(validateSchema.faqImage),
        imageMulter.single('imageUri'),
        controller.faqImage
      );

    /**
       * @swagger
       *   /admin/faq/:_id :
       *   post:
       *     description: edit a faq
       *     tags:
       *       - FAQ
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: x-auth-token
       *         in: header
       *         schema:
       *         type: string
       *         required: true
       *       - name: answer
       *         description: answer
       *         in: body
       *         type: string
       *         required: true
       *       - name: question
       *         description: question.
       *         in: body
       *         type: string
       *         required: true
       *       - name: imageUri
       *         description: imageUri.
       *         in: body
       *         type: string
       *         required: true
       *     responses:
       *       200:
       *        	description: Success message
       */
  router
    .put(
      '/admin/faq/:_id',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.editFaq),
      controller.editFaq
    );
};
