const { Joi } = require('celebrate');

module.exports = {
  hashtagMedium: {
    params: Joi.object().required().keys({
      hashtag: Joi.string().required(),
      userId: Joi.string().required(),
      bountyCampaignId: Joi.string().required()
    })
  },
  usernameExists: {
    params: Joi.object().required().keys({
      username: Joi.string().required()
    })
  },
  submitImageBounty: {
    body: Joi.object().keys({
      imageUri: Joi.any()
    })
  },
  submitBounty: {
    params: Joi.object().keys({
      bountyCampaignId: Joi.string().required()
    }),
    body: Joi.object().keys({
      participantUsername: Joi.string().required(),
      imageUri: Joi.string(),
      url: Joi.string(),
      hashtag: Joi.string()
    })
  },
  bountyStatus: {
    body: Joi.object().keys({
      status: Joi.string().valid('Accepted', 'Rejected').required(),
      bountyCampaignId: Joi.string().required(),
      userId: Joi.string().required()
    })
  },
  transferBounty: {
    body: Joi.object().keys({
      transferStatus: Joi.string().valid('yes', 'no').required(),
      bountyCampaignId: Joi.string().required(),
      userId: Joi.string().required()
    })
  }
};
