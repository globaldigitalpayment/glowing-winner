const mongoose = require('mongoose');

const bountyParticipantsSchema = new mongoose.Schema({
  participantUsername : {
    type: String,
    required: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  bountyCampaignId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'BountyCampaign'
  },
  submitProof: {
    type: {
      type: String,
      enum: ['image', 'url']
    },
    url: {
      type: String
    },
  },
  hashtag: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['Submitted', 'Accepted', 'Rejected']
  },
  usernameValidation: {
    type: String,
    enum: ['yes', 'no'],
    default: 'no'
  },
  activityValidation: {
    type: String,
    enum: ['yes', 'no'],
    default: 'no'
  },
  bountyTransferred : {
    type: String,
    enum: ['yes', 'no'],
    default: 'no'
  }
});

bountyParticipantsSchema.index(
  {
    userId: 1,
    bountyCampaignId: 1
  },
  {
    unique: true,
  }
);

const BountyParticipants = mongoose.model('BountyParticipants', bountyParticipantsSchema);


module.exports = BountyParticipants;
