const controller = require('./controller'),
  { celebrate } = require('celebrate'),
  moment = require('moment'),
  modelFunction = require('./doa'),
  multer = require('multer'),
  multerS3 = require('multer-s3'),
  s3 = require('app/v1/config/s3');

const imageMulter = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'zineum-ico-kyc',
    acl: 'public-read',
    metadata: function (req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function (req, file, cb) {
      const originalName = file.originalname.split('.');
      const ext = `.${originalName[originalName.length - 1]}`;
      cb(null,originalName + Date.now().toString() + ext);
    }
  })
});


const authenticate = require('./../../config/authenticate');
const validateSchema = require('./schema');

const checkIfAdminOrSuperAdmin = (req, res, next) => {
//   console.log(req.user);
  if (req.user.role === 'SUPER_ADMIN' || req.user.role === 'ADMIN') {
    next();
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Access',
      description: ''
    });
  }
};


module.exports = function (router) {

  // sending dynamic link as a param or query
  /**
  * @swagger
  * /medium/hashtagBounty/:hashtag/:userId/:bountyCampaignId:
  *   get:
  *     description: medium hashtag ?
  *     tags:
  *       - Bounty Participants
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: userId
  *         in: params
  *         schema:
  *           type: string
  *         required: true
  *         description: userId of the user
  *       - name: hashtag
  *         in: params
  *         schema:
  *           type: string
  *         required: true
  *         description: hashtag used by the user
  *       - name: bountyCampaignId
  *         in: params
  *         schema:
  *           type: string
  *         required: true
  *         description: bountyCampaignId of the user
  *     responses:
  *       200:
  *        	description: Success message
  */
  router
    .get(
      '/medium/hashtagBounty/:hashtag/:userId/:bountyCampaignId',
      celebrate(validateSchema.hashtagMedium),
      controller.mediumHashtagBounty
    );

    /**
    * @swagger
    * /user/bountyCampaign/image:
    *   patch:
    *     description: bountyCampaign image uri got (not saved)
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: headers
    *         schema:
    *           type: string
    *         required: true
    *         description: token created when user signed in
    *       - name: imageUri
    *         in: body
    *         schema:
    *           type: string
    *         required: false
    *         description: image uri of the image
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .patch(
      '/user/bountyCampaign/image',
      authenticate,
      celebrate(validateSchema.submitImageBounty),
      imageMulter.single('imageUri'),
      controller.submitImageBounty
    );

    /**
    * @swagger
    * /user/bountyCampaign/submit/:bountyCampaignId:
    *   put:
    *     description: participants submission for bounty
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: headers
    *         schema:
    *           type: string
    *         required: true
    *         description: token created when user signed in
    *       - name: bountyCampaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: bountyCampaignId of the cbounty
    *       - name: participantUsername
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: social media handle of user for specific bounty
    *       - name: url
    *         in: body
    *         schema:
    *           type: string
    *         required: false
    *         description: url of participation proof
    *       - name: imageUri
    *         in: body
    *         schema:
    *           type: string
    *         required: false
    *         description: image uri of participation proof
    *       - name: hashtag
    *         in: body
    *         schema:
    *           type: string
    *         required: false
    *         description: hashtag used during participation
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .put(
      '/user/bountyCampaign/submit/:bountyCampaignId',
      authenticate,
      celebrate(validateSchema.submitBounty),
      controller.submitBounty
    );

    /**
    * @swagger
    * /user/bountyCampaignActivity:
    *   get:
    *     description: retrieved all activity
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: headers
    *         schema:
    *           type: string
    *         required: true
    *         description: token created when user signed in
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/user/bountyCampaignActivity',
      authenticate,
      controller.activitySMBC
    );

    /**
    * @swagger
    * /bountyCampaign/status/:userId/:bountyCampaignId:
    *   get:
    *     description: get bounnty status for user
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: userId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: id of the user
    *       - name: bountyCampaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: id of bounty
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/bountyCampaign/status/:userId/:bountyCampaignId',
      controller.getBountyStatus
    );

  // router
  //   .put(
  //     '/admin/:bountyCampaignId/:status/:userId',
  //     authenticate,
  //     checkIfAdminOrSuperAdmin,
  //     celebrate(validateSchema.bountyStatus),
  //     controller.bountyStatus
  //   );

  /**
  * @swagger
  * /admin/statusChange:
  *   put:
  *     description: changing the status
  *     tags:
  *       - Bounty Participants
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: userId
  *         in: body
  *         schema:
  *           type: string
  *         required: true
  *         description: id of the user
  *       - name: bountyCampaignId
  *         in: body
  *         schema:
  *           type: string
  *         required: true
  *         description: id of bounty
  *       - name: status
  *         in: body
  *         schema:
  *           type: string
  *         required: true
  *         description: valid status are Accepted, Rejected
  *     responses:
  *       200:
  *        	description: Success message
  */
  router
    .put(
      '/admin/statusChange',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.bountyStatus),
      controller.bountyStatusChange
    );

    /**
    * @swagger
    * /admin/transferBounty:
    *   put:
    *     description: transfer bounty
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: x-auth-token
    *         in: headers
    *         schema:
    *           type: string
    *         required: true
    *         description: token
    *       - name: transferStatus
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: transferStatus
    *       - name: bountyCampaignId
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: id of bounty
    *       - name: userId
    *         in: body
    *         schema:
    *           type: string
    *         required: true
    *         description: userId
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .put(
      '/admin/transferBounty',
      authenticate,
      checkIfAdminOrSuperAdmin,
      celebrate(validateSchema.transferBounty),
      controller.transferBounty
    );

  // router
  //   .put(
  //     '/admin/transferBounty/:bountyCampaignId/:transferStatus/:userId',
  //     authenticate,
  //     checkIfAdminOrSuperAdmin,
  //     celebrate(validateSchema.transferBounty),
  //     controller.transferBounty
  //   );

  /**
  * @swagger
  * /medium/:username:
  *   get:
  *     description: checking username exists in medium
  *     tags:
  *       - Bounty Participants
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: username
  *         in: params
  *         schema:
  *           type: string
  *         required: true
  *         description: social media handle
  *     responses:
  *       200:
  *        	description: Success message
  */
  router
    .get(
      '/medium/:username',
      controller.mediumCheck
    );

    /**
    * @swagger
    * /validateUser/medium/:campaignId/:userId/:username:
    *   put:
    *     description: validating user in medium
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: campaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: campaignId
    *       - name: userId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: userId
    *       - name: username
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: social media handle
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .put(
      '/validateUser/medium/:campaignId/:userId/:username',
      controller.mediumValidation
    );

    /**
    * @swagger
    * /medium/folowing/:username/:usernameToCheck:
    *   get:
    *     description: medium follow ?
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: username
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: username
    *       - name: usernameToCheck
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: usernameToCheck
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/medium/folowing/:username/:usernameToCheck',
      controller.mediumIsFollowing
    );

    /**
    * @swagger
    * /medium/post/:userId/:bountyCampaignId:
    *   get:
    *     description: medium get post id
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: bountyCampaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: bountyCampaignId
    *       - name: userId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: userId
    *     responses:
    *       200:
    *        	description: Success message
    */
  router.
    get(
      '/medium/post/:userId/:bountyCampaignId',
      controller.mediumGetPostId
    );

    /**
    * @swagger
    * /medium/clapped/:username/:usernameToCheck:
    *   get:
    *     description: medium clapped
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: usernameToCheck
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: usernameToCheck
    *       - name: username
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: username
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/medium/clapped/:username/:usernameToCheck',
      controller.mediumClapped
    );

    /**
    * @swagger
    * /medium/post/clapped/:postId/:username:
    *   get:
    *     description: medium post clapped
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: postId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: postId
    *       - name: username
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: username
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/medium/post/clapped/:postId/:username',
      controller.mediumPostClapped
    );

    /**
    * @swagger
    * /activity/validation/:userId/:campaignId:
    *   put:
    *     description: update vaidation
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: userId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: userId
    *       - name: campaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: campaignId
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .put(
      '/activity/validation/:userId/:campaignId',
      controller.activityValidation
    )


        /**
        * @swagger
        * /reddit/user/:username:
        *   get:
        *     description: username exists ?
        *     tags:
        *       - Bounty Participants
        *     produces:
        *       - application/json
        *     parameters:
        *       - name: username
        *         in: params
        *         schema:
        *           type: string
        *         required: true
        *         description: social media handle
        *     responses:
        *       200:
        *        	description: Success message
        */
  router
    .get(
      '/reddit/user/:username',
      celebrate(validateSchema.usernameExists),
      controller.usernameExists
    );

    /**
    * @swagger
    * /validateUser/reddit/:campaignId/:userId/:username:
    *   put:
    *     description: validateUser reddit
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: campaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *       - name: userId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *       - name: username
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .put(
      '/validateUser/reddit/:campaignId/:userId/:username',
      controller.redditValidation
    );

    /**
    * @swagger
    * /reddit/posts/:username/:hashtag:
    *   get:
    *     description: hashtag used
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: hashtag
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *       - name: username
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *       - name: username
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/reddit/posts/:username/:hashtag',
      controller.redditPostHashTag
    );

    /**
    * @swagger
    * /steemit/following/:username/:usernameToCheck:
    *   get:
    *     description: following ?
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: username
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: username
    *       - name: usernameToCheck
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: usernameToCheck
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/steemit/following/:username/:usernameToCheck',
      controller.steemitIsFollowing
    );

    /**
    * @swagger
    * /steemit/post/upvoted/:userId/:bountyCampaignId:
    *   get:
    *     description: upvoted ?
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: userId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: userId
    *       - name: bountyCampaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: bountyCampaignId
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/steemit/post/upvoted/:userId/:bountyCampaignId',
      controller.steemitIsUpvoted
    );

    /**
    * @swagger
    * /steemit/post/commented/:userId/:bountyCampaignId:
    *   get:
    *     description: commented ?
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: userId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: userId
    *       - name: bountyCampaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: bountyCampaignId
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/steemit/post/commented/:userId/:bountyCampaignId',
      controller.steemitIsCommented
    );

    /**
    * @swagger
    * /steemit/post/hashtag/:userId/:bountyCampaignId/:hashtag:
    *   get:
    *     description: hashtag ?
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: userId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: userId
    *       - name: bountyCampaignId
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: bountyCampaignId
    *       - name: hashtag
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: hashtag
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/steemit/post/hashtag/:userId/:bountyCampaignId/:hashtag',
      controller.steemitIsHashTagged
    );

    /**
    * @swagger
    * /twitter/followers/:username:
    *   get:
    *     description: total followers
    *     tags:
    *       - Bounty Participants
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: username
    *         in: params
    *         schema:
    *           type: string
    *         required: true
    *         description: social media handle
    *     responses:
    *       200:
    *        	description: Success message
    */
  router
    .get(
      '/twitter/followers/:username',
      controller.twittertTotalFollowers
    );


  router
    .put(
      '/validateUser/twitter/:campaignId/:userId/:username',
      // authenticate,
      controller.twitterValidation
    );


  // router
  //   .put(
  //     '/activity/validate/twitter/:campaignId/:userId/:username',
  //   );

  router
    .get(
      '/twitter/retweetedQuoted/:username/:originalTweetId/:userTweetId',
      controller.twitterRetweetedQuoted
    );

  router
    .get(
      '/twitter/hashtag/:username/:userTweetId/:hashtag',
      controller.twitterHashTag
    );

};
