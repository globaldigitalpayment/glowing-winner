const modelFunction = require('./doa'),
  userModelFunction = require('../user/doa'),
  bountyCampaignModelFunction = require('../BountyCampaign/doa'),
  mongoose = require('mongoose'),
  request = require('request'),
  _ = require('lodash'),
  BountyParticipationModel = require('./model'),
  twitterapi = require('twitter'),
  fs = require('fs'),
  bountyParticipantsController = Object.create(null);

const constants = require('../../../../config/constants');
const client = new twitterapi(constants.twitterAuth);

bountyParticipantsController.activitySMBC = async(req, res, next) => {
  try {
    const activitySMBCampaign = await modelFunction.find({
      params: { userId: req.user._id },
      query: [ 'bountyCampaignId' ]
    });
    if(activitySMBCampaign.length > 0) {
      return res
        .status(200)
        .json({
          success: true,
          data: activitySMBCampaign,
          message: 'Successfully retrieved all activity'
        });
    }else {
      return res
        .status(200)
        .json({
          success: true,
          data: [],
          message: 'No activity'
        });
    }
  } catch(err) {
    next(err);
  }
};

bountyParticipantsController.submitImageBounty = async(req, res, next) => {

  if (!!req.file) {
    const image = req.file;
    console.log('image : ', image);
    console.log('image location : ', image.location);
    return res
      .status(200)
      .json({
        success: true,
        message: 'image stored successfully',
        imageUri: image.location
      });
  }else {
    console.log('req.file : ', req.file);
    return res
      .status(200)
      .json({
        success: false,
        message: 'no image to store'
      });
  }
};

bountyParticipantsController.submitBounty = async(req, res, next) => {
  const userId = req.user._id;
  const bountyCampaignId = req.params.bountyCampaignId;
  let bountyCampaignType;
  let dataF, dataU, dataA;
  console.log(bountyCampaignId);
  try {
    const bountyCampaignFind = await bountyCampaignModelFunction.findOne({
      params: {
        _id: bountyCampaignId
      }
    });
    if(!!bountyCampaignFind) {
      bountyCampaignType = bountyCampaignFind.basicInfo.campaignType;
      console.log('bountyCampaignType : ', bountyCampaignType);

      // Checking if user has participated in the campaign
      dataF = { userId, bountyCampaignId };
      const userCampaignParticipation = await modelFunction.findOne({  params: dataF });
      if(!!userCampaignParticipation) {
        // User has already participated
        return res
          .status(200)
          .json({
            success: false,
            message: 'User have already participated in this bounty campaign'
          });
      }else {
        // can participate
        const date = new Date();
        const dateNowTime = date.getTime();
        const endDate = bountyCampaignFind.endDate;
        const endDateTime = endDate.getTime();
        console.log('endDateTime > dateNowTime : ', endDateTime > dateNowTime);
        console.log('bountyCampaignFind.active : ', bountyCampaignFind.active);
        console.log('bountyCampaignFind : ', !!bountyCampaignFind);
        console.log('is true : ', !!bountyCampaignFind && bountyCampaignFind.active && endDateTime > dateNowTime);
        if(!!bountyCampaignFind && bountyCampaignFind.active && endDateTime > dateNowTime) {
          if(!req.body.imageUri && !req.body.url) {
            // User need to submit either imageUri or url
            return res
              .status(200)
              .json({
                success: false,
                message: 'imageUri or url is required'
              });
          }else {
            if(!!req.body.imageUri && bountyCampaignFind.submitProof.includes('imageUri')) {
              // imageUri received
              console.log('bountyCampaignFind submitProof imageUri ', bountyCampaignFind.submitProof.includes('imageUri'));
              dataA = {
                participantUsername: req.body.participantUsername,
                userId,
                bountyCampaignId: req.params.bountyCampaignId,
                'submitProof.type': 'image',
                'submitProof.url': req.body.imageUri,
                status: 'Submitted',
                hashtag: req.body.hashtag
              };
            }else if(!!req.body.url && bountyCampaignFind.submitProof.includes('url')) {
              console.log('bountyCampaignFind submitProof  url : ', bountyCampaignFind.submitProof.includes('url'));
              // url received
              dataA = {
                participantUsername: req.body.participantUsername,
                userId,
                bountyCampaignId: req.params.bountyCampaignId,
                'submitProof.type': 'url',
                'submitProof.url': req.body.url,
                status: 'Submitted',
                hashtag: req.body.hashtag
              };
            }
            if(!!dataA) {
              // Updating bountyParticipation
              const bountyDetailAdd = await modelFunction.create({
                obj: dataA
              });
              // console.log('bounty Update : ', bountyUpdate);
              console.log('bounty detail add : ', bountyDetailAdd);
              if(!!bountyDetailAdd) {
                const updateBountyCampaign = await bountyCampaignModelFunction.findOneAndUpdate({
                  query: { _id: req.params.bountyCampaignId },
                  params: { $addToSet: { bountyParticipations:  bountyDetailAdd._id } }
                });

                return res
                  .status(200)
                  .json({
                    success: true,
                    message: 'Successfully added',
                  });
              }
            }else {
              return res
                .status(200)
                .json({
                  success: false,
                  message: 'Invalid submition type'
                });
            }
          }
        }else {
          return res
            .status(200)
            .json({
              success: false,
              message: 'inactive bounty campaign'
            })
        }
      }
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'Invalid id'
        })
    }
  }catch(err) {
    next(err);
  }
};

// bountyParticipantsController.submitBountyT = async(req, res, next) => {
//     if(!!bountyCampaignFind) {
//
//       findUserWithBounty = await userModelFunction.findOne({
//         params: dataF
//       });
//
//       console.log('findUserWithBounty : ', findUserWithBounty);
//
//       if(!!findUserWithBounty) {
//         console.log('findUserWithBounty : ', findUserWithBounty);
//         return res
//           .status(200)
//           .json({
//             success: false,
//             message: 'User have already participated in this bounty campaign'
//           });
//       }else {
//         // User can take part in the bounty
//         dataF = { 'basicInfo.campaignType': req.params.bountyCampaignName };
//         //Checking what type of submission is allowed
//         const bountyFindType = await bountyCampaignModelFunction.findOne({ params: dataF });
//         const date = new Date();
//         // const dateNow = date.toISOString();
//         const dateNowTime = date.getTime();
//         const endDate = bountyFindType.endDate;
//         const endDateTime = endDate.getTime();
//         console.log('endDateTime > dateNowTime : ', endDateTime > dateNowTime);
//         console.log('bountyFindType.active : ', bountyFindType.active);
//         console.log('bountyFindType : ', !!bountyFindType);
//         // console.log('bountyFindType : ', !!bountyFindType);
//         console.log('is true : ', !!bountyFindType && bountyFindType.active && endDateTime > dateNowTime);
//         // if(!!bountyFindType) {
//         if(!!bountyFindType && bountyFindType.active && endDateTime > dateNowTime) {
//           if(!req.body.imageUri && !req.body.url) {
//             // User need to submit either imageUri or url
//             return res
//               .status(200)
//               .json({
//                 success: false,
//                 message: 'imageUri or url is required'
//               });
//           }else {
//             // let dataUBC;
//             let dataAddBP;
//             if(!!req.body.imageUri && bountyFindType.submitProof.includes('imageUri')) {
//               // imageUri received
//               console.log('bountyFindType submitProof imageUri ', bountyFindType.submitProof.includes('imageUri'));
//               dataAddBP = {
//                 userId,
//                 bountyCampaignId: req.params.bountyCampaignId,
//                 imageUri: req.body.imageUri,
//                 status: 'Submitted'
//               };
//             }else if(!!req.body.url && bountyFindType.submitProof.includes('url')) {
//               console.log('bountyFindType submitProof  url : ', bountyFindType.submitProof.includes('url'));
//               // url received
//               dataAddBP = {
//                 userId,
//                 bountyCampaignId: req.params.bountyCampaignId,
//                 url: req.body.url,
//                 status: 'Submitted'
//               };
//             }
//
//             // dataF = { 'basicInfo.name': req.params.bountyName };
//
//             // updating data
//             if(!!dataAddBP) {
//               // Check in BountyParticipantsModel if this user already submitted
//               const participantFind = {
//                 userId: req.user.id,
//                 bountyCampaignId: req.params.bountyCampaignId
//               };
//               const bountyParticipantUserFind = await modelFunction.findOne({
//                 params: participantFind
//               })
//               console.log('bountyParticipantUserFind : ', bountyParticipantUserFind);
//               if(!!bountyParticipantUserFind) {
//                 // User alredy submitted in this campaignType
//                 return res
//                   .status(200)
//                   .json({
//                     success: false,
//                     message: 'You have already submitted in this campaign'
//                   });
//               }else {
//                 // Save user details
//                 const bountyDetailAdd = await modelFunction.create({
//                   obj: dataAddBP
//                 });
//                 // console.log('bounty Update : ', bountyUpdate);
//                 console.log('bounty detail add : ', bountyDetailAdd);
//                 if(!!bountyDetailAdd) {
//                   const UpdateUserWithBountyName = await userModelFunction.findOneAndUpdate({
//                     query: { _id: req.user._id },
//                     params: { $addToSet: { submittedBountyName: req.params.bountyName } }
//                   });
//                   // add bountyDetailAddId in bountyCampaign
//                   const UpdateBountyCampaignName = await bountyCampaignModelFunction.findOneAndUpdate({
//                     query: { _id: req.params.bountyCampaignId },
//                     params: { $addToSet: { bountyParticipations: { bountyParticipantsId: bountyDetailAdd._id } } }
//                   });
//                   return res
//                     .status(200)
//                     .json({
//                       success: true,
//                       message: 'Successfully submitted'
//                     });
//                 }else {
//                 return res
//                   .status(200)
//                   .json({
//                     success: false,
//                     message: 'Invalid submition type'
//                   });
//               }
//             }
//           }
//         }
//       }else {
//         return res
//           .status(200)
//           .json({
//             success: false,
//             message: 'No such bounty exists'
//           });
//       }
//     }
//   }else {
//       // No bounty campaign exists
//       return res
//         .status(200)
//         .json({
//           success: true,
//           message: 'Invalid _id'
//         })
//     }
//   }catch(err) {
//     next(err);
//   }
// };

bountyParticipantsController.getBountyStatus = async(req, res, next) => {
  const dataF = {
    bountyCampaignId: req.params.bountyCampaignId,
    userId: req.params.userId
  };

  const selector = 'status';
  console.log('getBountyStatus');
  try{
    const bountyParticipationFind = await modelFunction.findOne({
      params: dataF,
      selector
    });
    console.log('bountyParticipationFind : ', bountyParticipationFind);
    if(!!bountyParticipationFind) {
      console.log('bountyParticipationFind : ', bountyParticipationFind);
      return res
        .status(200)
        .json({
          success: true,
          data: bountyParticipationFind
        });
    }
  }catch(err) {
    next(err);
  }
};

bountyParticipantsController.bountyStatusChange = async (req, res, next) => {
  try {
    let dataF, dataU, userBountyStatus, maxUsersAllowed;
    let incVal = 0;
    const bountyCampaignId = req.body.bountyCampaignId;
    const userId = req.body.userId;

    dataF = { _id: bountyCampaignId };
    const bountyCampaignFind = await bountyCampaignModelFunction.findOne({ params: dataF });
    maxUsersAllowed = bountyCampaignFind.maxUsersAllowed;
    console.log('maxUsersAllowed : ', maxUsersAllowed);

    dataF = { userId, bountyCampaignId };

    const bountyParticipationFind = await modelFunction.findOne({ params: dataF });
    console.log(bountyParticipationFind);
    if(!!bountyParticipationFind) {
      // bountyParticipationFind found
      userBountyStatus = bountyParticipationFind.status;
      console.log('userBountyStatus : ', userBountyStatus);
      dataU = {
        $set: {
          status: req.body.status
        }
      };

      const bountyParticpationStatusUpdate = await modelFunction.findOneAndUpdate({
        query: dataF,
        params: dataU
      });

      if(!!bountyParticpationStatusUpdate) {

        dataF = {
          _id: req.body.userId
        }


        // const userBountyUpdate = await userModelFunction.findOneAndUpdate({
        //   query: dataF,
        //   params: dataU
        // });

        if(req.body.status === 'Accepted' && userBountyStatus !== 'Accepted' && maxUsersAllowed > 0) {
          incVal = -1;
        }else if(req.body.status === 'Rejected' && userBountyStatus === 'Accepted' && maxUsersAllowed > 0) {
          incVal = 1;
        }



        const dataInc = {
          $inc: {
            maxUsersAllowed: incVal
          }
        };

        const decIncMaxUsersAllowed = await bountyCampaignModelFunction.findOneAndUpdate({
          query : { _id: req.body.bountyCampaignId },
          params: dataInc
        });

        console.log('decIncMaxUsersAllowed : ', decIncMaxUsersAllowed);

        return res
          .status(200)
          .json({
            success: true,
            message: 'Status successfully changed and bounty transferred'
          });
      } else {
        // unable to update the status
        return res
          .status(200)
          .json({
            success: false,
            message: 'Unable to change the status'
          });
      }
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'unable to find participation of user in this campaign'
        });
    }
  }catch(err) {
    next(err);
  }
};

bountyParticipantsController.transferBounty = async (req, res, next) => {
  try {
    let dataF, dataU, bountyParticipationFind, bountyCampaignFind, bountyTransferred, status, active, rewardBounty, campaignType;
    dataF = {
      userId: req.body.userId,
      bountyCampaignId: req.body.bountyCampaignId
    };
    bountyParticipationFind = await modelFunction.findOne({
      params: dataF
    });

    bountyTransferred = bountyParticipationFind.bountyTransferred;
    status = bountyParticipationFind.status;
    console.log('bountyTransferred : ', bountyTransferred);
    console.log('status : ', status);


    dataF = {
      _id: req.body.bountyCampaignId
    };
    bountyCampaignFind = await bountyCampaignModelFunction.findOne({
      params: dataF
    });
    active = bountyCampaignFind.active;
    campaignType = bountyCampaignFind.basicInfo.campaignType;
    rewardBounty = bountyCampaignFind.rewardBounty;
    console.log('active : ', active);
    console.log('campaignType : ', campaignType);
    console.log('rewardBounty : ', rewardBounty);

    console.log(typeof req.body.transferStatus, 'req.body.transferStatus');
    console.log(typeof status, 'status');
    console.log(typeof bountyTransferred, 'bountyTransferred');
    console.log(req.body.transferStatus, 'this.body.transferStatus');
    console.log('true ? : ', (status === 'Accepted' && bountyTransferred === 'no' && req.body.transferStatus === 'yes'));
    console.log('check');
    if(status === 'Accepted' && bountyTransferred === 'no' && req.body.transferStatus === 'yes') {


      // transfering bounty
      console.log('inside 1');

      console.log('tokens.bounty.campaignType : ', `tokens.bounty.${campaignType}`);
      dataU = {
        $inc: {
          [`tokens.bounty.${campaignType}`]: rewardBounty,
          'tokens.bounty.total': rewardBounty,
          'tokens.total': rewardBounty
        }
      };
      console.log('dataU : ', dataU);

    }else if(status === 'Accepted' && bountyTransferred === 'yes' && req.body.transferStatus === 'no') {
      console.log('inside 2');

      dataU = {
        $inc: {
          [`tokens.bounty.${campaignType}`]: - rewardBounty,
          'tokens.bounty.total': - rewardBounty,
          'tokens.total': - rewardBounty
        }
      };
      console.log('dataU : ', dataU);
    }

    if(!!dataU) {
      console.log('*************----------------***********');
      console.log('dataF : ', dataF);
      console.log('dataU : ', dataU);
      const userUpdate = await userModelFunction.findByIdAndUpdate({
        id: req.body.userId,
        data: dataU
      });

      console.log(userUpdate);


      const bountyPartitionUpdate = await modelFunction.findOneAndUpdate({
        query: {
          userId: req.body.userId,
          bountyCampaignId: req.body.bountyCampaignId
        },
        params: {
          $set: {
            bountyTransferred: req.body.transferStatus
          }
        }
      });

      console.log(bountyPartitionUpdate);
      // else {
      //   return res
      //     .status(200)
      //     .json({
      //       success: false,
      //       message: 'Cannot transfer bounty to this user'
      //     });
      // }
      return res
        .status(200)
        .json({
          success: true,
          message: 'bounty transferred'
        });
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'bounty cannot be transferred'
        })
    }


  }catch(err) {
    next(err);
  }
};

bountyParticipantsController.mediumCheck = async (req, res, next) => {
  try{
    let userId;
    const userData = await request.get({
      url: `https://medium.com/@${req.params.username}?format=json`
    }, (err, httpResponse, body) => {
      if (err) {
        return res
          .status(200)
          .json({
            success: false,
            message: 'No such user exists'
          });
      }else {
        let result = JSON.parse(body.replace(/[^{]*/i, ''));
        if (!result.success) {
          return res
            .status(200)
            .json({
              success: false,
              message: 'No such user exists'
            });
        }else {
          userId = result.payload.user.userId;
          console.log('userId: -> ', userId)

          return res
            .status(200)
            .json({
              success: false,
              message: `Valid user, medium userId : ${userId}`
            });
        }
      }
    });
  }catch(err) {
    next(err);
  }
};

bountyParticipantsController.mediumIsFollowing = async(req, res, next) => {
  try{
    let userId;
    let isFollowing = false;
    const userData = await request.get({
      url: `https://medium.com/@${req.params.username}/following?format=json`
    }, (err, httpResponse, body) => {
      if (err) {
        return res
          .status(200)
          .json({
            success: false,
            message: 'No such user exists'
          });
      }else {

        let result = JSON.parse(body.replace(/[^{]*/i, ''));
        // console.log(result, "-**************");
        if (!result.success) {
          return res
            .status(200)
            .json({
              success: false,
              message: 'No such user exists'
            });
        }else {
          const followingData = result.payload.references.User;
          // console.log('followingData : ', followingData);
          for (key in followingData) {
            if (followingData[key].username === req.params.usernameToCheck) {
              isFollowing = true;
              break;
            }
          }
          if(!!isFollowing) {
            return res
              .status(200)
              .json({
                success: true,
                message: `medium user is following ${req.params.usernameToCheck}`
              });
          }else {
            return res
              .status(200)
              .json({
                success: false,
                message: `medium user is not following ${req.params.usernameToCheck}`
              });
          }
        }
      }
    });
  }catch(err) {
    next(err);
  }

}

bountyParticipantsController.mediumClapped = async(req, res, next) => {
  try{
    // let userId;
    let isClapping = false;
    const userData = await request.get({
      url: `https://medium.com/@${req.params.username}/has-recommended?format=json`
    }, (err, httpResponse, body) => {
      if (err) {
        return res
          .status(200)
          .json({
            success: false,
            message: 'No such user exists'
          });
      }else {
        let result = JSON.parse(body.replace(/[^{]*/i, ''));
        if (!result.success) {
          return res
            .status(200)
            .json({
              success: false,
              message: 'No such user exists'
            });
        }else {
          const clappedData = result.payload.references.User;
          // console.log('followingData : ', followingData);
          for (key in clappedData) {
            if (clappedData[key].username === req.params.usernameToCheck) {
              isClapping = true;
              break;
            }
          }
          if(!!isClapping) {
            return res
              .status(200)
              .json({
                success: true,
                message: `medium user have clapped for ${req.params.usernameToCheck}`
              });
          }else {
            return res
              .status(200)
              .json({
                success: false,
                message: `medium user haven't clapped for ${req.params.usernameToCheck}`
              });
          }
        }
      }
    });
  }catch(err) {
    next(err);
  }
}

bountyParticipantsController.activityValidation = async(req, res, next) => {
  try{
    const activityValidationData = await modelFunction.findOneAndUpdate({
      query: {
        userId: req.params.userId,
        bountyCampaignId: req.params.campaignId
      },
      params: {
        $set: {
          activityValidation: 'yes'
        }
      }
    });
    if(!!activityValidationData) {
      return res
        .status(200)
        .json({
          success: true,
          message: 'user activity validated'
        });
    }else {
      return res
        .status(200)
        .json({
          success: true,
          message: 'user activity invalid'
        });
    }
  } catch(err) {
    next(err);
  }
}



bountyParticipantsController.mediumHashtagBounty = async(req, res, next) => {
  try{
    let type, url;

    const userParticipationData = await modelFunction.findOne({
      params: {
        userId: req.params.userId,
        bountyCampaignId: req.params.bountyCampaignId
      }
    });

    type = userParticipationData.submitProof.type;
    if(type === 'url') {
      url = userParticipationData.submitProof.url;

      console.log('sdfsdfsdfdsfdf');
      let ishashTagged = false;
      let hashtag =  req.params.hashtag
      hashtag.includes('#') ?
        hashtag = hashtag
        :
        hashtag = '#' + hashtag

      console.log('url : ', `${url}?format=json`);
      const postData = await request.get({
        url: `${url}?format=json`
      }, (err, httpResponse, body) => {
        if (err) {
          return res
            .status(200)
            .json({
              success: false,
              message: 'No such post exists'
            });
        }else {
          let result = JSON.parse(body.replace(/[^{]*/i, ''));
          console.log('hashtag : ', hashtag);
          if (!result.success) {
            return res
              .status(200)
              .json({
                success: false,
                message: 'invalid details'
              });
          }else {
            console.log('hashtag : ', hashtag);
            ishashTagged = JSON.stringify(body).indexOf(hashtag) !== -1;
            // ishashTagged = JSON.stringify(body).indexOf('jogging') !== -1;

            console.log('ishashTagged : ', ishashTagged);
            if(!!ishashTagged) {
              return res
                .status(200)
                .json({
                  success: true,
                  message: `medium user have used hash tag ${hashtag}`
                });
            }else {
              return res
                .status(200)
                .json({
                  success: false,
                  message: `medium user haven't used hashtag for ${hashtag}`
                });
            }
          }
        }
      });
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'user does not have url'
        })
    }

  }catch(err) {
    next(err);
  }
}

bountyParticipantsController.mediumGetPostId = async(req, res, next) => {
  try{
    let type, url, postId;
    // let gotPostId = false;

    const userParticipationData = await modelFunction.findOne({
      params: {
        userId: req.params.userId,
        bountyCampaignId: req.params.bountyCampaignId
      }
    });

    type = userParticipationData.submitProof.type;
    if(type === 'url') {
      url = userParticipationData.submitProof.url;

      console.log('url : ', `${url}?format=json`);
      const postData = await request.get({
        url: `${url}?format=json`
      }, (err, httpResponse, body) => {
        if (err) {
          return res
            .status(200)
            .json({
              success: false,
              message: 'No such post exists'
            });
        }else {
          let result = JSON.parse(body.replace(/[^{]*/i, ''));
          if (!result.success) {
            return res
              .status(200)
              .json({
                success: false,
                message: 'invalid details'
              });
          }else {
            // get post id
            postId = result.payload.value.id;
            console.log(' postId : ', postId);
            if(!!postId){
              //get if user clapped in this post
              // gotPostId = true;
              console.log('got post id ******');
              return res
                .status(200)
                .json({
                  success: true,
                  message: 'Successfully retrieved postid',
                  postId: postId
                });
            }else {
              return res
                .status(200)
                .json({
                  success: false,
                  message: 'unable to find post id'
                });
            }
          }
        }
      });
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'user does not have url'
        })
    }
  }catch(err) {
    next(err);
  }
}

bountyParticipantsController.mediumPostClapped = async(req, res, next) => {
  try{
    const userClappedData = await request.get({
      url: `https://medium.com/p/${req.params.postId}/upvotes`,
    }, (err, httpResponse, body) => {
      if (err) {
        next(err);
      }else {
        console.log('********');
        let isUsernamePresent = JSON.stringify(body).indexOf(`"username\\":\\"${req.params.username}\\"`) !== -1;

        if(!!isUsernamePresent) {
          console.log('isUsernamePresent : ', isUsernamePresent);
          return res
            .status(200)
            .json({
              success: true,
              message: 'Medium user have clapped for your post'
            });
        }else {
          console.log('isUsernamePresent : ', isUsernamePresent);
          return res
            .status(200)
            .json({
              success: false,
              message: 'Medium user have not clapped for your post'
            });
        }
      }
    });
  }catch(err) {
    next(err);
  }
};

bountyParticipantsController.redditPostHashTag = async(req, res, next) => {
  try {
    let hashtagExists = false;
    let postCounter = 0;
    let postTitle;
    const after='';
    const redditPost = await request.get(
      {
        url: `https://gateway.reddit.com/desktopapi/v1/user/${req.params.username}/posts?rtj=debug&after=${after}&dist=25&sort=new&t=all&layout=classic&allow_over18=&include=identity`,
      }, (err, httpResponse, body)=> {
        if(err) {
          next(err);
        }else {
          let result = JSON.parse(body);
          const posts = result.posts;
          // console.log('posts : ', posts);
          let hashtag =  req.params.hashtag
          hashtag.includes('#') ?
            hashtag = hashtag
            :
            hashtag = '#' + hashtag
          if(!!posts) {
            postCounter = Object.keys(posts).length
            for(key in posts) {
              postTitle = posts[key].title.toString();
              // if (postTitle.includes('disagreement')) {
              if (postTitle.includes(hashtag)) {
                hashtagExists = true;
                console.log(`${hashtag} exists in the post titled ${postTitle}`);
                break;
              }
            }
            console.log('postCounter : ', postCounter);
            if(!!hashtagExists) {
              return res
                .status(200)
                .json({
                  success: true,
                  message: `${hashtag} exists in the post titled ${postTitle}`
                });
            }else {
              return res
                .status(200)
                .json({
                  success: false,
                  message: `${hashtag} does not exists in any post`
                });
            }
          }else {
            return res
              .status(200)
              .json({
                success: false,
                message: 'unable to find posts'
              })
          }
        }
      }
    );
  }catch(err) {
    next(err);
  }
}


bountyParticipantsController.usernameExists = async(req, res, next) => {
  try {
    let hashtagExists = false;
    let postCounter = 0;
    let postTitle;
    const after='';
    const redditUserData = await request.get(
      {
        url: `https://gateway.reddit.com/desktopapi/v1/user/${req.params.username}/posts`,
      }, (err, httpResponse, body)=> {
        if(err) {
          next(err);
        }else {
          let result = JSON.parse(body);
          if(result.code === 404) {
            return res
              .status(404)
              .json({
                success: false,
                message: result.explanation
              });
          }else {
            return res
              .status(200)
              .json({
                success: true,
                message: `${req.params.username} exists`
              });
          }
        }
      }
    );
  }catch(err) {
    next(err);
  }
}

bountyParticipantsController.steemitIsFollowing = async(req, res, next) => {
  try {
    let username = req.params.username;
    let ourUsername = req.params.usernameToCheck;
    let isFollowing = false;

    ourUsername = ourUsername.includes('@') ? ourUsername.replace('@', '') : ourUsername;
    username = username.includes('@') ? username.replace('@', '') : username;

    const steemitUserData = await request.post(
      {
        url: 'https://api.steemit.com/',
        json: {
          id: 2,
          jsonrpc: '2.0',
          method: 'call',
          params: ['follow_api', 'get_following', [`${username}`, '', 'blog', 1000]]
        }
      }, (err, httpResponse, body)=> {
        if(err) {
          next(err);
        }else {
          let following = body.result;
          isFollowing = _.find(following, o => o.following == ourUsername);

          // console.log(isFollowing , ' : isFollowing');
          if(!!isFollowing) {
            return res
              .status(200)
              .json({
                success: true,
                message: `${username} is following ${ourUsername} in steemit`
              });
          }else {
            return res
              .status(200)
              .json({
                success: false,
                message: `${username} is not following ${ourUsername} in steemit`
              });
          }
        }
      }
    );
  }catch(err) {
    next(err);
  }
};


bountyParticipantsController.steemitIsUpvoted = async(req, res, next) => {
  try {
    const bountyParticipationData = await modelFunction.findOne({
      userId: req.params.userId,
      bountyCampaignId: req.params.bountyCampaignId
    });

    if(!!bountyParticipationData) {
      // console.log('bountyParticipationData : ', bountyParticipationData);
      let username = bountyParticipationData.participantUsername;
      let submitProofType = bountyParticipationData.submitProof.type;

      if(submitProofType === 'image') {
        return res
          .status(200)
          .json({
            success: false,
            message: 'user have not submitted any url'
          });
      }else {
        let postLink = bountyParticipationData.submitProof.url;
        postLink = postLink.replace(/^.*\/\/[^\/]+/, '');
        username = username.includes('@') ? username.replace('@', '') : username;

        const steemitPostData = await request.post({
          url: 'https://api.steemit.com/',
          json: {
            id: 0,
            jsonrpc: '2.0',
            method: 'call',
            params: ['database_api', 'get_state', [`${postLink}`]]
          }
        }, (err, httpResponse, body) => {
          if (err) {
            next(err);
          }else {
            let {result} = body;
            // console.log('result : ', result);
            let isContentUPvoted = JSON.stringify(result).indexOf(`"voter":"${username}"`) != -1;
            if(isContentUPvoted) {
              // console.log('isContentUPvoted : ', isContentUPvoted);
              return res
                .status(200)
                .json({
                  success: true,
                  message: 'Post is upvoted'
                });
            }else {
              console.log('isContentUPvoted : ', isContentUPvoted);
              return res
                .status(200)
                .json({
                  success: false,
                  message: 'Post is not upvoted'
                });
            }
          }
        });
      }
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'Invalid details'
        });
    }
  }catch(err) {
    next(err);
  }
};

bountyParticipantsController.steemitIsCommented = async(req, res, next) => {
  try {
    const bountyParticipationData = await modelFunction.findOne({
      userId: req.params.userId,
      bountyCampaignId: req.params.bountyCampaignId
    });

    if(!!bountyParticipationData) {
      console.log('bountyParticipationData : ', bountyParticipationData);
      let username = bountyParticipationData.participantUsername;
      let submitProofType = bountyParticipationData.submitProof.type;

      if(submitProofType === 'image') {
        return res
          .status(200)
          .json({
            success: false,
            message: 'user have not submitted any url'
          });
      }else {
        let postLink = bountyParticipationData.submitProof.url;
        postLink = postLink.replace(/^.*\/\/[^\/]+/, '');
        username = username.includes('@') ? username.replace('@', '') : username;

        const steemitPostData = await request.post({
          url: 'https://api.steemit.com/',
          json: {
            id: 0,
            jsonrpc: '2.0',
            method: 'call',
            params: ['database_api', 'get_state', [`${postLink}`]]
          }
        }, (err, httpResponse, body) => {
          if (err) {
            next(err);
          }else {
            let {result} = body;
            console.log('result : ', result);
            let isCommented = JSON.stringify(result).indexOf(`"author":"${username}"`) != -1;;
            if(isCommented) {
              console.log('isCommented : ', isCommented);
              return res
                .status(200)
                .json({
                  success: true,
                  message: `Post is commented by ${username}`
                });
            }else {
              console.log('isCommented : ', isCommented);
              return res
                .status(200)
                .json({
                  success: false,
                  message: 'User have not commented'
                });
            }
          }
        });
      }
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'Invalid details'
        });
    }
  }catch(err) {
    next(err);
  }
};


bountyParticipantsController.steemitIsHashTagged = async(req, res, next) => {
  try {
    const bountyParticipationData = await modelFunction.findOne({
      userId: req.params.userId,
      bountyCampaignId: req.params.bountyCampaignId
    });

    if(!!bountyParticipationData) {
      console.log('bountyParticipationData : ', bountyParticipationData);
      let username = bountyParticipationData.participantUsername;
      let submitProofType = bountyParticipationData.submitProof.type;

      if(submitProofType === 'image') {
        return res
          .status(200)
          .json({
            success: false,
            message: 'user have not submitted any url'
          });
      }else {
        let postLink = bountyParticipationData.submitProof.url;
        postLink = postLink.replace(/^.*\/\/[^\/]+/, '');
        username = username.includes('@') ? username.replace('@', '') : username;

        const steemitPostData = await request.post({
          url: 'https://api.steemit.com/',
          json: {
            id: 0,
            jsonrpc: '2.0',
            method: 'call',
            params: ['database_api', 'get_state', [`${postLink}`]]
          }
        }, (err, httpResponse, body) => {
          if (err) {
            next(err);
          }else {
            let {result} = body;
            console.log('result : ', result);
            let stringObj = JSON.stringify(result);
            let authorLink = postLink.split('@')[1];
            let searchString = '"json_metadata"';
            let startIndex = stringObj.indexOf(`"${authorLink}"`);
            let endIndex = startIndex + stringObj.substring(startIndex).indexOf(searchString);
            let resultString = stringObj.slice(startIndex, endIndex);
            let hashtag =  req.params.hashtag
            hashtag.includes('#') ?
              hashtag = hashtag
              :
              hashtag = '#' + hashtag

              // let isHashTagged = resultString.includes('DIMM');
            let isHashTagged = resultString.includes(`${hashtag}`);
            if(isHashTagged) {
              console.log('isHashTagged : ', isHashTagged);
              return res
                .status(200)
                .json({
                  success: true,
                  message: `${username} have used ${hashtag}`
                });
            }else {
              console.log('isHashTagged : ', isHashTagged);
              return res
                .status(200)
                .json({
                  success: false,
                  message: `${username} have not used ${hashtag}`
                });
            }
          }
        });
      }
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'Invalid details'
        });
    }
  }catch(err) {
    next(err);
  }
};


bountyParticipantsController.mediumValidation = async (req, res, next) => {
  try {
    let params = { 'screen_name': req.params.username }
    let userId;
    let validUser = false;
    const userData = await request.get({
      url: `https://medium.com/@${req.params.username}?format=json`
    }, async(err, httpResponse, body) => {
      if (err) {
        return res
          .status(200)
          .json({
            success: false,
            message: 'No such user exists in medium'
          });
      }else {
        let result = JSON.parse(body.replace(/[^{]*/i, ''));
        if (!result.success) {
          return res
            .status(200)
            .json({
              success: false,
              message: 'No such user exists in medium'
            });
        }else {
          userId = result.payload.user.userId;
          console.log('userId: -> ', userId)
          // update participation
          console.log('userId : ', req.params.userId);
          console.log('bountyCampaignId', req.params.campaignId);

          const usernameValidationUpdate = await modelFunction.findOneAndUpdate({
            query: {
              userId: req.params.userId,
              bountyCampaignId: req.params.campaignId
            },
            params: {
              $set: {
                usernameValidation: 'yes'
              }
            }
          });
          console.log('usernameValidationUpdate : ', usernameValidationUpdate);
          if(!!usernameValidationUpdate) {
            return res
              .status(200)
              .json({
                success: true,
                message: 'Valid username'
              });
          }else {
            return res
              .status(200)
              .json({
                success: true,
                message: 'No such medium user participated in the campaign'
              });
          }
        }
      }
    });
  } catch(err) {
    // next(err);
    // console.log('ERROR : ', err);
    return res
      .status(200)
      .json({
        success: false,
        message: 'Invalid username'
      });
  }
};

bountyParticipantsController.redditValidation = async(req, res, next) => {
  try {
    let hashtagExists = false;
    let postCounter = 0;
    let postTitle;
    const after='';
    console.log('username : ', req.params.username);
    const redditUserData = await request.get(
      {
        url: `https://gateway.reddit.com/desktopapi/v1/user/${req.params.username}/posts`,
      }, async (err, httpResponse, body)=> {
        if(err) {
          next(err);
        }else {
          console.log('body : ', body);
          let result = JSON.parse(body);
          if(result.code === 404) {
            return res
              .status(404)
              .json({
                success: false,
                message: result.explanation
              });
          }else {
            // user exists in reddit
            const usernameValidationUpdate = await modelFunction.findOneAndUpdate({
              query: {
                userId: req.params.userId,
                bountyCampaignId: req.params.campaignId
              },
              params: {
                $set: {
                  usernameValidation: 'yes'
                }
              }
            });
            console.log('usernameValidationUpdate : ', usernameValidationUpdate);
            if(!!usernameValidationUpdate) {
              return res
                .status(200)
                .json({
                  success: true,
                  message: 'Valid username'
                });
            }else {
              return res
                .status(200)
                .json({
                  success: true,
                  message: 'No such reddit user participated in the campaign'
                });
            }
          }
        }
      }
    );
  }catch(err) {
    next(err);
  }
}



bountyParticipantsController.twitterValidation = async (req, res, next) => {
  try {
    let params = { 'screen_name': req.params.username }
    const twitterData = await client.get('/users/show', params);
    console.log('twitterData : ', twitterData);
    if(!!twitterData) {
      console.log('helllllllllllll!!!!!!!!!!');
      // set usernameValidation to yes
      console.log('userId : ', req.params.userId);
      console.log('bountyCampaignId', req.params.campaignId);
      // const findValid = await modelFunction.findOne({
      //   params: {
      //     userId: req.params.userId,
      //     bountyCampaignId: req.params.campaignId
      //   }
      // });
      // console.log('findValid : ', findValid);
      const usernameValidationUpdate = await modelFunction.findOneAndUpdate({
        query: {
          userId: req.params.userId,
          bountyCampaignId: req.params.campaignId
        },
        params: {
          $set: {
            usernameValidation: 'yes'
          }
        }
      });
      console.log('usernameValidationUpdate : ', usernameValidationUpdate);
      if(!!usernameValidationUpdate) {
        return res
          .status(200)
          .json({
            success: true,
            message: 'Valid username'
          });
      }else {
        return res
          .status(200)
          .json({
            success: true,
            message: 'No such twitter user participated in the campaign'
          });
      }
    }
  } catch(err) {
    // next(err);
    // console.log('ERROR : ', err);
    return res
      .status(200)
      .json({
        success: false,
        message: 'Invalid username'
      });
  }
};

bountyParticipantsController.twittertTotalFollowers = async (req, res, next) => {
  try {
    let params = { 'screen_name': req.params.username }
    const twitterData = await client.get('/users/show', params);
    console.log('twitterData : ', twitterData);
    if(!!twitterData) {
      return res
        .status(200)
        .json({
          success: true,
          followersCount: twitterData.followers_count,
          twitterId: twitterData.id_str
        })
    }
  } catch(err) {
    // next(err);
    // console.log('ERROR : ', err);
    return res
      .status(200)
      .json({
        success: false,
        message: 'Invalid username'
      });
  }
};

bountyParticipantsController.twitterRetweetedQuoted = async(req, res, next) => {
  try{
    console.log('inside twitterRetweetedQuoted');
    let params = {};
    params.screen_name = req.params.username;
    const originalTweetId = req.params.originalTweetId;
    const userTweetId = req.params.userTweetId;

    const twitterData = await client.get('statuses/user_timeline', params);
    console.log('twitterData : ', twitterData);
    let foundTweetWithUserTweetId = false;
    if(!!twitterData) {
      // console.log('got twitter data');
      twitterData.forEach( (data) => {
        if(data.id_str == userTweetId) {
          console.log('data : ******** :---------------------: ', data);
          foundTweetWithUserTweetId = true;
          if(data.retweeted_status.id_str != originalTweetId) {
            console.log('data.quoted_status_id_str');
            return res
              .status(200)
              .json({
                success: false,
                message: `${req.params.username} have not retweetedQuoted`
              });
          } else {
            return res
              .status(200)
              .json({
                success: false,
                message: `${req.params.username}have retweetedQuoted`
              });
          }
        }
      });

      if(!foundTweetWithUserTweetId) {
        return res
          .status(200)
          .json({
            success: false,
            message: 'Invalid user tweetId'
          });
      }
    }else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'invalid details'
        });
    }
  }catch(err) {
    next(err);
  }

};


bountyParticipantsController.twitterHashTag = async(req, res, next) => {
  try{
    console.log('inside twitterRetweetedQuoted');
    let params = {};
    params.screen_name = req.params.username;
    const userTweetId = req.params.userTweetId;

    const twitterData = await client.get('statuses/user_timeline', params);
    // console.log('twitterData : ', twitterData);

    if(!!twitterData) {
      // console.log('got twitter data');
      let isHashTagged = false;
      twitterData.forEach( (data) => {
        if(data.id_str == userTweetId) {
          // console.log('data : ******** :---------------------: ', data);
          let hashtag =  req.params.hashtag
          hashtag.includes('#') ?
            hashtag = hashtag
            :
            hashtag = '#' + hashtag

          let text = data.text;
          isHashTagged = text.indexOf(hashtag) !== -1;
          console.log('text : ', text);
          if(!!isHashTagged) {
            console.log(`${hashtag} exists`);
            return res
              .status(200)
              .json({
                success: false,
                message: `${hashtag} exists`,
                text: text
              });
          } else {
            return res
              .status(200)
              .json({
                success: false,
                message: `${hashtag} does not exists`
              });
          }
        }
      });
    } else {
      return res
        .status(200)
        .json({
          success: false,
          message: 'invalid details'
        });
    }
  }catch(err) {
    next(err);
  }

};

module.exports = bountyParticipantsController;
