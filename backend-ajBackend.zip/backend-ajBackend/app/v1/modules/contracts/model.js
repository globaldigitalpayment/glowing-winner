const mongoose = require('mongoose');

const tokenSchema = new mongoose.Schema({
  'name': {
    type: String,
    required: true
  },
  'address': {
    type: String,
    required: true
  },
  'network': {
    type: String,
    required: true,
    // mainnet ,ropsten ,rinkeby, kovan ,infuranet
    enum: ['mainnet', 'ropsten', 'rinkeby', 'kovan', 'infuranet']
  },
  // token or crowdsale
  'tokenType': {
    type: String,
    required: true,
    enum: ['token', 'crowdsale', 'airdropCentral', 'airdroper']
  },
  'useInDashboard' : {
    type : Boolean ,
    default : false
  },
  'abi': {
    type: String,
    required: true
  },
  'timestamps': {
    'createdAt': { type: Date, default: Date.now() },
    'updatedAt': { type: Date }
  }
});


const Token = mongoose.model('Token', tokenSchema);
module.exports = Token;


// indexing, mongoose-created,update_at,
