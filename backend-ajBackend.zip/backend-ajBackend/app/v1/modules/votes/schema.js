const { Joi } = require('celebrate');

module.exports = {
  vote: {
    body: Joi.object().keys({
      votes: Joi.array().items(Joi.string()).required()
    })
  }
    
};
