const userModelFunction = require('../user/doa'),
  Boom = require('boom'),
  {
    addSubmitVoteLog
  } = require('./../logs/controller'),
  constants = require('config/constants');

const responseMsgs = constants.responseMsgs;

const voteController = Object.create(null);

voteController.submitVote = async (req,res,next) => {
  let userid = req.user.id,
    votes = req.body.votes;
  if (votes.length < constants.votes.min || votes.length > constants.votes.max) {
    return res.status(200).json({ success:false,message : responseMsgs.VOTING.MIN_ALERT });
  }
  try {
    const findResult = await userModelFunction.findById({ id:userid,projection:'votes refer' });
    if (findResult.refer.voted) {
      return res.status(200).json({ success:false,message : 'You have already submitted your vote' });
    }
    const data = {
      $set :{
        'votes' : req.body.votes,
        'refer.voted' : true
      },
      $inc : {
        'tokens.vote' : constants.voteRewardTokens,
        'tokens.total' : constants.voteRewardTokens
      }
    };
    const voteUpdateResult = await userModelFunction.findByIdAndUpdate({ id:userid,data }); // eslint-disable-line

    if (findResult.refer.referee) {

      const refereeId = findResult.refer.referee;
      const params = { _id:refereeId };
      const referre = await userModelFunction.findOne({ params });

      if (referre.refer.success < 100) {
         let data = { // eslint-disable-line
          $set: {
            'refer.success': referre.refer.success + 1,
            'tokens.referral': constants.getReferralTokenInc(referre.refer.success + 1),
            'tokens.total': constants.voteRewardTokens + constants.getReferralTokenInc(referre.refer.success + 1)
          }
        };
        const insertResult = await userModelFunction.findByIdAndUpdate({ id: referre.id,data }); // eslint-disable-line
      }
    }
    if(!!req.user.saveActivityLogs) {
      var ip = (req.headers['x-forwarded-for'] || '').split(',').pop() ||
        req.connection.remoteAddress ||
        req.socket.remoteAddress ||
        req.connection.socket.remoteAddress;
      let date = new Date();
      date = date.toISOString();
      addSubmitVoteLog({ _id: req.user._id, email: req.user.email.value, submittedAt: date, ip: ip })
        .then(data => {
          console.log('Successfully store log', data);
        })
        .catch(err => {
          logger.error('addSubmitVoteLog is unable to store log');
        });
    }
    next();
    // return res.status(200).json({ success:true,message : responseMsgs.VOTING.SUCCESS });
  } catch (error) {
    next(Boom.badImplementation(error));
  }

};

voteController.isReferred = async (userId) => {
  const userid = userId;
  try {
    const findResult = await userModelFunction.findById({ id:userid,projection:'refer tokens' });

    if (findResult.refer.referee) {

      const refereeId = findResult.refer.referee;
      const params = { _id:refereeId };
      const referre = await userModelFunction.findOne({ params });

      //if (referre.refer.success < 100) {
           let data = { // eslint-disable-line
        $set: {
          'refer.success': referre.refer.success + 1
          //,
          //'tokens.referral': constants.getReferralTokenInc(referre.refer.success + 1),
          //'tokens.total': referre.tokens.preSale + referre.tokens.privateSale + referre.tokens.crowdSale + constants.voteRewardTokens + constants.getReferralTokenInc(referre.refer.success + 1)
        }
      };
          const insertResult = await userModelFunction.findByIdAndUpdate({ id: referre.id,data }); // eslint-disable-line
      //}
    }
  } catch (error) {
    next(Boom.badImplementation(error));
  }

};

module.exports = voteController;
