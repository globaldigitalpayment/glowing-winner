const controller = require('./controller'),
  { celebrate } = require('celebrate');

const validateSchema = require('./schema');
let authenticate = require('./../../config/authenticate');

module.exports = function(router) {

  /**
	 * @swagger
	 * /user/vote:
	 *  post:
	 *   description : Submit vote by user
	 *   tags:
	 *    - Vote
	 *   produces:
	 *    - application/json
	 *   parameters:
	 *    - name: x-auth-token
	 *      in: header
	 *      schema:
	 *        type: string
	 *      required: true
	 *      description: Token obtained on login
     *    - name: votes
	 *      in: body
	 *      schema:
	 *        type: Array
	 *      required: true
	 *      description: Array of votes
	 *  responses:
	 *    200:
	 *     	description: success message
	 */
  router.post('/user/vote',
    authenticate,
    celebrate(validateSchema.vote),
    controller.submitVote);
};
